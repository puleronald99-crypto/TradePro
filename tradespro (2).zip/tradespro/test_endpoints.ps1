$response = Invoke-WebRequest -Uri 'http://localhost:5000/api/search/artisans' -UseBasicParsing
$data = $response.Content | ConvertFrom-Json

Write-Host "API Search Results:" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Total artisans found: $($data.total)" -ForegroundColor Green
Write-Host ""

if ($data.artisans -and $data.artisans.Count -gt 0) {
    Write-Host "Sample Artisans:" -ForegroundColor Yellow
    $data.artisans | Select-Object -First 5 | ForEach-Object {
        Write-Host "  • $($_.name)" -ForegroundColor Green
        Write-Host "    Service: $($_.service_type)" -ForegroundColor Gray
        Write-Host "    Rate: `$$($_.hourly_rate)/hr" -ForegroundColor Gray
        Write-Host "    Rating: $($_.rating)/5 ($($_.total_reviews) reviews)" -ForegroundColor Gray
        Write-Host "    Location: $($_.location)" -ForegroundColor Gray
        Write-Host ""
    }
} else {
    Write-Host "No artisans found!" -ForegroundColor Red
}

# Test search with service filter
Write-Host "`nSearching by Service (Electrical):" -ForegroundColor Yellow
$response2 = Invoke-WebRequest -Uri 'http://localhost:5000/api/search/artisans?service_type=Electrical' -UseBasicParsing
$data2 = $response2.Content | ConvertFrom-Json
Write-Host "Found: $($data2.total) electricians" -ForegroundColor Green

if ($data2.artisans.Count -gt 0) {
    $data2.artisans | ForEach-Object {
        Write-Host "  • $($_.name) - `$$($_.hourly_rate)/hr" -ForegroundColor Gray
    }
}

# Test search with service + location
Write-Host "`nSearching by Service + Location (Electrical, Maseru):" -ForegroundColor Yellow
$response3 = Invoke-WebRequest -Uri 'http://localhost:5000/api/search/artisans?service_type=Electrical&location=Maseru' -UseBasicParsing
$data3 = $response3.Content | ConvertFrom-Json
Write-Host "Found: $($data3.total) in Maseru" -ForegroundColor Green

if ($data3.artisans.Count -gt 0) {
    $data3.artisans | ForEach-Object {
        Write-Host "  • $($_.name)" -ForegroundColor Gray
    }
} else {
    Write-Host "  (No electricians in Maseru)" -ForegroundColor Gray
}

Write-Host "`n================================" -ForegroundColor Cyan
Write-Host "[OK] API is working!" -ForegroundColor Green
