#!/usr/bin/env python
"""Test script to create a customer account and test the dashboard"""

import json
import sys
sys.path.insert(0, 'backend')

from config import get_db_connection, close_db_connection
from auth import hash_password

# Create connection
conn = get_db_connection()
if not conn:
    print("ERROR: Cannot connect to database")
    sys.exit(1)

cursor = conn.cursor()

try:
    # Check if test customer exists
    cursor.execute("SELECT id FROM users WHERE email = %s", ("testcustomer@example.com",))
    existing = cursor.fetchone()
    
    if existing:
        user_id = existing[0]
        print(f"✓ Test customer already exists with ID: {user_id}")
    else:
        # Create new customer
        hashed_pwd = hash_password("TestPassword123!")
        cursor.execute("""
            INSERT INTO users (name, email, password, is_artisan, created_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, ("Test Customer", "testcustomer@example.com", hashed_pwd, 0))
        
        conn.commit()
        user_id = cursor.lastrowid
        print(f"✓ Created test customer with ID: {user_id}")
    
    # Check user data
    cursor.execute("SELECT id, name, email, is_artisan FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    if user:
        print(f"✓ User data: ID={user[0]}, Name={user[1]}, Email={user[2]}, IsArtisan={user[3]}")
    
    # Check if any artisans exist
    cursor.execute("SELECT COUNT(*) FROM users WHERE is_artisan = 1")
    artisan_count = cursor.fetchone()[0]
    print(f"✓ Total artisans in database: {artisan_count}")
    
    # Check if any bookings exist
    cursor.execute("SELECT COUNT(*) FROM bookings")
    booking_count = cursor.fetchone()[0]
    print(f"✓ Total bookings in database: {booking_count}")
    
    # Check if any services exist
    cursor.execute("SELECT COUNT(*) FROM services")
    service_count = cursor.fetchone()[0]
    print(f"✓ Total services in database: {service_count}")
    
    print("\n✓ Database is ready. Test customer credentials:")
    print(f"  Email: testcustomer@example.com")
    print(f"  Password: TestPassword123!")
    print(f"  User ID: {user_id}")
    
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
finally:
    cursor.close()
    close_db_connection(conn)
