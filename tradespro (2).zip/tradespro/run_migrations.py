import mysql.connector
from mysql.connector import Error
import os

try:
    # Connect to MySQL using the same credentials as the app
    connection = mysql.connector.connect(
        host='127.0.0.1',
        port=3306,
        user='root',
        password='NewStrongPassword123!',
        database='tradespro',
        autocommit=False
    )
    
    if connection.is_connected():
        cursor = connection.cursor()
        
        # Read and execute migrations
        db_info = connection.get_server_info()
        print(f"Connected to MySQL Server version {db_info}")
        
        migration_file = os.path.join(os.path.dirname(__file__), 'database', 'migrations.sql')
        
        with open(migration_file, 'r') as file:
            sql_script = file.read()
        
        # Split by semicolon and execute each statement
        statements = sql_script.split(';')
        count = 0
        for statement in statements:
            statement = statement.strip()
            # Skip comments and empty statements
            if statement and not statement.startswith('--'):
                try:
                    cursor.execute(statement)
                    connection.commit()
                    count += 1
                    print(f"✓ [{count}] {statement[:70].replace(chr(10), ' ')}...")
                except Error as e:
                    if 'already exists' in str(e).lower() or 'duplicate' in str(e).lower():
                        print(f"ℹ [{count}] Already exists (skipped): {statement[:70]}")
                        count += 1
                    else:
                        print(f"✗ Error on: {statement[:70]}")
                        print(f"  -> {e}")
        
        cursor.close()
        connection.close()
        print(f"\n✓ Migrations completed! {count} operations executed.")

except Error as e:
    print(f"✗ Connection Error: {e}")
except Exception as e:
    print(f"✗ Unexpected Error: {e}")
