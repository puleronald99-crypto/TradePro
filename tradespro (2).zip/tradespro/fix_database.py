#!/usr/bin/env python3
"""Create missing tables and fix database schema"""

import mysql.connector
import sys

def fix_database():
    """Create missing tables"""
    try:
        connection = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            database='tradespro'
        )
        
        cursor = connection.cursor()
        
        # Create artisan_availability table if it doesn't exist
        print("Creating artisan_availability table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS artisan_availability (
                id INT AUTO_INCREMENT PRIMARY KEY,
                artisan_id INT NOT NULL,
                day_of_week VARCHAR(20),
                start_time TIME,
                end_time TIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
            )
        """)
        print("✓ artisan_availability table created")
        
        # Create skills table if it doesn't exist
        print("Creating skills table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS skills (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) UNIQUE NOT NULL,
                category VARCHAR(100),
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✓ skills table created")
        
        # Create artisan_skills table if it doesn't exist
        print("Creating artisan_skills table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS artisan_skills (
                id INT AUTO_INCREMENT PRIMARY KEY,
                artisan_id INT NOT NULL,
                skill_id INT NOT NULL,
                proficiency_level VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
                FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
                UNIQUE KEY unique_artisan_skill (artisan_id, skill_id)
            )
        """)
        print("✓ artisan_skills table created")
        
        # Create certifications table if it doesn't exist
        print("Creating certifications table...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS certifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                artisan_id INT NOT NULL,
                certification_name VARCHAR(255) NOT NULL,
                issuing_organization VARCHAR(255),
                issue_date DATE,
                expiration_date DATE,
                certificate_number VARCHAR(255),
                document_url VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
            )
        """)
        print("✓ certifications table created")
        
        # Check and fix services table structure
        print("\nChecking services table structure...")
        cursor.execute("DESCRIBE services")
        columns = cursor.fetchall()
        column_names = [col[0] for col in columns]
        
        if 'description' not in column_names:
            cursor.execute("ALTER TABLE services ADD COLUMN description TEXT")
            print("✓ Added description column to services table")
        
        if 'icon' not in column_names:
            cursor.execute("ALTER TABLE services ADD COLUMN icon VARCHAR(255)")
            print("✓ Added icon column to services table")
        
        if 'category' not in column_names:
            cursor.execute("ALTER TABLE services ADD COLUMN category VARCHAR(100)")
            print("✓ Added category column to services table")
        
        # Check and fix artisan_services table structure
        print("\nChecking artisan_services table structure...")
        cursor.execute("DESCRIBE artisan_services")
        columns = cursor.fetchall()
        column_names = [col[0] for col in columns]
        
        if 'hourly_rate' not in column_names:
            cursor.execute("ALTER TABLE artisan_services ADD COLUMN hourly_rate DECIMAL(10, 2)")
            print("✓ Added hourly_rate column to artisan_services table")
        
        connection.commit()
        cursor.close()
        connection.close()
        
        print("\n✓ Database migration completed successfully!")
        return True
        
    except mysql.connector.Error as e:
        if "already exists" in str(e):
            print(f"Note: {e}")
        else:
            print(f"Error: {e}")
            return False
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    success = fix_database()
    sys.exit(0 if success else 1)
