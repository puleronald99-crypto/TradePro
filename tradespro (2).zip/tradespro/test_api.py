#!/usr/bin/env python
"""Test the Flask API endpoints"""

import requests
import json

BASE_URL = "http://localhost:5000"

print("=" * 70)
print("TESTING FLASK API")
print("=" * 70)

# Test 1: Health check
print("\n[TEST 1] Health Check")
print("-" * 70)
try:
    response = requests.get(f"{BASE_URL}/api/health", timeout=5)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
except Exception as e:
    print(f"❌ Error: {e}")

# Test 2: Search artisans - all
print("\n[TEST 2] Get All Artisans")
print("-" * 70)
try:
    response = requests.get(f"{BASE_URL}/api/search/artisans", timeout=5)
    data = response.json()
    print(f"Status: {response.status_code}")
    print(f"Total artisans: {data.get('total')}")
    if data.get('artisans'):
        print("\nFirst artisan:")
        print(json.dumps(data['artisans'][0], indent=2))
except Exception as e:
    print(f"❌ Error: {e}")

# Test 3: Search by service type
print("\n[TEST 3] Search by Service Type (Electrical)")
print("-" * 70)
try:
    response = requests.get(f"{BASE_URL}/api/search/artisans?service_type=Electrical", timeout=5)
    data = response.json()
    print(f"Status: {response.status_code}")
    print(f"Total found: {data.get('total')}")
    if data.get('artisans'):
        for artisan in data['artisans']:
            print(f"  • {artisan['name']} - {artisan.get('service_type')} @ ${artisan.get('hourly_rate')}/hr")
except Exception as e:
    print(f"❌ Error: {e}")

# Test 4: Search by service + location
print("\n[TEST 4] Search by Service + Location (Electrical, Maseru)")
print("-" * 70)
try:
    response = requests.get(
        f"{BASE_URL}/api/search/artisans?service_type=Electrical&location=Maseru", 
        timeout=5
    )
    data = response.json()
    print(f"Status: {response.status_code}")
    print(f"Total found: {data.get('total')}")
    print(f"Response: {json.dumps(data, indent=2)}")
except Exception as e:
    print(f"❌ Error: {e}")

# Test 5: Get services
print("\n[TEST 5] Get All Services")
print("-" * 70)
try:
    response = requests.get(f"{BASE_URL}/api/services", timeout=5)
    data = response.json()
    print(f"Status: {response.status_code}")
    if data.get('services'):
        print(f"Total services: {len(data['services'])}")
        for service in data['services'][:5]:
            print(f"  • {service['name']}")
except Exception as e:
    print(f"❌ Error: {e}")

# Test 6: Search by service name - Plumbing
print("\n[TEST 6] Search by Service Type (Plumbing)")
print("-" * 70)
try:
    response = requests.get(f"{BASE_URL}/api/search/by-service/Plumbing", timeout=5)
    data = response.json()
    print(f"Status: {response.status_code}")
    print(f"Service: {data.get('service', {}).get('name')}")
    print(f"Total artisans: {len(data.get('artisans', []))}")
    if data.get('artisans'):
        for artisan in data['artisans']:
            print(f"  • {artisan['name']} - ${artisan.get('hourly_rate')}/hr")
except Exception as e:
    print(f"❌ Error: {e}")

print("\n" + "=" * 70)
print("TEST COMPLETE")
print("=" * 70)
