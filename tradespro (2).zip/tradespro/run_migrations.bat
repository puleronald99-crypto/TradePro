@echo off
cd /d "C:\xampp\htdocs\tradespro\database"
"C:\xampp\mysql\bin\mysql" -u root tradespro < migrations.sql
echo.
echo Migrations completed!
pause
