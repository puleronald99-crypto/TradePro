#!/usr/bin/env python
"""Add test artisans to the database for search testing"""

import sys
sys.path.insert(0, r'c:\xampp\htdocs\tradespro')

from backend.config import get_db_connection
from backend.auth import hash_password

def add_test_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check existing services
        cursor.execute("SELECT id, name FROM services LIMIT 10")
        services = cursor.fetchall()
        print("Existing services:")
        for service in services:
            print(f"  {service[0]}: {service[1]}")
        
        # Check locations
        cursor.execute("SELECT id, city, country FROM locations LIMIT 5")
        locations = cursor.fetchall()
        print("\nExisting locations:")
        for loc in locations:
            print(f"  {loc[0]}: {loc[1]}, {loc[2]}")
        
        # Check existing users
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_artisan = 1")
        artisan_count = cursor.fetchone()[0]
        print(f"\nExisting artisans: {artisan_count}")
        
        # Add test artisans if we have services and locations
        if services and locations:
            print("\n--- Adding Test Artisans ---")
            
            service_ids = [s[0] for s in services]
            location_id = locations[0][0]
            
            # Test artisans to add
            test_artisans = [
                {
                    'name': 'John Smith',
                    'email': 'john.smith@test.com',
                    'bio': 'Expert handyman with 10 years experience',
                    'service_type': services[0][1] if services else 'General Services',
                    'hourly_rate': 65.00,
                    'experience_years': 10,
                    'rating': 4.8,
                    'total_reviews': 45
                },
                {
                    'name': 'Maria Garcia',
                    'email': 'maria.garcia@test.com',
                    'bio': 'Professional cleaning specialist',
                    'service_type': services[1][1] if len(services) > 1 else 'General Services',
                    'hourly_rate': 45.00,
                    'experience_years': 8,
                    'rating': 4.9,
                    'total_reviews': 78
                },
                {
                    'name': 'David Johnson',
                    'email': 'david.johnson@test.com',
                    'bio': 'Licensed electrician and contractor',
                    'service_type': services[2][1] if len(services) > 2 else 'General Services',
                    'hourly_rate': 85.00,
                    'experience_years': 15,
                    'rating': 4.7,
                    'total_reviews': 92
                },
                {
                    'name': 'Sarah Wilson',
                    'email': 'sarah.wilson@test.com',
                    'bio': 'Expert plumber and gas fitter',
                    'service_type': 'Plumbing',
                    'hourly_rate': 95.00,
                    'experience_years': 12,
                    'rating': 4.6,
                    'total_reviews': 34
                },
                {
                    'name': 'Ahmed Hassan',
                    'email': 'ahmed.hassan@test.com',
                    'bio': 'Professional painter and decorator',
                    'service_type': 'Painting',
                    'hourly_rate': 50.00,
                    'experience_years': 6,
                    'rating': 4.5,
                    'total_reviews': 28
                }
            ]
            
            # Add test artisans
            for i, artisan_data in enumerate(test_artisans, 1):
                try:
                    # Check if user already exists
                    cursor.execute("SELECT id FROM users WHERE email = %s", (artisan_data['email'],))
                    existing = cursor.fetchone()
                    
                    if existing:
                        print(f"  {i}. {artisan_data['name']} - Already exists")
                        continue
                    
                    # Insert user
                    password_hash = hash_password('password123')
                    cursor.execute("""
                        INSERT INTO users (name, email, password, is_artisan)
                        VALUES (%s, %s, %s, 1)
                    """, (artisan_data['name'], artisan_data['email'], password_hash))
                    conn.commit()
                    user_id = cursor.lastrowid
                    
                    # Insert artisan profile
                    cursor.execute("""
                        INSERT INTO artisan_profiles 
                        (user_id, bio, experience_years, location_id, rating, total_reviews, availability_status)
                        VALUES (%s, %s, %s, %s, %s, %s, 'available')
                    """, (user_id, artisan_data['bio'], artisan_data['experience_years'], 
                          location_id, artisan_data['rating'], artisan_data['total_reviews']))
                    conn.commit()
                    artisan_id = cursor.lastrowid
                    
                    # Get or create service
                    cursor.execute("SELECT id FROM services WHERE LOWER(name) = %s", 
                                 (artisan_data['service_type'].lower(),))
                    service_row = cursor.fetchone()
                    
                    if service_row:
                        service_id = service_row[0]
                    else:
                        # Create service
                        cursor.execute("""
                            INSERT INTO services (name, category)
                            VALUES (%s, %s)
                        """, (artisan_data['service_type'], 'Professional Services'))
                        conn.commit()
                        service_id = cursor.lastrowid
                    
                    # Link artisan to service
                    cursor.execute("""
                        INSERT INTO artisan_services (artisan_id, service_id, hourly_rate)
                        VALUES (%s, %s, %s)
                    """, (artisan_id, service_id, artisan_data['hourly_rate']))
                    conn.commit()
                    
                    print(f"  {i}. {artisan_data['name']} ({artisan_data['service_type']}) - Added ✓")
                    
                except Exception as e:
                    print(f"  {i}. {artisan_data['name']} - Error: {str(e)}")
                    conn.rollback()
        
        cursor.close()
        conn.close()
        print("\n✓ Test data setup complete!")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        cursor.close()
        conn.close()

if __name__ == '__main__':
    add_test_data()
