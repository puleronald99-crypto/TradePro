# Backend Connection Troubleshooting Guide

## Issue: "Error connecting to server. Please try again"

This error occurs when the frontend cannot reach the backend `auth.php` file. Follow these steps to fix it:

### 1. **Verify XAMPP Apache is Running**
   - Open XAMPP Control Panel
   - Check if **Apache** is running (should show green)
   - If not running, click **Start** next to Apache
   - Port should be 80 (default)

### 2. **Verify Database is Running**
   - In XAMPP Control Panel, check if **MySQL** is running (should show green)
   - If not running, click **Start** next to MySQL

### 3. **Test Backend Connection**
   Open your browser and visit:
   ```
   http://localhost/tradespro/backend/test.php
   ```
   
   You should see JSON response like:
   ```json
   {
     "success": true,
     "message": "Backend is working!",
     "data": {
       "php_version": "7.x.x",
       "server": "Apache/...",
       "database": "Connected"
     }
   }
   ```

   If you get a blank page or error:
   - Check that `/backend/config.php` has correct database credentials
   - Default XAMPP credentials are: root (no password)

### 4. **Check File Paths**
   - Verify these files exist:
     - `c:\xampp\htdocs\tradespro\backend\auth.php`
     - `c:\xampp\htdocs\tradespro\backend\config.php`
     - `c:\xampp\htdocs\tradespro\frontend\login.html`
     - `c:\xampp\htdocs\tradespro\frontend\js\login.js`

### 5. **Check Console Errors**
   - Open browser DevTools (F12)
   - Go to **Console** tab
   - Look for error messages
   - Check **Network** tab to see if requests are being made

### 6. **Database Connection Debugging**
   Open `http://localhost/phpmyadmin` to verify:
   - Database `tradespro` exists
   - Table `users` exists with correct columns

### 7. **Common Issues & Solutions**

   **Issue**: MySQL not found
   - Make sure MySQL is started in XAMPP Control Panel
   - Check database credentials in `backend/config.php`

   **Issue**: 404 Error
   - File path is wrong
   - API_URL in `login.js` might be incorrect
   - Check that files are in correct directories

   **Issue**: Blank Response
   - PHP error occurred
   - Check `php_error_log` in XAMPP logs folder
   - Make sure `require_once 'config.php'` is working

### 8. **Manual Testing**
   Use Postman or cURL to test directly:
   ```bash
   curl -X POST http://localhost/tradespro/backend/auth.php \
     -d "action=sign_up&full_name=Test&email=test@example.com&password=123456&confirm_password=123456"
   ```

## If Still Not Working:
1. Check browser console (F12) for detailed error messages
2. Check XAMPP Apache error logs: `c:\xampp\apache\logs\error.log`
3. Check PHP error logs: `c:\xampp\php\logs\php_error.log`
4. Verify XAMPP is properly installed and Apache config is correct
