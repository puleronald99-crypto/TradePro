#!/usr/bin/env python3
"""
TradePro Login & Redirect Testing Script
Tests API endpoints and verifies login flow
"""

import requests
import json
import time

API_BASE_URL = "http://localhost:5000"

# Test user credentials (adjust based on your test data)
TEST_USER = {
    "email": "test@example.com",
    "password": "password123"
}

TEST_ARTISAN = {
    "email": "artisan@example.com",
    "password": "password123"
}

def test_health_check():
    """Test if API is running"""
    print("\n1️⃣  Testing API Health Check...")
    try:
        response = requests.get(f"{API_BASE_URL}/api/health", timeout=5)
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        return response.status_code == 200
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_signup(user_data=None):
    """Test signup endpoint"""
    print("\n2️⃣  Testing Signup...")
    if user_data is None:
        user_data = {
            "name": "Test User",
            "email": f"testuser_{int(time.time())}@example.com",
            "password": "testpass123",
            "is_artisan": False
        }
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/signup",
            json=user_data,
            timeout=5
        )
        print(f"   Status: {response.status_code}")
        print(f"   Response: {response.json()}")
        return response.json()
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return None

def test_login(email, password):
    """Test login endpoint"""
    print(f"\n3️⃣  Testing Login for {email}...")
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/login",
            json={"email": email, "password": password},
            timeout=5
        )
        print(f"   Status: {response.status_code}")
        data = response.json()
        print(f"   Response: {data}")
        return data
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return None

def main():
    print("="*60)
    print("TradePro Login & Redirect Testing")
    print("="*60)
    
    # Test 1: Health check
    if not test_health_check():
        print("\n❌ API is not running!")
        print("   Please start Flask backend: python backend/app.py")
        return
    
    print("\n✅ API is running!")
    
    # Test 2: Create a test user account
    print("\n\nCreating test account...")
    signup_result = test_signup()
    if signup_result and signup_result.get("status") == "success":
        email = signup_result["user"]["email"]
        print(f"\n✅ Test account created: {email}")
    else:
        email = TEST_USER["email"]
        print(f"\n⚠️  Using existing test account: {email}")
    
    # Test 3: Test login
    print("\n\nTesting login flow...")
    login_result = test_login(email, "testpass123")
    
    if login_result and login_result.get("status") == "success":
        print("\n✅ Login successful!")
        print(f"   User ID: {login_result['user']['id']}")
        print(f"   Is Artisan: {login_result['user'].get('is_artisan', False)}")
        print(f"   Would redirect to: {'artisan-dashboard.html' if login_result['user'].get('is_artisan') else 'user-dashboard.html'}")
    else:
        print("\n❌ Login failed!")
        if login_result:
            print(f"   Message: {login_result.get('message', 'Unknown error')}")
    
    print("\n" + "="*60)
    print("Test Summary:")
    print("="*60)
    print("""
✅ Features fixed:
  1. Error messages now display in red with left border
  2. Login errors are shown above the form
  3. Success messages are shown in green
  4. Form buttons are disabled during request
  5. Proper redirection after login based on user type
  6. Login protection on dashboards
  7. Console logging for debugging
  
📝 Testing in browser:
  1. Open: http://localhost/tradespro/frontend/
  2. Open DevTools (F12) - Console tab
  3. Try logging in
  4. Check console for debug messages
  5. Check Network tab for API responses
    """)

if __name__ == "__main__":
    main()
