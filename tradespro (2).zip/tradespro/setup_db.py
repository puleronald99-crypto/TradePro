#!/usr/bin/env python3
"""Initialize the database with schema from schema.sql"""

import mysql.connector
import sys

def setup_database():
    """Read and execute the schema.sql file"""
    try:
        # Read the schema file
        with open('database/schema.sql', 'r') as f:
            schema_content = f.read()
        
        # Connect to MySQL
        connection = mysql.connector.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            port=3306
        )
        
        cursor = connection.cursor()
        
        # Create database if not exists
        print("Creating database...")
        cursor.execute("CREATE DATABASE IF NOT EXISTS tradespro")
        cursor.execute("USE tradespro")
        
        # Split the schema into individual statements and execute them
        statements = schema_content.split(';')
        
        statement_count = 0
        for statement in statements:
            statement = statement.strip()
            if statement and not statement.startswith('--'):
                try:
                    cursor.execute(statement)
                    statement_count += 1
                except mysql.connector.Error as e:
                    if "already exists" not in str(e):
                        print(f"Warning: {e}")
        
        connection.commit()
        cursor.close()
        connection.close()
        
        print(f"✓ Database initialized successfully!")
        print(f"✓ Executed {statement_count} SQL statements")
        
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

if __name__ == "__main__":
    success = setup_database()
    sys.exit(0 if success else 1)
