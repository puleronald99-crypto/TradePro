"""
Database migration module - auto-runs on Flask startup
Ensures all required tables and columns exist
"""

from config import get_db_connection, close_db_connection
import sys

def run_migrations():
    """Execute database migrations to ensure schema is complete"""
    
    # SQL statements to run in order
    migrations = [
        # Create artisan_availability table
        """
        CREATE TABLE IF NOT EXISTS artisan_availability (
            id INT AUTO_INCREMENT PRIMARY KEY,
            artisan_id INT NOT NULL,
            day_of_week VARCHAR(20),
            start_time TIME,
            end_time TIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
        )
        """,
        
        # Create skills table
        """
        CREATE TABLE IF NOT EXISTS skills (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) UNIQUE NOT NULL,
            category VARCHAR(100),
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        
        # Create artisan_skills table
        """
        CREATE TABLE IF NOT EXISTS artisan_skills (
            id INT AUTO_INCREMENT PRIMARY KEY,
            artisan_id INT NOT NULL,
            skill_id INT NOT NULL,
            proficiency_level VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
            FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
            UNIQUE KEY unique_artisan_skill (artisan_id, skill_id)
        )
        """,
        
        # Create certifications table
        """
        CREATE TABLE IF NOT EXISTS certifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            artisan_id INT NOT NULL,
            certification_name VARCHAR(255) NOT NULL,
            issuing_organization VARCHAR(255),
            issue_date DATE,
            expiration_date DATE,
            certificate_number VARCHAR(255),
            document_url VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
        )
        """,

        # Create client favorites table
        """
        CREATE TABLE IF NOT EXISTS favorites (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            artisan_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
            UNIQUE KEY unique_user_artisan_favorite (user_id, artisan_id)
        )
        """,

        # Create client payment records table
        """
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            booking_id INT NOT NULL,
            customer_id INT NOT NULL,
            artisan_id INT NOT NULL,
            amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            status VARCHAR(50) NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
            FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
            UNIQUE KEY unique_booking_payment (booking_id)
        )
        """,

        # Create client and artisan messages table
        """
        CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            recipient_id INT NOT NULL,
            content TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """,

        # Create in-app notifications table
        """
        CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type VARCHAR(40) NOT NULL,
            title VARCHAR(160) NOT NULL,
            message TEXT NOT NULL,
            entity_id INT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """,

        # Create client payment methods table
        """
        CREATE TABLE IF NOT EXISTS client_payment_methods (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            method_type VARCHAR(20) NOT NULL,
            account_label VARCHAR(100),
            account_reference VARCHAR(255) NOT NULL,
            is_default BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """,

        # Create client settings table
        """
        CREATE TABLE IF NOT EXISTS client_settings (
            user_id INT PRIMARY KEY,
            booking_notifications BOOLEAN DEFAULT TRUE,
            message_notifications BOOLEAN DEFAULT TRUE,
            profile_visibility BOOLEAN DEFAULT TRUE,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
        """,
        
        # Fix services table - add missing columns (ignore errors if columns exist)
        "ALTER TABLE services ADD COLUMN description TEXT",
        "ALTER TABLE services ADD COLUMN icon VARCHAR(255)",
        "ALTER TABLE services ADD COLUMN category VARCHAR(100)",
        
        # Fix artisan_services table - add missing columns (ignore errors if columns exist)
        "ALTER TABLE artisan_services ADD COLUMN hourly_rate DECIMAL(10, 2)",
        "ALTER TABLE reviews ADD COLUMN booking_id INT NULL",
        "ALTER TABLE reviews ADD COLUMN artisan_reply TEXT NULL",
        "ALTER TABLE reviews ADD COLUMN artisan_reply_at TIMESTAMP NULL",
        "ALTER TABLE artisan_profiles ADD COLUMN response_time_minutes INT DEFAULT 60",
        "ALTER TABLE artisan_profiles ADD COLUMN buffer_time_minutes INT DEFAULT 30",
        "ALTER TABLE artisan_profiles ADD COLUMN is_premium BOOLEAN DEFAULT FALSE",
        "ALTER TABLE artisan_profiles ADD COLUMN profile_visible BOOLEAN DEFAULT TRUE",
        "ALTER TABLE users ADD COLUMN location_address VARCHAR(255)",
        "ALTER TABLE users ADD COLUMN latitude DECIMAL(10, 7)",
        "ALTER TABLE users ADD COLUMN longitude DECIMAL(10, 7)",
        "ALTER TABLE artisan_profiles ADD COLUMN workplace_address VARCHAR(255)",
        "ALTER TABLE artisan_profiles ADD COLUMN workplace_latitude DECIMAL(10, 7)",
        "ALTER TABLE artisan_profiles ADD COLUMN workplace_longitude DECIMAL(10, 7)",
        "ALTER TABLE artisan_profiles ADD COLUMN fuel_consumption_l_per_100km DECIMAL(6, 2) DEFAULT 8.00",
        "ALTER TABLE artisan_profiles ADD COLUMN fuel_price_per_liter DECIMAL(10, 2) DEFAULT 0.00",
        "ALTER TABLE bookings ADD COLUMN client_location_address VARCHAR(255)",
        "ALTER TABLE bookings ADD COLUMN client_latitude DECIMAL(10, 7)",
        "ALTER TABLE bookings ADD COLUMN client_longitude DECIMAL(10, 7)",
        "ALTER TABLE bookings ADD COLUMN distance_km DECIMAL(10, 2)",
        "ALTER TABLE bookings ADD COLUMN estimated_travel_minutes INT",
        "ALTER TABLE bookings ADD COLUMN estimated_fuel_cost DECIMAL(10, 2)",
        
        # Create indexes for performance
        "CREATE INDEX idx_artisan_availability_artisan_id ON artisan_availability(artisan_id)",
        "CREATE INDEX idx_artisan_skills_artisan_id ON artisan_skills(artisan_id)",
        "CREATE INDEX idx_artisan_skills_skill_id ON artisan_skills(skill_id)",
        "CREATE INDEX idx_certifications_artisan_id ON certifications(artisan_id)",
        "CREATE INDEX idx_favorites_user_id ON favorites(user_id)",
        "CREATE INDEX idx_favorites_artisan_id ON favorites(artisan_id)",
        "CREATE INDEX idx_payments_customer_id ON payments(customer_id)",
        "CREATE INDEX idx_messages_sender_id ON messages(sender_id)",
        "CREATE INDEX idx_messages_recipient_id ON messages(recipient_id)",
        "CREATE INDEX idx_messages_created_at ON messages(created_at)",
        "CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read, created_at)",
        "CREATE INDEX idx_client_payment_methods_user_id ON client_payment_methods(user_id)",
        "CREATE INDEX idx_reviews_booking_id ON reviews(booking_id)",
    ]
    
    connection = get_db_connection()
    if connection is None:
        print("ERROR: Could not connect to database for migrations")
        return False
    
    try:
        cursor = connection.cursor()
        
        for i, migration in enumerate(migrations, 1):
            try:
                cursor.execute(migration)
                print(f"✓ Migration {i}/{len(migrations)} completed successfully")
            except Exception as e:
                # Log the error but continue
                print(f"⚠ Migration {i} warning: {str(e)}")
                # Don't fail on ALTER TABLE IF NOT EXISTS or CREATE TABLE IF NOT EXISTS
                if "already exists" not in str(e) and "Duplicate column name" not in str(e) and "Duplicate key name" not in str(e) and "already has" not in str(e):
                    raise
        
        connection.commit()
        print("\n✅ All database migrations completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Migration failed: {str(e)}")
        connection.rollback()
        return False
    finally:
        close_db_connection(connection)

if __name__ == "__main__":
    """Run migrations manually if script is executed directly"""
    success = run_migrations()
    sys.exit(0 if success else 1)
