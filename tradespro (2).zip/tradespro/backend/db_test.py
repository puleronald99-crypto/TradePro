# Database Connection Test

from config import get_db_connection, close_db_connection

def test_connection():
    """Test the database connection"""
    print("\n" + "="*50)
    print("Database Connection Test")
    print("="*50)
    
    connection = get_db_connection()
    
    if connection is None:
        print("✗ Connection failed!")
        return
    
    try:
        print("✓ Database connection successful!")
        print(f"✓ Host: 127.0.0.1")
        print(f"✓ Port: 3306")
        print(f"✓ Database: tradespro")
        
        # Show tables
        cursor = connection.cursor()
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        print(f"\n✓ Tables in database ({len(tables)} total):")
        if tables:
            for table in tables:
                print(f"  - {table[0]}")
        else:
            print("  (No tables found. Run schema.sql to initialize.)")
        
        cursor.close()
        
    except Exception as e:
        print(f"✗ Error: {e}")
    finally:
        close_db_connection(connection)
    
    print("="*50 + "\n")

if __name__ == "__main__":
    test_connection()
