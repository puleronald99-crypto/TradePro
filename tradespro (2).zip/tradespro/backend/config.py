# Database Configuration for External MySQL

import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'root',
    'password': 'NewStrongPassword123!',
    'database': 'tradespro'
}

def get_db_connection():
    """Create and return a database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
        return None

def close_db_connection(connection):
    """Close the database connection"""
    if connection and connection.is_connected():
        connection.close()
