"""
TradePro Backend API - Flask Application
"""

from flask import Flask, jsonify, request, send_file, send_from_directory, redirect, session, url_for
from flask_cors import CORS
from config import get_db_connection, close_db_connection
from auth import hash_password, verify_password, is_valid_email, is_valid_password, is_valid_phone
from migrate import run_migrations
import json
import os
import base64
import hashlib
import secrets
import urllib.parse
import urllib.request
import time
import math

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'tradepro-development-secret-change-me')
CORS(app)  # Enable CORS for frontend requests

SOCIAL_PROVIDER_ENV = {
    'google': ('GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'),
    'facebook': ('FACEBOOK_CLIENT_ID', 'FACEBOOK_CLIENT_SECRET'),
    'github': ('GITHUB_CLIENT_ID', 'GITHUB_CLIENT_SECRET')
}

SOCIAL_PROVIDER_CONFIG = {
    'google': {
        'authorize': 'https://accounts.google.com/o/oauth2/v2/auth',
        'token': 'https://oauth2.googleapis.com/token',
        'profile': 'https://openidconnect.googleapis.com/v1/userinfo',
        'scope': 'openid email profile'
    },
    'facebook': {
        'authorize': 'https://www.facebook.com/v19.0/dialog/oauth',
        'token': 'https://graph.facebook.com/v19.0/oauth/access_token',
        'profile': 'https://graph.facebook.com/me?fields=id,name,email,picture',
        'scope': 'email public_profile'
    },
    'github': {
        'authorize': 'https://github.com/login/oauth/authorize',
        'token': 'https://github.com/login/oauth/access_token',
        'profile': 'https://api.github.com/user',
        'scope': 'read:user user:email'
    }
}

def create_notification(cursor, user_id, notification_type, title, message, entity_id=None):
    cursor.execute(
        """INSERT INTO notifications (user_id, type, title, message, entity_id)
           VALUES (%s, %s, %s, %s, %s)""",
        (user_id, notification_type, title, message, entity_id)
    )

def calculate_trip_estimate(start_latitude, start_longitude, end_latitude, end_longitude, fuel_consumption, fuel_price):
    """Estimate road travel using a conservative 1.25 route factor.

    A live routing provider can replace this estimate later without changing booking data.
    """
    if None in (start_latitude, start_longitude, end_latitude, end_longitude):
        return None, None, None
    earth_radius_km = 6371
    lat_delta = math.radians(float(end_latitude) - float(start_latitude))
    lon_delta = math.radians(float(end_longitude) - float(start_longitude))
    start_latitude = math.radians(float(start_latitude))
    end_latitude = math.radians(float(end_latitude))
    haversine = math.sin(lat_delta / 2) ** 2 + math.cos(start_latitude) * math.cos(end_latitude) * math.sin(lon_delta / 2) ** 2
    straight_line_km = earth_radius_km * 2 * math.atan2(math.sqrt(haversine), math.sqrt(1 - haversine))
    route_km = straight_line_km * 1.25
    travel_minutes = max(1, round(route_km / 35 * 60))
    fuel_cost = route_km * float(fuel_consumption or 8) / 100 * float(fuel_price or 0)
    return round(route_km, 2), travel_minutes, round(fuel_cost, 2)

@app.route('/api/user/<int:user_id>/notifications', methods=['GET', 'PUT'])
def user_notifications(user_id):
    """Return or mark a user's in-app notifications."""
    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        if request.method == 'PUT':
            notification_id = (request.get_json(silent=True) or {}).get('notification_id')
            if notification_id:
                cursor.execute("UPDATE notifications SET is_read = TRUE WHERE id = %s AND user_id = %s", (notification_id, user_id))
            else:
                cursor.execute("UPDATE notifications SET is_read = TRUE WHERE user_id = %s", (user_id,))
            connection.commit()
        cursor.execute("""
            SELECT id, type, title, message, entity_id, is_read, created_at
            FROM notifications WHERE user_id = %s
            ORDER BY created_at DESC LIMIT 30
        """, (user_id,))
        notifications = [{
            "id": row[0], "type": row[1], "title": row[2], "message": row[3],
            "entity_id": row[4], "is_read": bool(row[5]),
            "created_at": row[6].isoformat() if row[6] else None
        } for row in cursor.fetchall()]
        unread_count = sum(1 for notification in notifications if not notification['is_read'])
        cursor.close()
        return jsonify({"status": "success", "notifications": notifications, "unread_count": unread_count}), 200
    except Exception as error:
        connection.rollback()
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

def social_json_request(url, payload=None, headers=None):
    body = urllib.parse.urlencode(payload or {}).encode() if payload is not None else None
    request = urllib.request.Request(url, data=body, headers=headers or {})
    with urllib.request.urlopen(request, timeout=15) as response:
        content = response.read().decode()
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return dict(urllib.parse.parse_qsl(content))

def social_redirect_uri(provider):
    return url_for('social_callback', provider=provider, _external=True)

@app.route('/api/auth/<provider>', methods=['GET'])
def social_auth(provider):
    """Start configured social authentication; Gmail uses Google's provider."""
    provider = provider.lower()
    if provider == 'gmail':
        provider = 'google'
    if provider not in SOCIAL_PROVIDER_ENV:
        return jsonify({"status": "error", "message": "Unsupported social provider"}), 400
    client_env, secret_env = SOCIAL_PROVIDER_ENV[provider]
    if not os.getenv(client_env) or not os.getenv(secret_env):
        return jsonify({
            "status": "error",
            "message": f"{provider.title()} login needs {client_env} and {secret_env} in backend/.env"
        }), 503
    state = secrets.token_urlsafe(32)
    session['social_oauth_state'] = state
    session['social_oauth_provider'] = provider
    session['social_oauth_is_artisan'] = request.args.get('is_artisan') == 'true'
    config = SOCIAL_PROVIDER_CONFIG[provider]
    params = {
        'client_id': os.getenv(client_env),
        'redirect_uri': social_redirect_uri(provider),
        'response_type': 'code',
        'scope': config['scope'],
        'state': state
    }
    return jsonify({"status": "success", "authorization_url": config['authorize'] + '?' + urllib.parse.urlencode(params)}), 200

@app.route('/api/auth/<provider>/callback', methods=['GET'])
def social_callback(provider):
    provider = provider.lower()
    if provider == 'gmail':
        provider = 'google'
    if provider not in SOCIAL_PROVIDER_CONFIG:
        return 'Unsupported social provider', 400
    if request.args.get('state') != session.pop('social_oauth_state', None):
        return 'Invalid OAuth state', 400
    code = request.args.get('code')
    if not code:
        return 'OAuth provider did not return an authorization code', 400
    client_env, secret_env = SOCIAL_PROVIDER_ENV[provider]
    config = SOCIAL_PROVIDER_CONFIG[provider]
    try:
        token = social_json_request(config['token'], {
            'client_id': os.getenv(client_env),
            'client_secret': os.getenv(secret_env),
            'code': code,
            'redirect_uri': social_redirect_uri(provider),
            'grant_type': 'authorization_code'
        }, {'Accept': 'application/json'})
        access_token = token.get('access_token')
        if not access_token:
            raise ValueError('OAuth token was not returned')
        profile = social_json_request(config['profile'], headers={
            'Authorization': f'Bearer {access_token}',
            'User-Agent': 'TradePro'
        })
        provider_id = str(profile.get('id') or profile.get('sub'))
        email = profile.get('email')
        if provider == 'github' and not email:
            emails = social_json_request('https://api.github.com/user/emails', headers={'Authorization': f'Bearer {access_token}', 'User-Agent': 'TradePro'})
            email = next((item.get('email') for item in emails if item.get('primary')), None) if isinstance(emails, list) else None
        if not email or not provider_id:
            raise ValueError('The provider did not return a usable email address')
        name = profile.get('name') or profile.get('login') or email.split('@')[0]
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute('SELECT id FROM users WHERE email = %s', (email.lower(),))
        existing = cursor.fetchone()
        is_artisan = session.pop('social_oauth_is_artisan', False)
        if existing:
            user_id = existing[0]
            cursor.execute('SELECT is_artisan FROM users WHERE id = %s', (user_id,))
            is_artisan = bool(cursor.fetchone()[0])
        else:
            password = hash_password(secrets.token_urlsafe(32))
            cursor.execute('INSERT INTO users (name, email, password, is_artisan) VALUES (%s, %s, %s, %s)', (name, email.lower(), password, is_artisan))
            user_id = cursor.lastrowid
            if is_artisan:
                cursor.execute('INSERT INTO artisan_profiles (user_id, availability_status) VALUES (%s, %s)', (user_id, 'available'))
            connection.commit()
        cursor.close()
        close_db_connection(connection)
        payload = base64.urlsafe_b64encode(json.dumps({'id': user_id, 'name': name, 'email': email.lower(), 'is_artisan': is_artisan}).encode()).decode()
        return redirect(f'/login.html?oauth_user={payload}')
    except Exception as error:
        return redirect('/login.html?oauth_error=' + urllib.parse.quote(str(error)))

# ==================== AUTOMATIC DATABASE MIGRATIONS ====================
# Run migrations on app startup to ensure schema is complete
print("\n" + "="*60)
print("Starting TradePro Backend API...")
print("="*60)
print("\nRunning database schema migrations...")
if run_migrations():
    print("Database is ready!\n")
else:
    print("WARNING: Database migrations encountered issues\n")

# ==================== FRONTEND ROUTES ====================

@app.route('/', methods=['GET'])
def index():
    """Serve login page as default"""
    return send_from_directory('../frontend', 'login.html')

@app.route('/frontend/<path:filename>', methods=['GET'])
def serve_frontend(filename):
    """Serve frontend files (HTML, CSS, JS)"""
    return send_from_directory('../frontend', filename)

@app.route('/<path:filename>', methods=['GET'])
def serve_root(filename):
    """Serve files from root frontend directory"""
    frontend_path = os.path.join('../frontend', filename)
    if os.path.exists(frontend_path):
        return send_from_directory('../frontend', filename)
    # Return 404 for non-existent files
    return jsonify({"status": "error", "message": "File not found"}), 404

# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "message": "TradePro API is running!"}), 200

@app.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password():
    """Create a short-lived password reset token.

    The reset link is returned for local development because this project has no
    configured mail provider. Production deployments should email this link.
    """
    data = request.get_json(silent=True) or {}
    email = (data.get('email') or '').strip().lower()
    if not is_valid_email(email):
        return jsonify({"status": "error", "message": "Please enter a valid email address"}), 400

    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        response = {"status": "success", "message": "If an account exists, a reset link has been created."}
        if user:
            token = secrets.token_urlsafe(32)
            token_value = f"{hashlib.sha256(token.encode()).hexdigest()}:{int(time.time())}"
            cursor.execute("UPDATE users SET reset_token = %s, updated_at = CURRENT_TIMESTAMP WHERE id = %s", (token_value, user[0]))
            response["reset_link"] = f"/reset-password.html?token={urllib.parse.quote(token)}"
        connection.commit()
        cursor.close()
        return jsonify(response), 200
    except Exception as error:
        connection.rollback()
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

@app.route('/api/auth/reset-password', methods=['GET', 'POST'])
def reset_password():
    """Validate a reset token or use it to set a new password."""
    data = request.get_json(silent=True) or {}
    token = request.args.get('token') or data.get('token')
    if not token:
        return jsonify({"status": "error", "message": "Reset token is required"}), 400

    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        cursor.execute("SELECT id, reset_token FROM users WHERE reset_token LIKE %s", (token_hash + ':%',))
        user = cursor.fetchone()
        if not user:
            return jsonify({"status": "error", "message": "This reset link is invalid or has expired"}), 400

        try:
            created_at = int(user[1].rsplit(':', 1)[1])
        except (ValueError, IndexError):
            return jsonify({"status": "error", "message": "This reset link is invalid or has expired"}), 400
        if int(time.time()) - created_at > 1800:
            return jsonify({"status": "error", "message": "This reset link has expired"}), 400

        if request.method == 'GET':
            return jsonify({"status": "success", "message": "Reset token is valid"}), 200

        new_password = data.get('new_password')
        valid, message = is_valid_password(new_password or '')
        if not valid:
            return jsonify({"status": "error", "message": message}), 400
        if new_password != data.get('confirm_password'):
            return jsonify({"status": "error", "message": "Passwords do not match"}), 400

        cursor.execute("UPDATE users SET password = %s, reset_token = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = %s", (hash_password(new_password), user[0]))
        connection.commit()
        cursor.close()
        return jsonify({"status": "success", "message": "Password reset successfully"}), 200
    except Exception as error:
        connection.rollback()
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

@app.route('/api/db-status', methods=['GET'])
def db_status():
    """Check database connection status"""
    connection = get_db_connection()
    
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT DATABASE()")
        db_name = cursor.fetchone()[0]
        
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        
        cursor.close()
        
        return jsonify({
            "status": "success",
            "database": db_name,
            "tables_count": len(tables),
            "tables": [table[0] for table in tables]
        }), 200
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    
    finally:
        close_db_connection(connection)

# ==================== AUTHENTICATION ENDPOINTS ====================

@app.route('/api/signup', methods=['POST'])
def signup():
    """Register a new user (client or artisan)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name') or not data.get('email') or not data.get('password'):
            return jsonify({"status": "error", "message": "All fields are required"}), 400
        
        name = data.get('name').strip()
        email = data.get('email').strip().lower()
        password = data.get('password')
        phone = data.get('phone', '').strip()
        is_artisan = data.get('is_artisan', False)
        
        # Validate email format
        if not is_valid_email(email):
            return jsonify({"status": "error", "message": "Invalid email format"}), 400
        
        # Validate password strength
        valid, msg = is_valid_password(password)
        if not valid:
            return jsonify({"status": "error", "message": msg}), 400
        
        # Validate phone if provided
        if phone and not is_valid_phone(phone):
            return jsonify({"status": "error", "message": "Invalid phone format"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Check if user already exists
            cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
            existing_user = cursor.fetchone()
            
            if existing_user:
                return jsonify({"status": "error", "message": "Email already registered"}), 400
            
            # Hash password
            password_hash = hash_password(password)
            
            # Insert user
            cursor.execute("""
                INSERT INTO users (name, email, password, phone, is_artisan)
                VALUES (%s, %s, %s, %s, %s)
            """, (name, email, password_hash, phone, is_artisan))
            
            connection.commit()
            user_id = cursor.lastrowid
            
            # If artisan, create artisan profile with complete information
            if is_artisan:
                # Extract artisan-specific fields
                service_type = data.get('service_type', '').strip()
                experience_years = data.get('experience_years', 0)
                bio = data.get('bio', '').strip()
                location = data.get('location', '').strip()
                service_radius_km = data.get('service_radius', 10)
                license_number = data.get('license_number', '').strip() or None
                
                # Convert experience to integer
                try:
                    experience_years = int(experience_years) if experience_years else 0
                except (ValueError, TypeError):
                    experience_years = 0
                
                try:
                    service_radius_km = int(service_radius_km) if service_radius_km else 10
                except (ValueError, TypeError):
                    service_radius_km = 10
                
                # Get or create location
                location_id = None
                if location:
                    cursor.execute(
                        "SELECT id FROM locations WHERE city = %s LIMIT 1",
                        (location,)
                    )
                    location_row = cursor.fetchone()
                    if location_row:
                        location_id = location_row[0]
                    else:
                        # Create new location
                        cursor.execute(
                            "INSERT INTO locations (city) VALUES (%s)",
                            (location,)
                        )
                        connection.commit()
                        location_id = cursor.lastrowid
                
                # Insert artisan profile
                cursor.execute("""
                    INSERT INTO artisan_profiles (
                        user_id, bio, experience_years, location_id, 
                        license_number, service_radius_km
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (user_id, bio if bio else None, experience_years, location_id, license_number, service_radius_km))
                
                connection.commit()
                artisan_profile_id = cursor.lastrowid
                
                # Link service type if provided
                if service_type:
                    # Get or create the service
                    cursor.execute(
                        "SELECT id FROM services WHERE name = %s LIMIT 1",
                        (service_type,)
                    )
                    service_row = cursor.fetchone()
                    service_id = None
                    if service_row:
                        service_id = service_row[0]
                    else:
                        # Create service if it doesn't exist
                        cursor.execute(
                            "INSERT INTO services (name, category) VALUES (%s, %s)",
                            (service_type, 'Professional Services')
                        )
                        connection.commit()
                        service_id = cursor.lastrowid
                    
                    # Link artisan to service
                    cursor.execute("""
                        INSERT INTO artisan_services (artisan_id, service_id)
                        VALUES (%s, %s)
                    """, (artisan_profile_id, service_id))
                    connection.commit()
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Account created successfully",
                "user_id": user_id,
                "is_artisan": is_artisan
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": f"Registration failed: {str(e)}"}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    """Login user (works for both clients and artisans)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('email') or not data.get('password'):
            return jsonify({"status": "error", "message": "Email and password are required"}), 400
        
        email = data.get('email').strip().lower()
        password = data.get('password')
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Find user by email
            cursor.execute("""
                SELECT id, name, email, password, phone, profile_picture, is_artisan
                FROM users
                WHERE email = %s
            """, (email,))
            
            user = cursor.fetchone()
            
            if not user:
                return jsonify({"status": "error", "message": "Invalid email or password"}), 401
            
            user_id, name, user_email, password_hash, phone, profile_picture, is_artisan = user
            
            # Verify password
            if not verify_password(password, password_hash):
                return jsonify({"status": "error", "message": "Invalid email or password"}), 401
            
            # Get artisan details if user is artisan
            artisan_data = None
            if is_artisan:
                cursor.execute("""
                    SELECT id, bio, experience_years, rating, verified
                    FROM artisan_profiles
                    WHERE user_id = %s
                """, (user_id,))
                artisan = cursor.fetchone()
                if artisan:
                    artisan_id, bio, experience_years, rating, verified = artisan
                    artisan_data = {
                        "artisan_id": artisan_id,
                        "bio": bio,
                        "experience_years": experience_years,
                        "rating": float(rating) if rating else 0.0,
                        "verified": verified
                    }
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Login successful",
                "user": {
                    "id": user_id,
                    "name": name,
                    "email": user_email,
                    "phone": phone,
                    "profile_picture": profile_picture,
                    "is_artisan": is_artisan,
                    "artisan": artisan_data
                }
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": f"Login failed: {str(e)}"}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/user/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Get user details by ID"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("""
                SELECT id, name, email, phone, profile_picture, is_artisan, created_at
                FROM users
                WHERE id = %s
            """, (user_id,))
            
            user = cursor.fetchone()
            
            if not user:
                return jsonify({"status": "error", "message": "User not found"}), 404
            
            user_id, name, email, phone, profile_picture, is_artisan, created_at = user
            
            user_data = {
                "id": user_id,
                "name": name,
                "email": email,
                "phone": phone,
                "profile_picture": profile_picture,
                "is_artisan": is_artisan,
                "created_at": created_at.isoformat() if created_at else None
            }
            
            # Get artisan data if applicable
            if is_artisan:
                cursor.execute("""
                    SELECT id, bio, experience_years, rating, verified, company_name, 
                           business_registration_number, license_number, certification_details,
                           portfolio_url, availability_status, years_in_business, 
                           languages_spoken, service_radius_km, location_id, total_reviews
                    FROM artisan_profiles
                    WHERE user_id = %s
                """, (user_id,))
                artisan = cursor.fetchone()
                if artisan:
                    (artisan_id, bio, experience_years, rating, verified, company_name,
                     business_registration_number, license_number, certification_details,
                     portfolio_url, availability_status, years_in_business,
                     languages_spoken, service_radius_km, location_id, total_reviews) = artisan
                    
                    # Get primary service type
                    cursor.execute("""
                        SELECT s.name FROM services s
                        JOIN artisan_services a_s ON s.id = a_s.service_id
                        WHERE a_s.artisan_id = %s
                        LIMIT 1
                    """, (artisan_id,))
                    service_type_row = cursor.fetchone()
                    service_type = service_type_row[0] if service_type_row else None
                    
                    # Get certifications if table exists
                    certifications = []
                    try:
                        cursor.execute("""
                            SELECT id, certification_name, issuing_organization, issue_date, expiration_date
                            FROM certifications
                            WHERE artisan_id = %s
                            ORDER BY issue_date DESC
                        """, (artisan_id,))
                        certs = cursor.fetchall()
                        for cert in certs:
                            certifications.append({
                                "id": cert[0],
                                "name": cert[1],
                                "issuer": cert[2],
                                "issue_date": str(cert[3]) if cert[3] else None,
                                "expiry_date": str(cert[4]) if cert[4] else None
                            })
                    except:
                        # Table doesn't exist yet, that's ok
                        certifications = []
                    
                    user_data["artisan"] = {
                        "artisan_id": artisan_id,
                        "bio": bio,
                        "experience_years": experience_years,
                        "rating": float(rating) if rating else 0.0,
                        "verified": verified,
                        "company_name": company_name,
                        "business_registration_number": business_registration_number,
                        "license_number": license_number,
                        "certification_details": certification_details,
                        "portfolio_url": portfolio_url,
                        "availability_status": availability_status,
                        "years_in_business": years_in_business,
                        "languages_spoken": languages_spoken,
                        "service_radius_km": service_radius_km,
                        "location_id": location_id,
                        "total_reviews": total_reviews,
                        "service_type": service_type,
                        "certifications": certifications
                    }
            
            cursor.close()
            
            return jsonify({"status": "success", "user": user_data}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/user/<int:user_id>/password', methods=['PUT'])
def update_user_password(user_id):
    """Update user password"""
    try:
        data = request.get_json()
        
        if not data.get('current_password') or not data.get('new_password'):
            return jsonify({"status": "error", "message": "Current and new password are required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get current password hash
            cursor.execute("SELECT password FROM users WHERE id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "User not found"}), 404
            
            password_hash = result[0]
            
            # Verify current password
            if not verify_password(data['current_password'], password_hash):
                return jsonify({"status": "error", "message": "Current password is incorrect"}), 401
            
            # Hash new password
            new_password_hash = hash_password(data['new_password'])
            
            # Update password
            cursor.execute("""
                UPDATE users
                SET password = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """, (new_password_hash, user_id))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Password updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/user/<int:user_id>', methods=['PUT', 'DELETE'])
def update_user(user_id):
    """Update user information"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()

            if request.method == 'DELETE':
                cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
                connection.commit()
                deleted = cursor.rowcount
                cursor.close()
                if not deleted:
                    return jsonify({"status": "error", "message": "User not found"}), 404
                return jsonify({"status": "success", "message": "Account deleted"}), 200
            
            update_fields = []
            params = []
            
            # Update email only when it actually changes; phone-only edits do not need a password.
            if 'email' in data and data['email']:
                # Verify password if changing email
                cursor.execute("SELECT email, password FROM users WHERE id = %s", (user_id,))
                current_user = cursor.fetchone()
                if current_user and data['email'].strip().lower() == current_user[0].lower():
                    pass
                elif 'password' not in data:
                    return jsonify({"status": "error", "message": "Password required to change email"}), 400
                elif current_user and verify_password(data['password'], current_user[1]):
                    update_fields.append("email = %s")
                    params.append(data['email'].strip().lower())
                else:
                    return jsonify({"status": "error", "message": "Password is incorrect"}), 401
            
            # Update phone if provided
            if 'phone' in data:
                update_fields.append("phone = %s")
                params.append(data['phone'])
            
            # Update name if provided
            if 'name' in data:
                update_fields.append("name = %s")
                params.append(data['name'])

            for field in ('location_address', 'latitude', 'longitude'):
                if field in data:
                    update_fields.append(f"{field} = %s")
                    params.append(data[field])
            
            # Update profile_picture if provided
            if 'profile_picture' in data:
                profile_picture = data['profile_picture']
                if profile_picture and (not isinstance(profile_picture, str) or len(profile_picture) > 3_000_000):
                    return jsonify({"status": "error", "message": "Profile picture must be a valid image smaller than 2 MB"}), 400
                update_fields.append("profile_picture = %s")
                params.append(profile_picture)
            
            if update_fields:
                params.append(user_id)
                query = f"UPDATE users SET {', '.join(update_fields)}, updated_at = CURRENT_TIMESTAMP WHERE id = %s"
                cursor.execute(query, params)
                connection.commit()
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "User updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/user/<int:user_id>/profile-picture', methods=['POST'])
def upload_profile_picture(user_id):
    """Save a profile image and persist its public frontend URL."""
    image = request.files.get('image')
    if not image or not image.mimetype.startswith('image/'):
        return jsonify({"status": "error", "message": "Please select an image file"}), 400

    image_bytes = image.read()
    if len(image_bytes) > 2 * 1024 * 1024:
        return jsonify({"status": "error", "message": "Profile picture must be smaller than 2 MB"}), 400

    extension = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp'}.get(image.mimetype)
    if not extension:
        return jsonify({"status": "error", "message": "Only JPG, PNG, and WebP images are supported"}), 400

    upload_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'frontend', 'uploads'))
    os.makedirs(upload_dir, exist_ok=True)
    filename = f"profile_{user_id}_{secrets.token_hex(8)}.{extension}"
    filepath = os.path.join(upload_dir, filename)
    with open(filepath, 'wb') as uploaded_file:
        uploaded_file.write(image_bytes)

    profile_picture = f"/uploads/{filename}"
    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        cursor.execute("UPDATE users SET profile_picture = %s, updated_at = CURRENT_TIMESTAMP WHERE id = %s", (profile_picture, user_id))
        connection.commit()
        if cursor.rowcount == 0:
            return jsonify({"status": "error", "message": "User not found"}), 404
        cursor.close()
        return jsonify({"status": "success", "profile_picture": profile_picture}), 200
    except Exception as error:
        connection.rollback()
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

# ==================== ARTISAN ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/bookings', methods=['GET'])
def get_artisan_bookings(user_id):
    """Get all bookings for an artisan (by user_id)"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "bookings": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get bookings for this artisan
            cursor.execute("""
                SELECT b.id, b.customer_id, u.name as customer_name, s.name as service_name,
                       b.booking_date, b.booking_time, b.status, b.notes,
                       b.client_location_address, b.client_latitude, b.client_longitude,
                       b.distance_km, b.estimated_travel_minutes, b.estimated_fuel_cost
                FROM bookings b
                JOIN users u ON b.customer_id = u.id
                JOIN services s ON b.service_id = s.id
                WHERE b.artisan_id = %s
                ORDER BY b.booking_date DESC, b.booking_time DESC
            """, (artisan_id,))
            
            bookings = cursor.fetchall()
            bookings_list = []
            
            for booking in bookings:
                booking_id, customer_id, customer_name, service_name, booking_date, booking_time, status, notes, location_address, client_latitude, client_longitude, distance_km, travel_minutes, fuel_cost = booking
                bookings_list.append({
                    "id": booking_id,
                    "customer_id": customer_id,
                    "customer_name": customer_name,
                    "service_name": service_name,
                    "date": str(booking_date) if booking_date else "",
                    "time": str(booking_time) if booking_time else "",
                    "status": status,
                    "notes": notes,
                    "client_location_address": location_address,
                    "client_latitude": float(client_latitude) if client_latitude is not None else None,
                    "client_longitude": float(client_longitude) if client_longitude is not None else None,
                    "distance_km": float(distance_km) if distance_km is not None else None,
                    "estimated_travel_minutes": travel_minutes,
                    "estimated_fuel_cost": float(fuel_cost) if fuel_cost is not None else None
                })
            
            cursor.close()
            return jsonify({"status": "success", "bookings": bookings_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/services', methods=['GET'])
def get_artisan_services(user_id):
    """Get all services for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "services": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get services for this artisan
            cursor.execute("""
                SELECT s.id, s.name, s.description, ars.hourly_rate
                FROM artisan_services ars
                JOIN services s ON ars.service_id = s.id
                WHERE ars.artisan_id = %s
            """, (artisan_id,))
            
            services = cursor.fetchall()
            services_list = []
            
            for service in services:
                service_id, name, description, hourly_rate = service
                services_list.append({
                    "id": service_id,
                    "name": name,
                    "description": description,
                    "hourly_rate": float(hourly_rate) if hourly_rate else 0.0
                })
            
            cursor.close()
            return jsonify({"status": "success", "services": services_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/reviews', methods=['GET'])
def get_artisan_reviews(user_id):
    """Get all reviews for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "reviews": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get reviews for this artisan
            cursor.execute("""
                  SELECT r.id, r.customer_id, u.name as customer_name, r.rating, r.comment,
                      r.artisan_reply, r.artisan_reply_at, r.created_at
                FROM reviews r
                JOIN users u ON r.customer_id = u.id
                WHERE r.artisan_id = %s
                ORDER BY r.created_at DESC
            """, (artisan_id,))
            
            reviews = cursor.fetchall()
            reviews_list = []
            
            for review in reviews:
                review_id, customer_id, customer_name, rating, comment, artisan_reply, artisan_reply_at, created_at = review
                reviews_list.append({
                    "id": review_id,
                    "customer_id": customer_id,
                    "customer_name": customer_name,
                    "rating": float(rating) if rating else 0.0,
                    "comment": comment,
                    "artisan_reply": artisan_reply,
                    "artisan_reply_at": artisan_reply_at.isoformat() if artisan_reply_at else None,
                    "created_at": str(created_at) if created_at else ""
                })
            
            cursor.close()
            return jsonify({"status": "success", "reviews": reviews_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan-profile/<int:artisan_id>/reviews', methods=['GET'])
def get_artisan_profile_reviews(artisan_id):
    """Get public reviews for an artisan profile ID."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            cursor.execute("""
                SELECT r.id, u.name, r.rating, r.comment, r.artisan_reply, r.artisan_reply_at, r.created_at
                FROM reviews r JOIN users u ON r.customer_id = u.id
                WHERE r.artisan_id = %s ORDER BY r.created_at DESC
            """, (artisan_id,))
            reviews = [{"id": row[0], "customer_name": row[1], "rating": float(row[2]), "comment": row[3] or '', "artisan_reply": row[4] or '', "artisan_reply_at": row[5].isoformat() if row[5] else None, "created_at": row[6].isoformat() if row[6] else ''} for row in cursor.fetchall()]
            cursor.close()
            return jsonify({"status": "success", "reviews": reviews}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan-profile/<int:artisan_id>', methods=['GET'])
def get_public_artisan_profile(artisan_id):
    """Return the public profile used by the client artisan timeline page."""
    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT ap.id, ap.user_id, u.name, u.profile_picture, ap.bio,
                   ap.experience_years, ap.rating, ap.total_reviews, ap.verified,
                   ap.company_name, ap.availability_status, ap.service_radius_km,
                   ap.response_time_minutes, ap.profile_visible,
                   l.city, l.district, l.country
            FROM artisan_profiles ap
            JOIN users u ON ap.user_id = u.id
            LEFT JOIN locations l ON ap.location_id = l.id
            WHERE ap.id = %s AND ap.profile_visible = TRUE
        """, (artisan_id,))
        profile = cursor.fetchone()
        if not profile:
            return jsonify({"status": "error", "message": "Artisan profile not found"}), 404

        cursor.execute("""
            SELECT s.id, s.name, s.description, asv.hourly_rate
            FROM artisan_services asv
            JOIN services s ON asv.service_id = s.id
            WHERE asv.artisan_id = %s
            ORDER BY s.name ASC
        """, (artisan_id,))
        services = [{
            "id": row[0], "name": row[1], "description": row[2] or "",
            "hourly_rate": float(row[3]) if row[3] is not None else None
        } for row in cursor.fetchall()]
        cursor.close()

        location_parts = [value for value in profile[14:17] if value]
        return jsonify({
            "status": "success",
            "profile": {
                "id": profile[0], "user_id": profile[1], "name": profile[2],
                "profile_picture": profile[3], "bio": profile[4] or "",
                "experience_years": int(profile[5]) if profile[5] is not None else 0,
                "rating": float(profile[6]) if profile[6] is not None else 0.0,
                "total_reviews": int(profile[7]) if profile[7] is not None else 0,
                "verified": bool(profile[8]), "company_name": profile[9] or "",
                "availability_status": profile[10] or "available",
                "service_radius_km": profile[11] or 15,
                "response_time_minutes": profile[12] or 60,
                "location": ", ".join(location_parts), "services": services
            }
        }), 200
    except Exception as error:
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

@app.route('/api/artisan-profile/<int:artisan_id>/unavailable-dates', methods=['GET'])
def get_public_artisan_unavailable_dates(artisan_id):
    """Return unavailable date ranges so clients can pre-check a booking date."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            cursor.execute("""
                SELECT start_date, end_date, reason
                FROM unavailable_dates
                WHERE artisan_id = %s
                ORDER BY start_date ASC
            """, (artisan_id,))
            dates = [{
                "start_date": str(row[0]),
                "end_date": str(row[1]),
                "reason": row[2] or 'unavailable'
            } for row in cursor.fetchall()]
            cursor.close()
            return jsonify({"status": "success", "unavailable_dates": dates}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/reviews/<int:review_id>/reply', methods=['PUT'])
def reply_to_review(user_id, review_id):
    """Save a reply from the artisan who owns the review."""
    try:
        reply = (request.get_json() or {}).get('reply', '').strip()
        if not reply:
            return jsonify({"status": "error", "message": "Reply is required"}), 400
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            cursor.execute("""
                UPDATE reviews r
                JOIN artisan_profiles ap ON r.artisan_id = ap.id
                SET r.artisan_reply = %s, r.artisan_reply_at = CURRENT_TIMESTAMP
                WHERE r.id = %s AND ap.user_id = %s
            """, (reply, review_id, user_id))
            if cursor.rowcount == 0:
                return jsonify({"status": "error", "message": "Review not found"}), 404
            connection.commit()
            cursor.close()
            return jsonify({"status": "success", "message": "Reply saved"}), 200
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== CLIENT ENDPOINTS ====================

@app.route('/api/client/<int:user_id>/bookings', methods=['GET'])
def get_client_bookings(user_id):
    """Get all bookings for a client"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get bookings for this client
            cursor.execute("""
                SELECT b.id, b.artisan_id, ap.user_id, u.name as artisan_name, s.name as service_name,
                       b.booking_date, b.booking_time, b.status, b.notes
                FROM bookings b
                JOIN artisan_profiles ap ON b.artisan_id = ap.id
                JOIN users u ON ap.user_id = u.id
                JOIN services s ON b.service_id = s.id
                WHERE b.customer_id = %s
                ORDER BY b.booking_date DESC, b.booking_time DESC
            """, (user_id,))
            
            bookings = cursor.fetchall()
            bookings_list = []
            
            for booking in bookings:
                booking_id, artisan_id, artisan_user_id, artisan_name, service_name, booking_date, booking_time, status, notes = booking
                bookings_list.append({
                    "id": booking_id,
                    "artisan_id": artisan_id,
                    "artisan_user_id": artisan_user_id,
                    "artisan_name": artisan_name,
                    "service_name": service_name,
                    "date": str(booking_date) if booking_date else "",
                    "time": str(booking_time) if booking_time else "",
                    "status": status,
                    "notes": notes
                })
            
            cursor.close()
            return jsonify({"status": "success", "bookings": bookings_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/client/<int:user_id>/reviews', methods=['POST'])
def create_client_review(user_id):
    """Create a review for a completed client booking."""
    try:
        data = request.get_json() or {}
        booking_id = data.get('booking_id')
        rating = int(data.get('rating', 0))
        comment = (data.get('comment') or '').strip()
        if not booking_id or rating < 1 or rating > 5:
            return jsonify({"status": "error", "message": "A valid booking and rating from 1 to 5 are required"}), 400

        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            cursor.execute("""
                SELECT artisan_id FROM bookings
                WHERE id = %s AND customer_id = %s AND status = 'completed'
            """, (booking_id, user_id))
            booking = cursor.fetchone()
            if not booking:
                return jsonify({"status": "error", "message": "Only completed bookings can be reviewed"}), 400
            artisan_id = booking[0]
            cursor.execute("SELECT id FROM reviews WHERE booking_id = %s", (booking_id,))
            if cursor.fetchone():
                return jsonify({"status": "error", "message": "This booking has already been reviewed"}), 400
            cursor.execute("""
                INSERT INTO reviews (artisan_id, customer_id, booking_id, rating, comment)
                VALUES (%s, %s, %s, %s, %s)
            """, (artisan_id, user_id, booking_id, rating, comment))
            cursor.execute("""
                UPDATE artisan_profiles ap
                SET ap.total_reviews = (SELECT COUNT(*) FROM reviews WHERE artisan_id = ap.id),
                    ap.rating = (SELECT AVG(rating) FROM reviews WHERE artisan_id = ap.id)
                WHERE ap.id = %s
            """, (artisan_id,))
            connection.commit()
            cursor.close()
            return jsonify({"status": "success", "message": "Review submitted"}), 201
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/client/<int:user_id>/payment-methods', methods=['GET', 'POST'])
def client_payment_methods(user_id):
    """List or add M-Pesa, EcoCash, or card payment methods."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            if request.method == 'POST':
                data = request.get_json() or {}
                method_type = data.get('method_type', '').lower()
                reference = (data.get('account_reference') or '').strip()
                if method_type not in ('mpesa', 'ecocash', 'card') or not reference:
                    return jsonify({"status": "error", "message": "Choose M-Pesa, EcoCash, or Card and provide account details"}), 400
                cursor.execute("""
                    INSERT INTO client_payment_methods (user_id, method_type, account_label, account_reference, is_default)
                    VALUES (%s, %s, %s, %s, %s)
                """, (user_id, method_type, data.get('account_label'), reference, bool(data.get('is_default', False))))
                connection.commit()
            cursor.execute("""
                SELECT id, method_type, account_label, account_reference, is_default
                FROM client_payment_methods WHERE user_id = %s ORDER BY created_at DESC
            """, (user_id,))
            methods = [{"id": row[0], "method_type": row[1], "account_label": row[2], "account_reference": row[3], "is_default": bool(row[4])} for row in cursor.fetchall()]
            cursor.close()
            return jsonify({"status": "success", "payment_methods": methods}), 200
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/client/<int:user_id>/settings', methods=['GET', 'PUT'])
def client_settings(user_id):
    """Read or update client notification and privacy settings."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            if request.method == 'PUT':
                data = request.get_json() or {}
                cursor.execute("""
                    INSERT INTO client_settings (user_id, booking_notifications, message_notifications, profile_visibility)
                    VALUES (%s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE booking_notifications = VALUES(booking_notifications), message_notifications = VALUES(message_notifications), profile_visibility = VALUES(profile_visibility)
                """, (user_id, bool(data.get('booking_notifications', True)), bool(data.get('message_notifications', True)), bool(data.get('profile_visibility', True))))
                connection.commit()
            cursor.execute("SELECT booking_notifications, message_notifications, profile_visibility FROM client_settings WHERE user_id = %s", (user_id,))
            row = cursor.fetchone() or (True, True, True)
            cursor.close()
            return jsonify({"status": "success", "settings": {"booking_notifications": bool(row[0]), "message_notifications": bool(row[1]), "profile_visibility": bool(row[2])}}), 200
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== CLIENT PAYMENT ENDPOINTS ====================

@app.route('/api/client/<int:user_id>/payments', methods=['GET'])
def get_client_payments(user_id):
    """Get payment records for a client with booking artisan details."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500

        try:
            cursor = connection.cursor()
            cursor.execute("""
                SELECT b.id, b.id, b.artisan_id, u.name, s.name,
                      COALESCE(MAX(ars.hourly_rate), 0), COALESCE(p.status, b.status), b.updated_at
                FROM bookings b
                JOIN artisan_profiles ap ON b.artisan_id = ap.id
                JOIN users u ON ap.user_id = u.id
                JOIN services s ON b.service_id = s.id
                LEFT JOIN artisan_services ars ON ars.artisan_id = b.artisan_id
                    AND ars.service_id = b.service_id
                LEFT JOIN payments p ON p.booking_id = b.id
                WHERE b.customer_id = %s AND b.status IN ('completed', 'paid')
                GROUP BY b.id, b.artisan_id, u.name, s.name, b.status, b.updated_at
                ORDER BY b.updated_at DESC
            """, (user_id,))
            payments = []
            for row in cursor.fetchall():
                payments.append({
                    "id": row[0],
                    "booking_id": row[1],
                    "artisan_id": row[2],
                    "artisan_name": row[3],
                    "service_name": row[4],
                    "amount": float(row[5]) if row[5] is not None else 0.0,
                    "status": row[6],
                    "created_at": row[7].isoformat() if row[7] else None
                })
            cursor.close()
            return jsonify({"status": "success", "payments": payments}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/client/<int:user_id>/bookings/<int:booking_id>/pay', methods=['POST'])
def pay_completed_booking(user_id, booking_id):
    """Record a client payment for an owned completed booking."""
    data = request.get_json(silent=True) or {}
    payment_method_id = data.get('payment_method_id')
    connection = get_db_connection()
    if connection is None:
        return jsonify({"status": "error", "message": "Database connection failed"}), 500
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT b.id, b.artisan_id, b.status, COALESCE(MAX(ars.hourly_rate), 0)
            FROM bookings b
            LEFT JOIN artisan_services ars ON ars.artisan_id = b.artisan_id AND ars.service_id = b.service_id
            WHERE b.id = %s AND b.customer_id = %s
            GROUP BY b.id, b.artisan_id, b.status
        """, (booking_id, user_id))
        booking = cursor.fetchone()
        if not booking:
            return jsonify({"status": "error", "message": "Booking not found"}), 404
        if booking[2] not in ('completed', 'paid'):
            return jsonify({"status": "error", "message": "Only completed bookings can be paid"}), 400
        if payment_method_id:
            cursor.execute("SELECT id FROM client_payment_methods WHERE id = %s AND user_id = %s", (payment_method_id, user_id))
            if not cursor.fetchone():
                return jsonify({"status": "error", "message": "Payment method not found"}), 400
        cursor.execute("""
            INSERT INTO payments (booking_id, customer_id, artisan_id, amount, status)
            VALUES (%s, %s, %s, %s, 'paid')
            ON DUPLICATE KEY UPDATE status = 'paid', amount = VALUES(amount)
        """, (booking_id, user_id, booking[1], booking[3] or 0,))
        cursor.execute("UPDATE bookings SET status = 'paid', updated_at = CURRENT_TIMESTAMP WHERE id = %s", (booking_id,))
        cursor.execute("SELECT u.id FROM artisan_profiles ap JOIN users u ON ap.user_id = u.id WHERE ap.id = %s", (booking[1],))
        artisan_user = cursor.fetchone()
        if artisan_user:
            create_notification(cursor, artisan_user[0], 'payment', 'Payment received', f'Payment for booking #{booking_id} has been received.', booking_id)
        connection.commit()
        cursor.close()
        return jsonify({"status": "success", "message": "Payment confirmed", "booking_id": booking_id}), 200
    except Exception as error:
        connection.rollback()
        return jsonify({"status": "error", "message": str(error)}), 500
    finally:
        close_db_connection(connection)

# ==================== SEARCH AND DISCOVERY ENDPOINTS ====================

@app.route('/api/artisans', methods=['GET'])
def get_all_artisans():
    """Get all artisans with their performance metrics"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get all artisans with their basic profile info
            cursor.execute("""
                SELECT ap.id, u.name, ap.bio, ap.hourly_rate, ap.rating, ap.total_reviews,
                       ap.profile_picture, ap.response_time_minutes, ap.is_premium,
                       GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') as service_types,
                       ap.availability_status
                FROM artisan_profiles ap
                JOIN users u ON ap.user_id = u.id
                LEFT JOIN artisan_services asvc ON ap.id = asvc.artisan_id
                LEFT JOIN services s ON asvc.service_id = s.id
                WHERE ap.availability_status = 'available'
                GROUP BY ap.id, u.name, ap.bio, ap.hourly_rate, ap.rating, ap.total_reviews,
                         ap.profile_picture, ap.response_time_minutes, ap.is_premium, ap.availability_status
                ORDER BY ap.rating DESC, ap.total_reviews DESC
            """)
            
            artisans = cursor.fetchall()
            artisans_list = []
            
            for artisan in artisans:
                artisan_id, name, bio, hourly_rate, rating, total_reviews, profile_picture, response_time, is_premium, service_types, availability = artisan
                artisans_list.append({
                    "id": artisan_id,
                    "name": name,
                    "bio": bio or "Professional service provider",
                    "hourly_rate": float(hourly_rate) if hourly_rate else 75.00,
                    "rating": float(rating) if rating else 4.5,
                    "total_reviews": int(total_reviews) if total_reviews else 0,
                    "profile_picture": profile_picture or "https://via.placeholder.com/150",
                    "response_time_minutes": int(response_time) if response_time else 24,
                    "is_premium": bool(is_premium),
                    "service_type": service_types or "General Services",
                    "availability_status": availability
                })
            
            cursor.close()
            return jsonify({
                "status": "success",
                "artisans": artisans_list,
                "total": len(artisans_list)
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/services', methods=['GET'])
def get_all_services():
    """Get all available services"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get all services with count of artisans offering them
            cursor.execute("""
                SELECT s.id, s.name, s.description, s.category,
                       COUNT(DISTINCT asvc.artisan_id) as artisan_count,
                       AVG(asvc.hourly_rate) as avg_rate
                FROM services s
                LEFT JOIN artisan_services asvc ON s.id = asvc.service_id
                LEFT JOIN artisan_profiles ap ON asvc.artisan_id = ap.id
                WHERE ap.availability_status = 'available' OR ap.id IS NULL
                GROUP BY s.id, s.name, s.description, s.category
                ORDER BY artisan_count DESC, s.name ASC
            """)
            
            services = cursor.fetchall()
            services_list = []
            
            for service in services:
                service_id, name, description, category, artisan_count, avg_rate = service
                services_list.append({
                    "id": service_id,
                    "name": name,
                    "description": description or "",
                    "category": category or "General",
                    "artisan_count": int(artisan_count) if artisan_count else 0,
                    "average_rate": float(avg_rate) if avg_rate else 0
                })
            
            cursor.close()
            return jsonify({
                "status": "success",
                "services": services_list,
                "total": len(services_list)
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== SEARCH ENDPOINTS ====================

@app.route('/api/search/artisans', methods=['GET'])
def search_artisans():
    """Search and filter artisans by service type, location, rating, price, and keywords"""
    try:
        # Get query parameters
        service_type = request.args.get('service_type', '').strip()
        location = request.args.get('location', '').strip()
        rating = request.args.get('min_rating', '').strip()
        price_min = request.args.get('price_min', '').strip()
        price_max = request.args.get('price_max', '').strip()
        keyword = request.args.get('keyword', '').strip()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Build dynamic SQL query with proper joins and HAVING clause for aggregates
            query = """
                SELECT DISTINCT ap.id, u.id, u.name, ap.bio, ap.experience_years, MAX(asvc.hourly_rate) as hourly_rate, ap.rating, ap.total_reviews,
                       u.profile_picture, ap.response_time_minutes,
                       GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') as service_types,
                       ap.availability_status, l.city, l.district, l.country
                FROM artisan_profiles ap
                JOIN users u ON ap.user_id = u.id
                LEFT JOIN artisan_services asvc ON ap.id = asvc.artisan_id
                LEFT JOIN services s ON asvc.service_id = s.id
                LEFT JOIN locations l ON ap.location_id = l.id
                WHERE ap.availability_status = 'available'
            """
            
            params = []
            having_conditions = []
            having_params = []
            
            # Add service type filter
            if service_type:
                query += " AND (LOWER(s.name) LIKE %s OR LOWER(ap.bio) LIKE %s)"
                params.append(f"%{service_type}%")
                params.append(f"%{service_type}%")
            
            # Add location filter
            if location:
                query += " AND (LOWER(l.city) LIKE %s OR LOWER(l.district) LIKE %s OR LOWER(u.name) LIKE %s)"
                params.append(f"%{location}%")
                params.append(f"%{location}%")
                params.append(f"%{location}%")
            
            # Add rating filter
            if rating:
                try:
                    min_rating = float(rating)
                    query += " AND ap.rating >= %s"
                    params.append(min_rating)
                except ValueError:
                    pass
            
            # Add keyword search
            if keyword:
                query += " AND (LOWER(u.name) LIKE %s OR LOWER(ap.bio) LIKE %s OR LOWER(s.name) LIKE %s)"
                params.append(f"%{keyword}%")
                params.append(f"%{keyword}%")
                params.append(f"%{keyword}%")
            
            # Add GROUP BY clause before HAVING
            query += """
                GROUP BY ap.id, u.id, u.name, ap.bio, ap.experience_years, ap.rating, ap.total_reviews,
                         u.profile_picture, ap.response_time_minutes,
                         ap.availability_status, l.city, l.district, l.country
            """
            
            # Add price range filter to HAVING clause
            if price_min:
                try:
                    min_price = float(price_min)
                    having_conditions.append("MAX(asvc.hourly_rate) >= %s")
                    having_params.append(min_price)
                except ValueError:
                    pass
            
            if price_max:
                try:
                    max_price = float(price_max)
                    having_conditions.append("MAX(asvc.hourly_rate) <= %s")
                    having_params.append(max_price)
                except ValueError:
                    pass
            
            if having_conditions:
                query += " HAVING " + " AND ".join(having_conditions)
                params.extend(having_params)
            
            query += " ORDER BY ap.rating DESC, ap.total_reviews DESC LIMIT 100"
            
            cursor.execute(query, params)
            artisans = cursor.fetchall()
            artisans_list = []
            
            for artisan in artisans:
                artisan_id, user_id, name, bio, experience_years, hourly_rate, rating_val, total_reviews, profile_picture, response_time, service_types, availability, city, district, country = artisan
                artisans_list.append({
                    "id": artisan_id,
                    "user_id": user_id,
                    "name": name,
                    "bio": bio or "Professional service provider",
                    "experience_years": int(experience_years) if experience_years is not None else 0,
                    "hourly_rate": float(hourly_rate) if hourly_rate else 75.00,
                    "rating": float(rating_val) if rating_val else 4.5,
                    "total_reviews": int(total_reviews) if total_reviews else 0,
                    "profile_picture": profile_picture or "https://via.placeholder.com/150",
                    "response_time_minutes": int(response_time) if response_time else 24,
                    "service_type": service_types or "General Services",
                    "availability_status": availability,
                    "location": f"{city}, {district}, {country}" if all([city, district, country]) else f"{city}, {country}" if all([city, country]) else city or "Location not specified"
                })
            
            cursor.close()
            return jsonify({
                "status": "success",
                "artisans": artisans_list,
                "total": len(artisans_list)
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/search/by-service/<service_type>', methods=['GET'])
def search_by_service_type(service_type):
    """Get all artisans and services for a specific service type"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get service by name
            cursor.execute("""
                SELECT id, name, description, category FROM services
                WHERE LOWER(name) LIKE %s
            """, (f"%{service_type}%",))
            
            service_result = cursor.fetchone()
            
            if not service_result:
                # Return empty result if service not found
                return jsonify({
                    "status": "success",
                    "service": None,
                    "artisans": [],
                    "total": 0
                }), 200
            
            service_id, name, description, category = service_result
            
            # Get all artisans offering this service with proper hourly rate from artisan_services
            cursor.execute("""
                SELECT ap.id, u.name, ap.bio, asvc.hourly_rate, ap.rating, ap.total_reviews,
                       u.profile_picture, ap.response_time_minutes,
                       ap.availability_status, l.city, l.district, l.country
                FROM artisan_profiles ap
                JOIN users u ON ap.user_id = u.id
                JOIN artisan_services asvc ON ap.id = asvc.artisan_id
                JOIN services s ON asvc.service_id = s.id
                LEFT JOIN locations l ON ap.location_id = l.id
                WHERE s.id = %s AND ap.availability_status = 'available'
                ORDER BY ap.rating DESC, ap.total_reviews DESC
            """, (service_id,))
            
            artisans = cursor.fetchall()
            artisans_list = []
            
            for artisan in artisans:
                artisan_id, artisan_name, bio, hourly_rate, rating_val, total_reviews, profile_picture, response_time, availability, city, district, country = artisan
                artisans_list.append({
                    "id": artisan_id,
                    "name": artisan_name,
                    "bio": bio or "Professional service provider",
                    "hourly_rate": float(hourly_rate) if hourly_rate else 75.00,
                    "rating": float(rating_val) if rating_val else 4.5,
                    "total_reviews": int(total_reviews) if total_reviews else 0,
                    "profile_picture": profile_picture or "https://via.placeholder.com/150",
                    "response_time_minutes": int(response_time) if response_time else 24,
                    "availability_status": availability,
                    "service_type": name,
                    "location": f"{city}, {district}, {country}" if all([city, district, country]) else f"{city}, {country}" if all([city, country]) else city or "Location not specified"
                })
            
            cursor.close()
            return jsonify({
                "status": "success",
                "service": {
                    "id": service_id,
                    "name": name,
                    "description": description or "",
                    "category": category or "General"
                },
                "artisans": artisans_list,
                "total": len(artisans_list)
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/booking', methods=['POST'])
def create_booking():
    """Create a new booking"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['customer_id', 'artisan_id', 'booking_date', 'booking_time', 'service_id']
        if not all(field in data for field in required_fields):
            return jsonify({"status": "error", "message": "Missing required fields"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()

            cursor.execute("""
                SELECT reason FROM unavailable_dates
                WHERE artisan_id = %s AND %s BETWEEN start_date AND end_date
                LIMIT 1
            """, (data.get('artisan_id'), data.get('booking_date')))
            unavailable = cursor.fetchone()
            if unavailable:
                reason = unavailable[0] or 'unavailable'
                return jsonify({
                    "status": "error",
                    "message": f"This artisan is unavailable on {data.get('booking_date')} ({reason}). Please choose another date."
                }), 409

            cursor.execute("""
                SELECT u.latitude, u.longitude,
                       ap.workplace_latitude, ap.workplace_longitude,
                       ap.fuel_consumption_l_per_100km, ap.fuel_price_per_liter
                FROM users u
                JOIN artisan_profiles ap ON ap.id = %s
                WHERE u.id = %s
            """, (data.get('artisan_id'), data.get('customer_id')))
            travel_data = cursor.fetchone()
            client_latitude = data.get('client_latitude')
            client_longitude = data.get('client_longitude')
            if client_latitude is None and travel_data:
                client_latitude, client_longitude = travel_data[0], travel_data[1]
            artisan_latitude = travel_data[2] if travel_data else None
            artisan_longitude = travel_data[3] if travel_data else None
            distance_km, travel_minutes, fuel_cost = calculate_trip_estimate(
                artisan_latitude, artisan_longitude, client_latitude, client_longitude,
                travel_data[4] if travel_data else 8,
                travel_data[5] if travel_data else 0
            )
            
            # Insert booking
            cursor.execute("""
                INSERT INTO bookings (customer_id, artisan_id, service_id, booking_date, booking_time,
                                     notes, status, client_location_address, client_latitude, client_longitude,
                                     distance_km, estimated_travel_minutes, estimated_fuel_cost,
                                     created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, 'pending', %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """, (
                data.get('customer_id'),
                data.get('artisan_id'),
                data.get('service_id'),
                data.get('booking_date'),
                data.get('booking_time'),
                data.get('notes', ''), data.get('client_location_address'), client_latitude,
                client_longitude, distance_km, travel_minutes, fuel_cost
            ))
            
            booking_id = cursor.lastrowid
            cursor.execute("SELECT u.id, s.name FROM artisan_profiles ap JOIN users u ON ap.user_id = u.id JOIN services s ON s.id = %s WHERE ap.id = %s", (data.get('service_id'), data.get('artisan_id')))
            artisan_user = cursor.fetchone()
            if artisan_user:
                create_notification(cursor, artisan_user[0], 'booking', 'New booking request', f'You have a new {artisan_user[1]} booking request.', booking_id)
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Booking created successfully",
                "booking_id": booking_id,
                "travel": {
                    "distance_km": distance_km,
                    "estimated_travel_minutes": travel_minutes,
                    "estimated_fuel_cost": fuel_cost,
                    "directions_url": f"https://www.google.com/maps/dir/?api=1&origin={artisan_latitude},{artisan_longitude}&destination={client_latitude},{client_longitude}" if None not in (artisan_latitude, artisan_longitude, client_latitude, client_longitude) else None
                }
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== BOOKING MANAGEMENT ENDPOINTS ====================

@app.route('/api/booking/<int:booking_id>/status', methods=['PUT'])
def update_booking_status(booking_id):
    """Update booking status (accept, decline, complete, etc.)"""
    try:
        data = request.get_json()
        status = data.get('status')
        
        if not status or status not in ['pending', 'confirmed', 'in_progress', 'completed', 'declined', 'cancelled']:
            return jsonify({"status": "error", "message": "Invalid status"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("SELECT b.customer_id, s.name FROM bookings b JOIN services s ON b.service_id = s.id WHERE b.id = %s", (booking_id,))
            booking = cursor.fetchone()
            if not booking:
                return jsonify({"status": "error", "message": "Booking not found"}), 404

            # Update booking status
            cursor.execute("""
                UPDATE bookings
                SET status = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """, (status, booking_id))
            
            if status == 'confirmed':
                create_notification(cursor, booking[0], 'booking', 'Booking accepted', f'Your {booking[1]} booking has been accepted.', booking_id)
            elif status == 'declined':
                create_notification(cursor, booking[0], 'booking', 'Booking declined', f'Your {booking[1]} booking was declined.', booking_id)
            elif status == 'completed':
                create_notification(cursor, booking[0], 'booking', 'Service completed', f'Your {booking[1]} booking is marked complete.', booking_id)
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": f"Booking status updated to {status}",
                "booking_id": booking_id
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== ARTISAN PROFILE ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/profile', methods=['GET'])
def get_artisan_profile(user_id):
    """Get artisan profile information"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile with user and service information
            cursor.execute("""
                SELECT 
                    ap.id, 
                    ap.user_id,
                    u.name,
                    u.email,
                    u.phone,
                    ap.bio,
                    ap.experience_years,
                    ap.location_id,
                    l.city,
                    l.district,
                    l.country,
                    ap.license_number,
                    ap.service_radius_km,
                    ap.verified,
                    ap.rating,
                    ap.total_reviews,
                    ap.company_name,
                    ap.availability_status,
                    ap.response_time_minutes,
                    ap.buffer_time_minutes,
                    ap.is_premium,
                    ap.profile_visible,
                    ap.workplace_address,
                    ap.workplace_latitude,
                    ap.workplace_longitude,
                    ap.fuel_consumption_l_per_100km,
                    ap.fuel_price_per_liter
                FROM artisan_profiles ap
                JOIN users u ON ap.user_id = u.id
                LEFT JOIN locations l ON ap.location_id = l.id
                WHERE ap.user_id = %s
            """, (user_id,))
            
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]

            cursor.execute("SELECT profile_picture FROM users WHERE id = %s", (user_id,))
            profile_picture = cursor.fetchone()[0]
            
            # Get services offered
            cursor.execute("""
                SELECT s.id, s.name
                FROM artisan_services asv
                JOIN services s ON asv.service_id = s.id
                WHERE asv.artisan_id = %s
            """, (artisan_id,))
            
            services = [{"id": row[0], "name": row[1]} for row in cursor.fetchall()]
            
            cursor.close()
            
            # Build full location display from city, district, country
            city = result[8]
            district = result[9]
            country = result[10]
            
            if city and district and country:
                location_display = f"{city}, {district}, {country}"
            elif city and country:
                location_display = f"{city}, {country}"
            elif city:
                location_display = city
            else:
                location_display = None
            
            return jsonify({
                "status": "success",
                "profile": {
                    "id": result[0],
                    "user_id": result[1],
                    "name": result[2],
                    "email": result[3],
                    "phone": result[4],
                    "profile_picture": profile_picture,
                    "bio": result[5],
                    "experience_years": result[6],
                    "location_id": result[7],
                    "location": location_display,
                    "license_number": result[11],
                    "service_radius_km": result[12],
                    "verified": result[13],
                    "rating": float(result[14]) if result[14] else 0.0,
                    "total_reviews": result[15],
                    "company_name": result[16],
                    "availability_status": result[17],
                    "response_time_minutes": result[18] or 60,
                    "buffer_time_minutes": result[19] or 30,
                    "is_premium": bool(result[20]),
                    "profile_visible": bool(result[21]),
                    "workplace_address": result[22],
                    "workplace_latitude": float(result[23]) if result[23] is not None else None,
                    "workplace_longitude": float(result[24]) if result[24] is not None else None,
                    "fuel_consumption_l_per_100km": float(result[25]) if result[25] is not None else 8.0,
                    "fuel_price_per_liter": float(result[26]) if result[26] is not None else 0.0,
                    "services": services
                }
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/profile', methods=['PUT'])
def update_artisan_profile(user_id):
    """Update artisan profile information"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Update profile fields
            update_fields = []
            params = []
            
            if 'bio' in data:
                update_fields.append("bio = %s")
                params.append(data['bio'])
            
            if 'experience_years' in data:
                update_fields.append("experience_years = %s")
                params.append(data['experience_years'])
            
            if 'availability_status' in data:
                update_fields.append("availability_status = %s")
                params.append(data['availability_status'])
            
            if 'service_radius_km' in data:
                update_fields.append("service_radius_km = %s")
                params.append(data['service_radius_km'])
            
            if 'company_name' in data:
                update_fields.append("company_name = %s")
                params.append(data['company_name'])
            
            if 'license_number' in data:
                update_fields.append("license_number = %s")
                params.append(data['license_number'])
            
            if 'location_id' in data:
                update_fields.append("location_id = %s")
                params.append(data['location_id'])

            for field in ('workplace_address', 'workplace_latitude', 'workplace_longitude', 'fuel_consumption_l_per_100km', 'fuel_price_per_liter'):
                if field in data:
                    update_fields.append(f"{field} = %s")
                    params.append(data[field])
            
            if 'portfolio_url' in data:
                update_fields.append("portfolio_url = %s")
                params.append(data['portfolio_url'])
            
            if 'response_time_minutes' in data:
                update_fields.append("response_time_minutes = %s")
                params.append(data['response_time_minutes'])
            
            if 'buffer_time_minutes' in data:
                update_fields.append("buffer_time_minutes = %s")
                params.append(data['buffer_time_minutes'])

            if 'is_premium' in data:
                update_fields.append("is_premium = %s")
                params.append(bool(data['is_premium']))

            if 'profile_visible' in data:
                update_fields.append("profile_visible = %s")
                params.append(bool(data['profile_visible']))
            
            if update_fields:
                params.append(artisan_id)
                query = f"UPDATE artisan_profiles SET {', '.join(update_fields)}, updated_at = CURRENT_TIMESTAMP WHERE id = %s"
                cursor.execute(query, params)
                connection.commit()
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Profile updated successfully",
                "artisan_id": artisan_id
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== SERVICE MANAGEMENT ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/services', methods=['POST'])
def add_artisan_service(user_id):
    """Add a new service for an artisan"""
    try:
        data = request.get_json()
        
        if not data.get('service_name') or not data.get('hourly_rate'):
            return jsonify({"status": "error", "message": "Service name and rate are required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Check if service exists or create it
            service_name = data.get('service_name')
            cursor.execute("SELECT id FROM services WHERE name = %s", (service_name,))
            service = cursor.fetchone()
            
            if not service:
                # Create new service
                cursor.execute("""
                    INSERT INTO services (name, description, category)
                    VALUES (%s, %s, %s)
                """, (service_name, data.get('description', ''), data.get('category', '')))
                connection.commit()
                service_id = cursor.lastrowid
            else:
                service_id = service[0]
            
            # Add service to artisan
            cursor.execute("""
                INSERT INTO artisan_services (artisan_id, service_id, hourly_rate)
                VALUES (%s, %s, %s)
            """, (artisan_id, service_id, data.get('hourly_rate')))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Service added successfully",
                "service_id": service_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/service/<int:service_id>', methods=['PUT'])
def update_artisan_service(service_id):
    """Update an artisan service"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            if 'hourly_rate' in data:
                cursor.execute("""
                    UPDATE artisan_services
                    SET hourly_rate = %s
                    WHERE id = %s
                """, (data['hourly_rate'], service_id))
                connection.commit()
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Service updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/service/<int:service_id>', methods=['DELETE'])
def delete_artisan_service(service_id):
    """Delete an artisan service"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("DELETE FROM artisan_services WHERE id = %s", (service_id,))
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Service deleted successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== AVAILABILITY ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/availability', methods=['GET'])
def get_artisan_availability(user_id):
    """Get availability schedule for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "success", "availability": []}), 200
            
            artisan_id = result[0]
            
            # Get availability for this artisan if table exists
            availability_list = []
            try:
                cursor.execute("""
                    SELECT id, day_of_week, start_time, end_time
                    FROM artisan_availability
                    WHERE artisan_id = %s
                    ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
                """, (artisan_id,))
                
                availability = cursor.fetchall()
                
                for avail in availability:
                    availability_list.append({
                        "id": avail[0],
                        "day_of_week": avail[1],
                        "start_time": str(avail[2]) if avail[2] else None,
                        "end_time": str(avail[3]) if avail[3] else None
                    })
            except:
                # Table doesn't exist yet, that's ok - return empty list
                availability_list = []
            
            cursor.close()
            return jsonify({"status": "success", "availability": availability_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/availability', methods=['POST'])
def set_artisan_availability(user_id):
    """Set availability for an artisan"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Clear existing availability for this artisan
            cursor.execute("DELETE FROM artisan_availability WHERE artisan_id = %s", (artisan_id,))
            
            # Add new availability entries
            availability = data.get('availability', [])
            for slot in availability:
                cursor.execute("""
                    INSERT INTO artisan_availability (artisan_id, day_of_week, start_time, end_time)
                    VALUES (%s, %s, %s, %s)
                """, (artisan_id, slot.get('day'), slot.get('start_time'), slot.get('end_time')))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Availability updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== EARNINGS ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/earnings', methods=['GET'])
def get_artisan_earnings(user_id):
    """Calculate total earnings for an artisan from completed bookings"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "total_earnings": 0, "currency": "USD", "bookings": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get completed/paid bookings with their service rates
            cursor.execute("""
                SELECT b.id, b.customer_id, u.name as customer_name, s.name as service_name,
                       a_s.hourly_rate, b.booking_date, b.status
                FROM bookings b
                JOIN users u ON b.customer_id = u.id
                JOIN services s ON b.service_id = s.id
                JOIN artisan_services a_s ON a_s.artisan_id = %s AND a_s.service_id = b.service_id
                WHERE b.artisan_id = %s AND b.status IN ('completed', 'paid')
                ORDER BY b.booking_date DESC
            """, (artisan_id, artisan_id))
            
            bookings = cursor.fetchall()
            earnings_list = []
            total_earnings = 0.0
            
            for booking in bookings:
                booking_id, customer_id, customer_name, service_name, hourly_rate, booking_date, status = booking
                # Assume 1 hour per booking unless we have duration info
                earnings = float(hourly_rate) if hourly_rate else 0.0
                total_earnings += earnings
                
                earnings_list.append({
                    "booking_id": booking_id,
                    "customer_name": customer_name,
                    "service_name": service_name,
                    "amount": earnings,
                    "status": status,
                    "date": str(booking_date) if booking_date else ""
                })
            
            cursor.close()
            return jsonify({
                "status": "success",
                "total_earnings": round(total_earnings, 2),
                "currency": "USD",
                "earnings_list": earnings_list,
                "booking_count": len(earnings_list)
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== PAYOUT SETTINGS ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/payout-settings', methods=['GET'])
def get_payout_settings(user_id):
    """Get payout settings and methods for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Get payout settings
            cursor.execute("""
                SELECT payout_frequency, minimum_payout, auto_payout_enabled, 
                       last_payout_date, next_payout_date, primary_method_id
                FROM payout_settings
                WHERE artisan_id = %s
            """, (artisan_id,))
            
            settings_row = cursor.fetchone()
            
            # Get all payout methods
            cursor.execute("""
                SELECT id, payment_method, account_holder_name, account_number, 
                       account_type, bank_name, phone_number, email, is_primary, is_verified
                FROM payout_methods
                WHERE artisan_id = %s
                ORDER BY is_primary DESC, created_at DESC
            """, (artisan_id,))
            
            methods = []
            for row in cursor.fetchall():
                methods.append({
                    "id": row[0],
                    "payment_method": row[1],
                    "account_holder_name": row[2],
                    "account_number": "****" + (row[3][-4:] if row[3] and len(row[3]) > 4 else row[3] or ""),
                    "account_type": row[4],
                    "bank_name": row[5],
                    "phone_number": row[6],
                    "email": row[7],
                    "is_primary": row[8],
                    "is_verified": row[9]
                })
            
            cursor.close()
            
            settings = {}
            if settings_row:
                settings = {
                    "payout_frequency": settings_row[0] or "weekly",
                    "minimum_payout": float(settings_row[1]) if settings_row[1] else 10.00,
                    "auto_payout_enabled": settings_row[2],
                    "last_payout_date": str(settings_row[3]) if settings_row[3] else None,
                    "next_payout_date": str(settings_row[4]) if settings_row[4] else None,
                    "primary_method_id": settings_row[5]
                }
            else:
                settings = {
                    "payout_frequency": "weekly",
                    "minimum_payout": 10.00,
                    "auto_payout_enabled": True,
                    "last_payout_date": None,
                    "next_payout_date": None,
                    "primary_method_id": None
                }
            
            return jsonify({
                "status": "success",
                "settings": settings,
                "payout_methods": methods
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/artisan/<int:user_id>/payout-method', methods=['POST'])
def add_payout_method(user_id):
    """Add a new payout method for an artisan"""
    try:
        data = request.get_json()
        
        if not data.get('payment_method'):
            return jsonify({"status": "error", "message": "Payment method is required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Check if this is the first method
            cursor.execute("SELECT COUNT(*) FROM payout_methods WHERE artisan_id = %s", (artisan_id,))
            method_count = cursor.fetchone()[0]
            is_primary = method_count == 0
            
            # Insert new payout method
            cursor.execute("""
                INSERT INTO payout_methods 
                (artisan_id, payment_method, account_holder_name, account_number, 
                 account_type, bank_name, phone_number, email, is_primary)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                artisan_id,
                data.get('payment_method'),
                data.get('account_holder_name', ''),
                data.get('account_number', ''),
                data.get('account_type', ''),
                data.get('bank_name', ''),
                data.get('phone_number', ''),
                data.get('email', ''),
                is_primary
            ))
            
            method_id = cursor.lastrowid
            
            # If this is the first method, create default payout settings
            if is_primary:
                cursor.execute("""
                    INSERT INTO payout_settings (artisan_id, primary_method_id, payout_frequency, minimum_payout, auto_payout_enabled)
                    VALUES (%s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE primary_method_id = %s
                """, (artisan_id, method_id, 'weekly', 10.00, True, method_id))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Payout method added successfully",
                "method_id": method_id,
                "is_primary": is_primary
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/artisan/payout-method/<int:method_id>', methods=['PUT'])
def update_payout_method(method_id):
    """Update a payout method"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get current method details
            cursor.execute("SELECT artisan_id FROM payout_methods WHERE id = %s", (method_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Payout method not found"}), 404
            
            artisan_id = result[0]
            
            # Handle primary method change
            if data.get('is_primary') and data.get('is_primary') != False:
                cursor.execute("UPDATE payout_methods SET is_primary = FALSE WHERE artisan_id = %s", (artisan_id,))
                cursor.execute("UPDATE payout_methods SET is_primary = TRUE WHERE id = %s", (method_id,))
                cursor.execute("UPDATE payout_settings SET primary_method_id = %s WHERE artisan_id = %s", 
                             (method_id, artisan_id))
            
            # Update method fields
            update_fields = []
            params = []
            
            if 'account_holder_name' in data:
                update_fields.append("account_holder_name = %s")
                params.append(data['account_holder_name'])
            
            if 'account_number' in data:
                update_fields.append("account_number = %s")
                params.append(data['account_number'])
            
            if 'account_type' in data:
                update_fields.append("account_type = %s")
                params.append(data['account_type'])
            
            if 'bank_name' in data:
                update_fields.append("bank_name = %s")
                params.append(data['bank_name'])
            
            if 'phone_number' in data:
                update_fields.append("phone_number = %s")
                params.append(data['phone_number'])
            
            if 'email' in data:
                update_fields.append("email = %s")
                params.append(data['email'])
            
            if update_fields:
                params.append(method_id)
                query = f"UPDATE payout_methods SET {', '.join(update_fields)}, updated_at = CURRENT_TIMESTAMP WHERE id = %s"
                cursor.execute(query, params)
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Payout method updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/artisan/payout-method/<int:method_id>', methods=['DELETE'])
def delete_payout_method(method_id):
    """Delete a payout method"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get method details
            cursor.execute("SELECT artisan_id, is_primary FROM payout_methods WHERE id = %s", (method_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Payout method not found"}), 404
            
            artisan_id, is_primary = result
            
            # Delete the method
            cursor.execute("DELETE FROM payout_methods WHERE id = %s", (method_id,))
            
            # If this was primary, make another method primary
            if is_primary:
                cursor.execute("""
                    SELECT id FROM payout_methods
                    WHERE artisan_id = %s
                    ORDER BY created_at DESC
                    LIMIT 1
                """, (artisan_id,))
                
                next_method = cursor.fetchone()
                if next_method:
                    next_id = next_method[0]
                    cursor.execute("UPDATE payout_methods SET is_primary = TRUE WHERE id = %s", (next_id,))
                    cursor.execute("UPDATE payout_settings SET primary_method_id = %s WHERE artisan_id = %s", 
                                 (next_id, artisan_id))
                else:
                    cursor.execute("UPDATE payout_settings SET primary_method_id = NULL WHERE artisan_id = %s", 
                                 (artisan_id,))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Payout method deleted successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/artisan/<int:user_id>/payout-settings', methods=['PUT'])
def update_payout_settings(user_id):
    """Update payout settings"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Update settings
            cursor.execute("""
                UPDATE payout_settings
                SET payout_frequency = %s,
                    minimum_payout = %s,
                    auto_payout_enabled = %s,
                    updated_at = CURRENT_TIMESTAMP
                WHERE artisan_id = %s
            """, (
                data.get('payout_frequency', 'weekly'),
                data.get('minimum_payout', 10.00),
                data.get('auto_payout_enabled', True),
                artisan_id
            ))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Payout settings updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({"status": "error", "message": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({"status": "error", "message": "Internal server error"}), 500

# ==================== LOCATIONS ENDPOINTS ====================

@app.route('/api/locations', methods=['GET'])
def get_locations():
    """Get all available locations"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("""
                SELECT id, city, district, country
                FROM locations
                ORDER BY country, city
            """)
            
            locations = cursor.fetchall()
            locations_list = []
            
            for loc in locations:
                loc_id, city, district, country = loc
                locations_list.append({
                    "id": loc_id,
                    "city": city,
                    "district": district,
                    "country": country,
                    "display_name": f"{city}, {district}, {country}" if all([city, district, country]) else f"{city}, {country}"
                })
            
            cursor.close()
            return jsonify({"status": "success", "locations": locations_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/locations/search', methods=['GET'])
def search_locations():
    """Search for locations by city, district, or country"""
    try:
        query = request.args.get('q', '').strip().lower()
        
        if not query or len(query) < 2:
            return jsonify({"status": "error", "message": "Search query must be at least 2 characters"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Search in city, district, or country
            search_pattern = f"%{query}%"
            cursor.execute("""
                SELECT id, city, district, country
                FROM locations
                WHERE LOWER(city) LIKE %s 
                   OR LOWER(district) LIKE %s 
                   OR LOWER(country) LIKE %s
                ORDER BY country, city
                LIMIT 50
            """, (search_pattern, search_pattern, search_pattern))
            
            locations = cursor.fetchall()
            locations_list = []
            
            for loc in locations:
                loc_id, city, district, country = loc
                locations_list.append({
                    "id": loc_id,
                    "city": city,
                    "district": district,
                    "country": country,
                    "display_name": f"{city}, {district}, {country}" if all([city, district, country]) else f"{city}, {country}"
                })
            
            cursor.close()
            return jsonify({"status": "success", "locations": locations_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/locations', methods=['POST'])
def create_location():
    """Create a new location"""
    try:
        data = request.get_json()
        
        if not data.get('city') or not data.get('country'):
            return jsonify({"status": "error", "message": "City and country are required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Check if location already exists
            cursor.execute("""
                SELECT id FROM locations
                WHERE LOWER(city) = %s AND LOWER(country) = %s
            """, (data['city'].lower(), data['country'].lower()))
            
            existing = cursor.fetchone()
            if existing:
                cursor.close()
                return jsonify({
                    "status": "success",
                    "message": "Location already exists",
                    "location_id": existing[0]
                }), 200
            
            # Create new location
            cursor.execute("""
                INSERT INTO locations (city, district, country)
                VALUES (%s, %s, %s)
            """, (data['city'], data.get('district', ''), data['country']))
            
            connection.commit()
            location_id = cursor.lastrowid
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Location created successfully",
                "location_id": location_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== CERTIFICATIONS ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/certifications', methods=['GET'])
def get_artisan_certifications(user_id):
    """Get all certifications for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "certifications": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get certifications
            cursor.execute("""
                SELECT id, certification_name, issuing_organization, issue_date, expiration_date, certificate_number
                FROM certifications
                WHERE artisan_id = %s
                ORDER BY issue_date DESC
            """, (artisan_id,))
            
            certs = cursor.fetchall()
            certifications_list = []
            
            for cert in certs:
                certifications_list.append({
                    "id": cert[0],
                    "name": cert[1],
                    "issuer": cert[2],
                    "issue_date": str(cert[3]) if cert[3] else None,
                    "expiry_date": str(cert[4]) if cert[4] else None,
                    "certificate_number": cert[5]
                })
            
            cursor.close()
            return jsonify({"status": "success", "certifications": certifications_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/certifications', methods=['POST'])
def add_artisan_certification(user_id):
    """Add a certification for an artisan"""
    try:
        data = request.get_json()
        
        if not data.get('certification_name'):
            return jsonify({"status": "error", "message": "Certification name is required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Add certification
            cursor.execute("""
                INSERT INTO certifications (artisan_id, certification_name, issuing_organization, issue_date, expiration_date, certificate_number)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (artisan_id, data['certification_name'], data.get('issuing_organization', ''),
                  data.get('issue_date'), data.get('expiration_date'), data.get('certificate_number')))
            
            connection.commit()
            cert_id = cursor.lastrowid
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Certification added successfully",
                "certification_id": cert_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/certification/<int:cert_id>', methods=['PUT'])
def update_artisan_certification(cert_id):
    """Update an artisan certification"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Update certification fields
            update_fields = []
            params = []
            
            if 'certification_name' in data:
                update_fields.append("certification_name = %s")
                params.append(data['certification_name'])
            
            if 'issuing_organization' in data:
                update_fields.append("issuing_organization = %s")
                params.append(data['issuing_organization'])
            
            if 'issue_date' in data:
                update_fields.append("issue_date = %s")
                params.append(data['issue_date'])
            
            if 'expiration_date' in data:
                update_fields.append("expiration_date = %s")
                params.append(data['expiration_date'])
            
            if 'certificate_number' in data:
                update_fields.append("certificate_number = %s")
                params.append(data['certificate_number'])
            
            if update_fields:
                params.append(cert_id)
                query = f"UPDATE certifications SET {', '.join(update_fields)} WHERE id = %s"
                cursor.execute(query, params)
                connection.commit()
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Certification updated successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/certification/<int:cert_id>', methods=['DELETE'])
def delete_artisan_certification(cert_id):
    """Delete an artisan certification"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("DELETE FROM certifications WHERE id = %s", (cert_id,))
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Certification deleted successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== SKILLS ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/skills', methods=['GET'])
def get_artisan_skills(user_id):
    """Get all skills for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            artisan_profile = cursor.fetchone()
            
            if not artisan_profile:
                return jsonify({"status": "success", "skills": []}), 200
            
            artisan_id = artisan_profile[0]
            
            # Get skills
            cursor.execute("""
                SELECT s.id, as_table.id as artisan_skill_id, s.name, s.category, as_table.proficiency_level
                FROM artisan_skills as_table
                JOIN skills s ON as_table.skill_id = s.id
                WHERE as_table.artisan_id = %s
                ORDER BY s.name
            """, (artisan_id,))
            
            skills = cursor.fetchall()
            skills_list = []
            
            for skill in skills:
                skills_list.append({
                    "skill_id": skill[0],
                    "artisan_skill_id": skill[1],
                    "name": skill[2],
                    "category": skill[3],
                    "proficiency_level": skill[4]
                })
            
            cursor.close()
            return jsonify({"status": "success", "skills": skills_list}), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/skills', methods=['POST'])
def add_artisan_skill(user_id):
    """Add a skill for an artisan"""
    try:
        data = request.get_json()
        
        if not data.get('skill_name'):
            return jsonify({"status": "error", "message": "Skill name is required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Check if skill exists or create it
            skill_name = data.get('skill_name')
            cursor.execute("SELECT id FROM skills WHERE name = %s", (skill_name,))
            skill = cursor.fetchone()
            
            if not skill:
                # Create new skill
                cursor.execute("""
                    INSERT INTO skills (name, category, description)
                    VALUES (%s, %s, %s)
                """, (skill_name, data.get('category', ''), data.get('description', '')))
                connection.commit()
                skill_id = cursor.lastrowid
            else:
                skill_id = skill[0]
            
            # Add skill to artisan
            cursor.execute("""
                INSERT INTO artisan_skills (artisan_id, skill_id, proficiency_level)
                VALUES (%s, %s, %s)
            """, (artisan_id, skill_id, data.get('proficiency_level', 'intermediate')))
            
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Skill added successfully",
                "skill_id": skill_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/skill/<int:artisan_skill_id>', methods=['DELETE'])
def delete_artisan_skill(artisan_skill_id):
    """Delete an artisan skill"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("DELETE FROM artisan_skills WHERE id = %s", (artisan_skill_id,))
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Skill deleted successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== UNAVAILABLE DATES ENDPOINTS ====================

@app.route('/api/artisan/<int:user_id>/unavailable-dates', methods=['GET'])
def get_unavailable_dates(user_id):
    """Get all unavailable dates for an artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Get unavailable dates
            cursor.execute("""
                SELECT id, start_date, end_date, reason, created_at
                FROM unavailable_dates
                WHERE artisan_id = %s
                ORDER BY start_date ASC
            """, (artisan_id,))
            
            unavailable_dates = []
            for row in cursor.fetchall():
                unavailable_dates.append({
                    'id': row[0],
                    'start_date': str(row[1]),
                    'end_date': str(row[2]),
                    'reason': row[3],
                    'created_at': str(row[4])
                })
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "unavailable_dates": unavailable_dates
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/unavailable-dates', methods=['POST'])
def add_unavailable_date(user_id):
    """Add an unavailable date period for an artisan"""
    try:
        data = request.get_json()
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get artisan profile ID
            cursor.execute("SELECT id FROM artisan_profiles WHERE user_id = %s", (user_id,))
            result = cursor.fetchone()
            
            if not result:
                return jsonify({"status": "error", "message": "Artisan profile not found"}), 404
            
            artisan_id = result[0]
            
            # Insert unavailable date
            cursor.execute("""
                INSERT INTO unavailable_dates (artisan_id, start_date, end_date, reason)
                VALUES (%s, %s, %s, %s)
            """, (artisan_id, data.get('start_date'), data.get('end_date'), data.get('reason')))
            
            connection.commit()
            date_id = cursor.lastrowid
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Unavailable date added successfully",
                "id": date_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/unavailable-date/<int:date_id>', methods=['DELETE'])
def delete_unavailable_date(date_id):
    """Delete an unavailable date period"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("DELETE FROM unavailable_dates WHERE id = %s", (date_id,))
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Unavailable date deleted successfully"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== FAVORITES ENDPOINTS ====================

@app.route('/api/user/<int:user_id>/favorites', methods=['GET'])
def get_favorites(user_id):
    """Get all favorites for a user"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute("""
                SELECT 
                    f.id,
                    ap.id as artisan_id,
                    u.id as artisan_user_id,
                    u.name,
                    u.email,
                    u.phone,
                    u.profile_picture,
                    ap.rating,
                    ap.location_id,
                    l.city,
                    l.district,
                    l.country
                FROM favorites f
                JOIN artisan_profiles ap ON f.artisan_id = ap.id
                JOIN users u ON ap.user_id = u.id
                LEFT JOIN locations l ON ap.location_id = l.id
                WHERE f.user_id = %s
                ORDER BY f.created_at DESC
            """, (user_id,))
            
            results = cursor.fetchall()
            cursor.close()
            
            favorites = []
            for row in results:
                location = None
                if row[9] and row[10] and row[11]:
                    location = f"{row[9]}, {row[10]}, {row[11]}"
                elif row[9] and row[11]:
                    location = f"{row[9]}, {row[11]}"
                elif row[9]:
                    location = row[9]
                
                favorites.append({
                    "id": row[1],
                    "user_id": row[2],
                    "name": row[3],
                    "email": row[4],
                    "phone": row[5],
                    "profile_picture": row[6],
                    "rating": float(row[7]) if row[7] else 0.0,
                    "location": location
                })
            
            return jsonify({
                "status": "success",
                "favorites": favorites
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/user/<int:user_id>/favorites', methods=['POST'])
def add_favorite(user_id):
    """Add a favorite artisan"""
    try:
        data = request.get_json()
        artisan_id = data.get('artisan_id')
        
        if not artisan_id:
            return jsonify({"status": "error", "message": "artisan_id is required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Check if already favorited
            cursor.execute(
                "SELECT id FROM favorites WHERE user_id = %s AND artisan_id = %s",
                (user_id, artisan_id)
            )
            
            if cursor.fetchone():
                cursor.close()
                return jsonify({
                    "status": "error",
                    "message": "Already in favorites"
                }), 400
            
            # Add to favorites
            cursor.execute(
                "INSERT INTO favorites (user_id, artisan_id) VALUES (%s, %s)",
                (user_id, artisan_id)
            )
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Added to favorites"
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/user/<int:user_id>/favorites/<int:artisan_id>', methods=['DELETE'])
def remove_favorite(user_id, artisan_id):
    """Remove a favorite artisan"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute(
                "DELETE FROM favorites WHERE user_id = %s AND artisan_id = %s",
                (user_id, artisan_id)
            )
            connection.commit()
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Removed from favorites"
            }), 200
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ==================== MESSAGES ENDPOINTS ====================

@app.route('/api/user/<int:user_id>/messages', methods=['GET'])
def get_conversations(user_id):
    """Get all conversations for a user"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            # Get unique conversations (both as sender and recipient)
            cursor.execute("""
                SELECT DISTINCT
                    CASE 
                        WHEN sender_id = %s THEN recipient_id
                        ELSE sender_id
                    END as other_user_id,
                    MAX(created_at) as last_message_time
                FROM messages
                WHERE sender_id = %s OR recipient_id = %s
                GROUP BY other_user_id
                ORDER BY last_message_time DESC
            """, (user_id, user_id, user_id))
            
            conversations = []
            for row in cursor.fetchall():
                other_user_id = row[0]
                
                # Get other user info
                cursor.execute(
                    "SELECT id, name, email, profile_picture FROM users WHERE id = %s",
                    (other_user_id,)
                )
                user_info = cursor.fetchone()
                
                if user_info:
                    # Get last message
                    cursor.execute("""
                        SELECT content, sender_id, created_at FROM messages
                        WHERE (sender_id = %s AND recipient_id = %s)
                           OR (sender_id = %s AND recipient_id = %s)
                        ORDER BY created_at DESC
                        LIMIT 1
                    """, (user_id, other_user_id, other_user_id, user_id))
                    
                    last_msg = cursor.fetchone()
                    
                    cursor.execute("SELECT COUNT(*) FROM messages WHERE recipient_id = %s AND sender_id = %s AND is_read = FALSE", (user_id, other_user_id))
                    unread_count = cursor.fetchone()[0]
                    conversations.append({
                        "user_id": user_info[0],
                        "artisan_id": user_info[0],
                        "artisan_name": user_info[1],
                        "email": user_info[2],
                        "profile_picture": user_info[3],
                        "avatar": user_info[3],
                        "last_message": last_msg[0] if last_msg else "",
                        "timestamp": last_msg[2].isoformat() if last_msg else row[1].isoformat(),
                        "last_message_time": last_msg[2].isoformat() if last_msg else row[1].isoformat(),
                        "unread": unread_count > 0,
                        "unread_count": unread_count
                    })
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "messages": conversations
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/user/<int:user_id>/messages/<int:other_user_id>', methods=['GET', 'PUT'])
def get_conversation(user_id, other_user_id):
    """Get messages between two users"""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()

            if request.method == 'PUT':
                cursor.execute("""
                    UPDATE messages SET is_read = TRUE
                    WHERE sender_id = %s AND recipient_id = %s AND is_read = FALSE
                """, (other_user_id, user_id))
                cursor.execute("""
                    UPDATE notifications n
                    JOIN messages m ON n.entity_id = m.id
                    SET n.is_read = TRUE
                    WHERE n.user_id = %s AND n.type = 'message'
                      AND m.sender_id = %s AND m.recipient_id = %s
                """, (user_id, other_user_id, user_id))
                connection.commit()
            
            cursor.execute("""
                SELECT id, sender_id, content, created_at FROM messages
                WHERE (sender_id = %s AND recipient_id = %s)
                   OR (sender_id = %s AND recipient_id = %s)
                ORDER BY created_at ASC
            """, (user_id, other_user_id, other_user_id, user_id))
            
            messages = []
            for row in cursor.fetchall():
                messages.append({
                    "id": row[0],
                    "sender": "customer" if row[1] == user_id else "artisan",
                    "content": row[2],
                    "timestamp": row[3].isoformat()
                })
            
            cursor.close()
            
            return jsonify({
                "status": "success",
                "messages": messages
            }), 200
        
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/artisan/<int:user_id>/messages', methods=['GET'])
def get_artisan_messages(user_id):
    """Get an artisan's client conversations, newest conversation first."""
    try:
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        try:
            cursor = connection.cursor()
            cursor.execute("""
                SELECT other_user_id, MAX(created_at) AS last_message_time
                FROM (
                    SELECT sender_id AS other_user_id, created_at FROM messages WHERE recipient_id = %s
                    UNION ALL
                    SELECT recipient_id AS other_user_id, created_at FROM messages WHERE sender_id = %s
                ) conversation_users
                GROUP BY other_user_id
                ORDER BY last_message_time DESC
            """, (user_id, user_id))
            conversations = []
            for other_user_id, last_message_time in cursor.fetchall():
                cursor.execute("SELECT id, name, profile_picture FROM users WHERE id = %s", (other_user_id,))
                user_info = cursor.fetchone()
                if not user_info:
                    continue
                cursor.execute("""
                    SELECT id, sender_id, content, created_at
                    FROM messages
                    WHERE (sender_id = %s AND recipient_id = %s)
                       OR (sender_id = %s AND recipient_id = %s)
                    ORDER BY created_at ASC
                """, (user_id, other_user_id, other_user_id, user_id))
                conversation_messages = [{
                    "id": row[0],
                    "sender": "artisan" if row[1] == user_id else "customer",
                    "content": row[2],
                    "timestamp": row[3].isoformat()
                } for row in cursor.fetchall()]
                cursor.execute("SELECT COUNT(*) FROM messages WHERE recipient_id = %s AND sender_id = %s AND is_read = FALSE", (user_id, other_user_id))
                unread_count = cursor.fetchone()[0]
                conversations.append({
                    "user_id": user_info[0],
                    "user_name": user_info[1],
                    "avatar": user_info[2],
                    "last_message": conversation_messages[-1]["content"] if conversation_messages else "",
                    "timestamp": last_message_time.isoformat() if last_message_time else "",
                    "last_message_time": last_message_time.isoformat() if last_message_time else "",
                    "messages": conversation_messages,
                    "unread": unread_count > 0,
                    "unread_count": unread_count
                })
            cursor.close()
            return jsonify({"status": "success", "messages": conversations}), 200
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
        finally:
            close_db_connection(connection)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/user/<int:user_id>/messages', methods=['POST'])
def send_message(user_id):
    """Send a message to another user"""
    try:
        data = request.get_json()
        recipient_id = data.get('recipient_id')
        content = data.get('content')
        
        if not recipient_id or not content:
            return jsonify({"status": "error", "message": "recipient_id and content are required"}), 400
        
        connection = get_db_connection()
        if connection is None:
            return jsonify({"status": "error", "message": "Database connection failed"}), 500
        
        try:
            cursor = connection.cursor()
            
            cursor.execute(
                "INSERT INTO messages (sender_id, recipient_id, content) VALUES (%s, %s, %s)",
                (user_id, recipient_id, content)
            )
            create_notification(cursor, recipient_id, 'message', 'New message', 'You have a new message.', cursor.lastrowid)
            connection.commit()
            
            message_id = cursor.lastrowid
            cursor.close()
            
            return jsonify({
                "status": "success",
                "message": "Message sent successfully",
                "message_id": message_id
            }), 201
        
        except Exception as e:
            connection.rollback()
            return jsonify({"status": "error", "message": str(e)}), 500
        
        finally:
            close_db_connection(connection)
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    print("Starting TradePro Backend API...")
    print("Available endpoints:")
    print("  - GET /api/health")
    print("  - GET /api/db-status")
    print("  - POST /api/signup")
    print("  - POST /api/login")
    print("  - GET /api/user/<user_id>")
    print("  - GET /api/artisan/<user_id>/bookings")
    print("  - GET /api/artisan/<user_id>/services")
    print("  - GET /api/artisan/<user_id>/reviews")
    print("  - GET /api/client/<user_id>/bookings")
    print("  - PUT /api/booking/<booking_id>/status")
    print("  - PUT /api/artisan/<user_id>/profile")
    print("  - POST /api/artisan/<user_id>/services")
    print("  - PUT /api/artisan/service/<service_id>")
    print("  - DELETE /api/artisan/service/<service_id>")
    print("  - POST /api/artisan/<user_id>/availability")
    app.run(debug=True, host='localhost', port=5000)
