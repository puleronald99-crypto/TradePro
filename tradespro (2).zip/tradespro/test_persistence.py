#!/usr/bin/env python3
"""
Test script to verify localStorage persistence in user dashboard
"""

import json
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Start browser
driver = webdriver.Chrome()
driver.get('http://localhost/tradespro/frontend/login.html')

print("=" * 60)
print("TESTING LOCALSTORAGE PERSISTENCE")
print("=" * 60)

# Wait for page load
time.sleep(2)

# Log in as customer
email_input = driver.find_element(By.ID, 'email')
password_input = driver.find_element(By.ID, 'password')

email_input.send_keys('john@example.com')
password_input.send_keys('password123')

login_button = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
login_button.click()

print("\n✓ Logged in")
time.sleep(3)

# Navigate to dashboard
driver.get('http://localhost/tradespro/frontend/user-dashboard.html')
print("✓ Navigated to user dashboard")
time.sleep(3)

# TEST 1: Check if localStorage functions exist
print("\n[TEST 1] Checking if localStorage functions exist...")
try:
    result = driver.execute_script('''
        return {
            'saveUserDataToLocalStorage': typeof saveUserDataToLocalStorage,
            'loadUserDataFromLocalStorage': typeof loadUserDataFromLocalStorage,
            'userDataExists': typeof userData !== 'undefined'
        }
    ''')
    print(f"  saveUserDataToLocalStorage: {result['saveUserDataToLocalStorage']}")
    print(f"  loadUserDataFromLocalStorage: {result['loadUserDataFromLocalStorage']}")
    print(f"  userData object: {result['userDataExists']}")
except Exception as e:
    print(f"  ✗ Error: {e}")

# TEST 2: Edit profile and check localStorage
print("\n[TEST 2] Testing profile persistence...")
try:
    # Click profile tab
    profile_tab = driver.find_element(By.CSS_SELECTOR, '[data-tab="profile"]')
    profile_tab.click()
    time.sleep(2)
    
    # Get original name
    original_data = driver.execute_script('''
        return JSON.stringify(userData.user);
    ''')
    print(f"  Original name: {json.loads(original_data)['name']}")
    
    # Click edit button
    edit_btn = driver.find_element(By.CSS_SELECTOR, 'button:contains("Edit")')
    edit_btn.click()
    time.sleep(1)
    
    # Edit the name
    name_input = driver.find_element(By.ID, 'editName')
    name_input.clear()
    name_input.send_keys('Test User Updated')
    
    # Save
    save_btn = driver.find_element(By.XPATH, '//button[contains(text(), "Save")]')
    save_btn.click()
    time.sleep(1)
    
    # Check if saved to localStorage
    saved_data = driver.execute_script('''
        const saved = localStorage.getItem('userDataPersistent');
        return saved ? JSON.parse(saved).user.name : 'NOT FOUND';
    ''')
    print(f"  Updated name in localStorage: {saved_data}")
    
    # Refresh page
    driver.refresh()
    time.sleep(3)
    
    # Check if name persisted after refresh
    persisted_data = driver.execute_script('''
        return userData.user.name;
    ''')
    print(f"  Name after refresh: {persisted_data}")
    
    if persisted_data == 'Test User Updated':
        print("  ✓ PASS: Profile changes persisted!")
    else:
        print("  ✗ FAIL: Profile changes not persisted")
        
except Exception as e:
    print(f"  ✗ Error: {e}")

# TEST 3: Check favorites persistence
print("\n[TEST 3] Testing favorites persistence...")
try:
    # Click search tab
    search_tab = driver.find_element(By.CSS_SELECTOR, '[data-tab="search"]')
    search_tab.click()
    time.sleep(2)
    
    # Get initial favorites count
    initial_fav_count = driver.execute_script('return userData.favorites.length;')
    print(f"  Initial favorites: {initial_fav_count}")
    
    # Add a favorite (if artisans are loaded)
    fav_buttons = driver.find_elements(By.CSS_SELECTOR, '.favorite-btn')
    if fav_buttons:
        fav_buttons[0].click()
        time.sleep(1)
        
        new_fav_count = driver.execute_script('return userData.favorites.length;')
        print(f"  Favorites after adding: {new_fav_count}")
        
        # Refresh page
        driver.refresh()
        time.sleep(3)
        
        # Check if favorite persisted
        persisted_fav_count = driver.execute_script('return userData.favorites.length;')
        print(f"  Favorites after refresh: {persisted_fav_count}")
        
        if persisted_fav_count > initial_fav_count:
            print("  ✓ PASS: Favorites persisted!")
        else:
            print("  ✗ FAIL: Favorites not persisted")
    else:
        print("  ⚠ No artisans loaded yet, skipping")
        
except Exception as e:
    print(f"  ✗ Error: {e}")

# TEST 4: Check localStorage contents
print("\n[TEST 4] localStorage contents...")
try:
    stored = driver.execute_script('''
        return {
            'keys': Object.keys(localStorage),
            'userDataPersistent': localStorage.getItem('userDataPersistent')
        }
    ''')
    print(f"  Stored keys: {stored['keys']}")
    if stored['userDataPersistent']:
        data = json.loads(stored['userDataPersistent'])
        print(f"  userDataPersistent contains:")
        print(f"    - user: {bool(data.get('user'))}")
        print(f"    - favorites: {len(data.get('favorites', []))} items")
        print(f"    - messages: {len(data.get('messages', []))} items")
except Exception as e:
    print(f"  ✗ Error: {e}")

print("\n" + "=" * 60)
print("TEST COMPLETE")
print("=" * 60)

driver.quit()
