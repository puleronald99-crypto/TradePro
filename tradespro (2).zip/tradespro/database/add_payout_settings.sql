-- Create Payout Methods Table
CREATE TABLE IF NOT EXISTS payout_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    account_holder_name VARCHAR(100),
    account_number VARCHAR(100),
    account_type VARCHAR(50),
    bank_name VARCHAR(100),
    branch_code VARCHAR(50),
    phone_number VARCHAR(20),
    email VARCHAR(100),
    is_primary BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
    KEY idx_artisan_id (artisan_id),
    KEY idx_is_primary (is_primary)
);

-- Create Payout Settings Table
CREATE TABLE IF NOT EXISTS payout_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL UNIQUE,
    primary_method_id INT,
    payout_frequency VARCHAR(50) DEFAULT 'weekly',
    minimum_payout DECIMAL(10, 2) DEFAULT 10.00,
    auto_payout_enabled BOOLEAN DEFAULT TRUE,
    last_payout_date DATE,
    next_payout_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (primary_method_id) REFERENCES payout_methods(id) ON DELETE SET NULL,
    KEY idx_artisan_id (artisan_id)
);

-- Payment methods enum values:
-- mpesa, ecocash, mywallet, bank_transfer, paypal, stripe, flutterwave, afrimozo, innov8
