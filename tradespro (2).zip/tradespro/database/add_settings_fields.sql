-- Add Response Time and Buffer Time fields to artisan_profiles
ALTER TABLE artisan_profiles ADD COLUMN IF NOT EXISTS response_time_minutes INT DEFAULT 60;
ALTER TABLE artisan_profiles ADD COLUMN IF NOT EXISTS buffer_time_minutes INT DEFAULT 30;

-- Add Premium subscription field to users if not exists
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;

-- Create unavailable_dates table for blocking dates
CREATE TABLE IF NOT EXISTS unavailable_dates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
    INDEX idx_artisan_unavailable (artisan_id),
    INDEX idx_date_range (start_date, end_date)
);
