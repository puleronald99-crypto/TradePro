-- Create missing tables for TradePro database

ALTER TABLE users ADD COLUMN location_address VARCHAR(255);
ALTER TABLE users ADD COLUMN latitude DECIMAL(10, 7);
ALTER TABLE users ADD COLUMN longitude DECIMAL(10, 7);
ALTER TABLE artisan_profiles ADD COLUMN workplace_address VARCHAR(255);
ALTER TABLE artisan_profiles ADD COLUMN workplace_latitude DECIMAL(10, 7);
ALTER TABLE artisan_profiles ADD COLUMN workplace_longitude DECIMAL(10, 7);
ALTER TABLE artisan_profiles ADD COLUMN fuel_consumption_l_per_100km DECIMAL(6, 2) DEFAULT 8.00;
ALTER TABLE artisan_profiles ADD COLUMN fuel_price_per_liter DECIMAL(10, 2) DEFAULT 0.00;
ALTER TABLE bookings ADD COLUMN client_location_address VARCHAR(255);
ALTER TABLE bookings ADD COLUMN client_latitude DECIMAL(10, 7);
ALTER TABLE bookings ADD COLUMN client_longitude DECIMAL(10, 7);
ALTER TABLE bookings ADD COLUMN distance_km DECIMAL(10, 2);
ALTER TABLE bookings ADD COLUMN estimated_travel_minutes INT;
ALTER TABLE bookings ADD COLUMN estimated_fuel_cost DECIMAL(10, 2);

CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(40) NOT NULL,
    title VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    entity_id INT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read, created_at);

-- Create artisan_availability table
CREATE TABLE IF NOT EXISTS artisan_availability (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL,
    day_of_week VARCHAR(20),
    start_time TIME,
    end_time TIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
);

-- Create skills table
CREATE TABLE IF NOT EXISTS skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create artisan_skills table
CREATE TABLE IF NOT EXISTS artisan_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL,
    skill_id INT NOT NULL,
    proficiency_level VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
    UNIQUE KEY unique_artisan_skill (artisan_id, skill_id)
);

-- Create certifications table
CREATE TABLE IF NOT EXISTS certifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    artisan_id INT NOT NULL,
    certification_name VARCHAR(255) NOT NULL,
    issuing_organization VARCHAR(255),
    issue_date DATE,
    expiration_date DATE,
    certificate_number VARCHAR(255),
    document_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artisan_id) REFERENCES artisan_profiles(id) ON DELETE CASCADE
);

-- Fix services table - add missing columns (ignore if they exist)
ALTER TABLE services ADD COLUMN description TEXT;
