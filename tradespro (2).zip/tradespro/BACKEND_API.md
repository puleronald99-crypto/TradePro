# TradePro Backend API Documentation

## Overview
The TradePro backend is built with PHP and MySQL, providing RESTful API endpoints for user authentication, artisan management, services, reviews, and bookings.

## Table of Contents
1. [Setup & Installation](#setup--installation)
2. [Database Schema](#database-schema)
3. [API Endpoints](#api-endpoints)
4. [Authentication](#authentication)
5. [Error Handling](#error-handling)
6. [Security](#security)

---

## Setup & Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- XAMPP or similar local server

### Installation Steps

1. **Extract project files** to `htdocs/tradespro/`

2. **Create database** (Option A - via PHP):
   - Navigate to: `http://localhost/tradespro/php/setup_database.php`
   - The script will create all tables automatically

3. **Create database** (Option B - via SQL):
   ```bash
   mysql -u root -p < php/schema.sql
   ```

4. **Configuration**:
   - Edit `php/config.php` if your database credentials differ
   - Default: localhost | user: root | password: (empty) | database: tradepro

5. **Test the setup**:
   - Visit `http://localhost/tradespro/` to access the homepage

---

## Database Schema

### Users Table
Stores user information (customers and artisans)
```sql
- id: INT (Primary Key)
- name: VARCHAR(100)
- email: VARCHAR(100) - UNIQUE
- password: VARCHAR(255) - Hashed
- phone: VARCHAR(20)
- profile_picture: VARCHAR(255)
- is_artisan: BOOLEAN
- reset_token: VARCHAR(255) - For password reset
- created_at: TIMESTAMP
```

### Artisan Profiles Table
Extended profile for artisans
```sql
- id: INT (Primary Key)
- user_id: INT (Foreign Key → users.id)
- bio: TEXT
- experience_years: INT
- rating: DECIMAL(3,2) - Average rating
- total_reviews: INT
- verified: BOOLEAN
- created_at: TIMESTAMP
```

### Services Table
Available services/skills
```sql
- id: INT (Primary Key)
- name: VARCHAR(100) - UNIQUE
- description: TEXT
- icon: VARCHAR(255)
- created_at: TIMESTAMP
```

### Artisan Services Table
Many-to-many relationship between artisans and services
```sql
- id: INT (Primary Key)
- artisan_id: INT (Foreign Key)
- service_id: INT (Foreign Key)
- hourly_rate: DECIMAL(10,2)
- created_at: TIMESTAMP
```

### Locations Table
Cities and areas
```sql
- id: INT (Primary Key)
- city: VARCHAR(100)
- district: VARCHAR(100)
- country: VARCHAR(100)
- created_at: TIMESTAMP
```

### Reviews Table
User reviews and ratings for artisans
```sql
- id: INT (Primary Key)
- reviewer_id: INT (Foreign Key → users.id)
- artisan_id: INT (Foreign Key → artisan_profiles.id)
- rating: INT (1-5)
- comment: TEXT
- created_at: TIMESTAMP
```

### Bookings Table
Service requests and job tracking
```sql
- id: INT (Primary Key)
- customer_id: INT (Foreign Key)
- artisan_id: INT (Foreign Key)
- service_id: INT (Foreign Key)
- status: ENUM('pending', 'accepted', 'in_progress', 'completed', 'cancelled')
- description: TEXT
- scheduled_date: DATETIME
- budget: DECIMAL(10,2)
- created_at: TIMESTAMP
```

### Messages Table
Direct messaging between users
```sql
- id: INT (Primary Key)
- sender_id: INT (Foreign Key)
- recipient_id: INT (Foreign Key)
- message: TEXT
- is_read: BOOLEAN
- created_at: TIMESTAMP
```

### Portfolio Table
Artisan work samples (images/videos)
```sql
- id: INT (Primary Key)
- artisan_id: INT (Foreign Key)
- image_url: VARCHAR(255)
- video_url: VARCHAR(255)
- description: TEXT
- created_at: TIMESTAMP
```

---

## API Endpoints

### Authentication

#### 1. Sign Up
**Endpoint:** `POST /php/api_signup.php`

**Request:**
```json
{
    "full_name": "John Doe",
    "email": "john@example.com",
    "password": "securePassword123",
    "confirm_password": "securePassword123"
}
```

**Response (Success):**
```json
{
    "status": "success",
    "message": "Account created successfully",
    "user_id": 1,
    "name": "John Doe",
    "email": "john@example.com"
}
```

**Response (Error):**
```json
{
    "status": "error",
    "message": "Email already registered"
}
```

**Validation Rules:**
- Full name: 2-100 characters
- Email: Valid email format, unique
- Password: Minimum 6 characters
- Passwords must match

---

#### 2. Sign In
**Endpoint:** `POST /php/api_login.php`

**Request:**
```json
{
    "email": "john@example.com",
    "password": "securePassword123"
}
```

**Response (Success):**
```json
{
    "status": "success",
    "message": "Login successful",
    "user_id": 1,
    "name": "John Doe",
    "email": "john@example.com"
}
```

**Response (Error):**
```json
{
    "status": "error",
    "message": "Invalid email or password"
}
```

**Session:** Sets `$_SESSION['user_id']`, `$_SESSION['user_name']`, `$_SESSION['user_email']`

---

#### 3. Check Auth Status
**Endpoint:** `GET /php/api_auth.php`

**Response (Authenticated):**
```json
{
    "status": "success",
    "user_id": 1,
    "name": "John Doe",
    "email": "john@example.com"
}
```

**Response (Not Authenticated):**
```json
{
    "status": "error",
    "message": "Not authenticated"
}
```

---

#### 4. Logout
**Endpoint:** `POST /php/api_logout.php`

**Response:**
```json
{
    "status": "success",
    "message": "Logged out successfully"
}
```

---

### Artisans

#### Get All Artisans
**Endpoint:** `GET /php/api_artisans.php`

**Query Parameters:**
- `service` (optional): Filter by service name (string)
- `location` (optional): Filter by city (string)
- `min_rating` (optional): Minimum rating (1-5)
- `limit` (optional): Results per page (default: 10)
- `offset` (optional): Pagination offset (default: 0)

**Example:**
```
GET /php/api_artisans.php?service=Plumber&location=Maseru&min_rating=4&limit=20
```

**Response:**
```json
{
    "status": "success",
    "total": 2,
    "artisans": [
        {
            "id": 2,
            "name": "Jane Smith",
            "email": "jane@example.com",
            "phone": "+266 22123456",
            "profile_picture": "url",
            "bio": "Expert plumber with 10 years experience",
            "experience_years": 10,
            "rating": 4.8,
            "total_reviews": 25,
            "verified": true,
            "services": "Plumber",
            "locations": "Maseru"
        }
    ]
}
```

---

#### Get Single Artisan
**Endpoint:** `GET /php/api_artisans.php?id={artisan_id}`

**Response:**
```json
{
    "status": "success",
    "id": 2,
    "name": "Jane Smith",
    "email": "jane@example.com",
    "phone": "+266 22123456",
    "profile_picture": "url",
    "bio": "Expert plumber with 10 years experience",
    "experience_years": 10,
    "rating": 4.8,
    "total_reviews": 25,
    "verified": true,
    "services": [
        {
            "id": 2,
            "name": "Plumbing",
            "description": "All plumbing services",
            "hourly_rate": 150.00
        }
    ]
}
```

---

### Services

#### Get All Services
**Endpoint:** `GET /php/api_services.php`

**Response:**
```json
{
    "status": "success",
    "total": 10,
    "services": [
        {
            "id": 1,
            "name": "Electrician",
            "description": "Electrical repair and installation services",
            "icon": "fa-bolt"
        },
        {
            "id": 2,
            "name": "Plumber",
            "description": "Plumbing repair and installation",
            "icon": "fa-wrench"
        }
    ]
}
```

---

#### Create Service (Admin)
**Endpoint:** `POST /php/api_services.php`

**Request:**
```json
{
    "name": "New Service",
    "description": "Service description",
    "icon": "fa-icon"
}
```

**Response:**
```json
{
    "status": "success",
    "message": "Service created successfully",
    "id": 11,
    "name": "New Service"
}
```

**Requirements:** Must be logged in

---

### Reviews

#### Get Reviews for Artisan
**Endpoint:** `GET /php/api_reviews.php?artisan_id={id}`

**Query Parameters:**
- `artisan_id` (required): Artisan ID
- `limit` (optional): Default 10
- `offset` (optional): Default 0

**Response:**
```json
{
    "status": "success",
    "total": 3,
    "reviews": [
        {
            "id": 1,
            "rating": 5,
            "comment": "Excellent work, highly recommend!",
            "created_at": "2025-01-15 14:30:00",
            "reviewer_name": "John Doe"
        }
    ]
}
```

---

#### Submit Review
**Endpoint:** `POST /php/api_reviews.php`

**Request:**
```json
{
    "artisan_id": 2,
    "rating": 5,
    "comment": "Excellent work, highly recommend!"
}
```

**Response:**
```json
{
    "status": "success",
    "message": "Review submitted successfully",
    "review_id": 15
}
```

**Validation Rules:**
- Rating: 1-5
- Comment: 5-1000 characters
- User can only review each artisan once

---

## Authentication

### Session Management
- Sessions are used for authentication
- Session data includes:
  - `user_id`: User's unique identifier
  - `user_name`: User's full name
  - `user_email`: User's email address
  - `login_time`: Timestamp of login

### Password Security
- Passwords are hashed using `PASSWORD_BCRYPT` with cost factor 12
- Use `password_verify()` to check passwords
- Never store plain text passwords

### Protected Endpoints
Endpoints that require authentication:
- `POST /php/api_services.php` (Create service)
- `POST /php/api_reviews.php` (Submit review)
- `GET/POST /php/api_auth.php` (Get auth info)

---

## Error Handling

### Standard Error Response
```json
{
    "status": "error",
    "message": "Error description"
}
```

### HTTP Status Codes
- `200`: Success
- `400`: Bad request / Validation error
- `401`: Unauthorized / Not authenticated
- `404`: Resource not found
- `405`: Method not allowed
- `500`: Server error

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| Email already registered | Duplicate email | Use different email |
| Invalid email format | Bad email | Verify email format |
| Password must be 6+ chars | Too short | Use stronger password |
| Passwords do not match | Mismatch | Ensure passwords match |
| Not authenticated | No session | Log in first |
| Database connection failed | Connection issue | Check credentials |

---

## Security Best Practices

### Implemented
✅ Password hashing with bcrypt
✅ SQL prepared statements
✅ Input validation and sanitization
✅ Session-based authentication
✅ CORS headers configured
✅ Email uniqueness validation
✅ Password reset tokens with expiry

### Recommendations for Production
- [ ] Use HTTPS only
- [ ] Implement rate limiting
- [ ] Add CSRF protection
- [ ] Use environment variables for credentials
- [ ] Implement 2FA for accounts
- [ ] Regular security audits
- [ ] Backup database regularly
- [ ] Monitor authentication logs
- [ ] Implement password strength requirements
- [ ] Add account lockout after failed attempts

---

## Frontend Integration

### Update Frontend API Calls

#### Sign Up
```javascript
fetch('php/api_signup.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
})
.then(res => res.json())
.then(res => {
    if (res.status === 'success') {
        // Handle success
    } else {
        // Handle error
    }
});
```

#### Login
```javascript
fetch('php/api_login.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
})
.then(res => res.json())
.then(res => {
    if (res.status === 'success') {
        // Redirect to dashboard
        window.location.href = 'index.html';
    }
});
```

#### Get Artisans
```javascript
fetch('php/api_artisans.php?service=Plumber&location=Maseru')
    .then(res => res.json())
    .then(res => {
        console.log(res.artisans);
    });
```

---

## File Structure
```
tradespro/
├── php/
│   ├── config.php (Main configuration & helper functions)
│   ├── api_signup.php (User registration)
│   ├── api_login.php (User authentication)
│   ├── api_logout.php (Logout)
│   ├── api_auth.php (Auth check)
│   ├── api_artisans.php (Artisan management)
│   ├── api_services.php (Services management)
│   ├── api_reviews.php (Reviews & ratings)
│   ├── forgot-password.php (Password reset request)
│   ├── reset-password-confirm.php (Reset confirmation)
│   ├── setup_database.php (Database initialization)
│   ├── schema.sql (Database schema)
│   ├── db.php (Legacy connection file)
│   ├── signup.php (Legacy signup)
│   ├── login.php (Legacy login)
│   └── setup.sh (Setup script)
├── frontend/
│   ├── index.html
│   ├── login.html
│   ├── find-artisans.html
│   ├── reset-password.html
│   ├── become-artisan.html
│   ├── js/
│   ├── css/
│   └── ...
└── README.md
```

---

## Testing API Endpoints

### Using cURL
```bash
# Sign Up
curl -X POST http://localhost/tradespro/php/api_signup.php \
  -H "Content-Type: application/json" \
  -d '{"full_name":"Test User","email":"test@example.com","password":"password123","confirm_password":"password123"}'

# Login
curl -X POST http://localhost/tradespro/php/api_login.php \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'

# Get Artisans
curl http://localhost/tradespro/php/api_artisans.php?service=Plumber
```

### Using Postman
1. Import the API endpoints
2. Set request method (GET/POST)
3. Add headers: `Content-Type: application/json`
4. Add request body (JSON)
5. Send request

---

## Support & Troubleshooting

### Database Connection Issues
- Check database credentials in `config.php`
- Ensure MySQL is running
- Verify database `tradepro` exists
- Check user permissions

### Session Issues
- Ensure PHP sessions are enabled
- Check `php.ini` session.save_path
- Verify browser accepts cookies

### API Not Found
- Check file path and spelling
- Verify PHP files are in `php/` directory
- Check .htaccess rewrite rules

---

## Future Enhancements
- [ ] JWT token authentication
- [ ] OAuth social login
- [ ] Payment gateway integration
- [ ] Email notifications
- [ ] SMS alerts
- [ ] Real-time notifications
- [ ] Advanced search filters
- [ ] User dashboard
- [ ] Admin panel
- [ ] Analytics & reporting

---

**Last Updated:** December 27, 2025
**Version:** 1.0
