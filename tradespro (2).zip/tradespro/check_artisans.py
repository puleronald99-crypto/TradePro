#!/usr/bin/env python
"""Check artisans in database"""

import mysql.connector

try:
    db = mysql.connector.connect(
        host='127.0.0.1',
        user='root',
        password='NewStrongPassword123!',
        database='tradespro'
    )
    cursor = db.cursor(dictionary=True)
    
    print("\n" + "="*70)
    print("CHECKING ARTISANS IN DATABASE")
    print("="*70 + "\n")
    
    # Count artisans
    cursor.execute("SELECT COUNT(*) as total FROM artisan_profiles")
    count = cursor.fetchone()
    print(f"Total Artisans: {count['total']}\n")
    
    # List all artisans
    print("Artisan Details:")
    print("-" * 70)
    cursor.execute("""
        SELECT 
            ap.id,
            u.name,
            u.email,
            u.phone,
            ap.bio,
            ap.rating,
            ap.total_reviews,
            ap.experience_years,
            ap.availability_status,
            l.city,
            s.name as service_type,
            asvc.hourly_rate
        FROM artisan_profiles ap
        JOIN users u ON ap.user_id = u.id
        LEFT JOIN locations l ON ap.location_id = l.id
        LEFT JOIN artisan_services asvc ON ap.id = asvc.artisan_id
        LEFT JOIN services s ON asvc.service_id = s.id
        ORDER BY ap.id
    """)
    
    artisans = cursor.fetchall()
    
    if artisans:
        for artisan in artisans:
            print(f"\n#{artisan['id']} - {artisan['name']}")
            print(f"   Email: {artisan['email']}")
            print(f"   Phone: {artisan['phone']}")
            print(f"   Bio: {artisan['bio']}")
            print(f"   Service: {artisan['service_type']}")
            print(f"   Rate: ${artisan['hourly_rate']}/hr" if artisan['hourly_rate'] else "   Rate: N/A")
            print(f"   Rating: {artisan['rating']}/5 ({artisan['total_reviews']} reviews)")
            print(f"   Experience: {artisan['experience_years']} years")
            print(f"   Location: {artisan['city']}")
            print(f"   Status: {artisan['availability_status']}")
    else:
        print("❌ No artisans found!\n")
    
    # Check services
    print("\n" + "-"*70)
    print("Services in Database:")
    print("-" * 70)
    cursor.execute("""
        SELECT s.id, s.name, COUNT(asvc.id) as artisan_count
        FROM services s
        LEFT JOIN artisan_services asvc ON s.id = asvc.service_id
        GROUP BY s.id, s.name
        ORDER BY s.name
    """)
    
    services = cursor.fetchall()
    for service in services:
        print(f"  • {service['name']}: {service['artisan_count']} artisans")
    
    print("\n" + "="*70)
    if artisans:
        print(f"✅ SUCCESS: {len(set(a['id'] for a in artisans))} artisans found!")
    else:
        print("❌ FAILED: No artisans in database")
    print("="*70 + "\n")
    
    cursor.close()
    db.close()
    
except Exception as e:
    print(f"\n❌ Error: {str(e)}\n")
