# FRONTEND USER GUIDE - Search Implementation

## Quick Start

**Access the Dashboard:**
```
http://localhost/tradespro/frontend/user-dashboard-clean.html
```

---

## 1. FIND ARTISANS TAB - Search Methods

### ✓ Method 1: Service Dropdown Filter

**Location:** Top of Find Artisans section
```
Service Dropdown ▼
│
├─ All Services
├─ Plumbing (2 artisans)
├─ Carpentry (4 artisans)
├─ Electrical (3 artisans)
├─ Painting (2 artisans)
└─ ... more services
```

**How to Use:**
1. Click service dropdown
2. Select a service (e.g., "Plumbing")
3. Page automatically fetches all artisans for that service
4. Results display in grid below

**What You'll See:**
- Service name in notification: "Plumbing - Found 2 artisans"
- Grid updates with matching artisans
- Auto-switches to search results tab

---

### ✓ Method 2: Global Search Bar

**Location:** Top right of dashboard
```
🔍 Search artisans... [Enter]
```

**How to Use:**
1. Click search bar
2. Type keyword: "plumbing", "electrician", "john", etc.
3. Press Enter
4. Results fetch from database

**What You'll See:**
- Notification: "Found X artisans matching 'keyword'"
- Grid displays matching artisans
- Tab auto-switches to show results

**Search Fields:**
- Artisan name
- Bio/description
- Service name

---

### ✓ Method 3: Advanced Filters

**Location:** Below service dropdown
```
Location:    [____________]
Rating:      ★★★★☆ (drag slider)
Price Range: $ [__] to [__] /hr
            [Apply Filters Button]
```

**How to Use:**
1. Enter location (optional): "Maseru", "Leribe", etc.
2. Drag rating slider: 0-5 stars
3. Set price range: min and max
4. Click "Apply Filters"
5. System fetches artisans matching ALL criteria

**What You'll See:**
- Notification: "Found X artisans matching your criteria"
- Results display in grid
- Filters work together (AND logic)

**Example Searches:**
- Location: "Maseru" → Shows all artisans in Maseru
- Rating: 4.5+ → Shows top-rated artisans
- Price: $50-$80/hr → Shows artisans in that range
- Combined: Plumbing + Maseru + $40-70/hr + 4.5+ rating

---

## 2. SEARCH RESULTS DISPLAY

### Artisan Card Layout

```
┌─────────────────────────────┐
│  [Profile Picture]          │
│                             │
│  Name: John Smith           │
│  Service: Plumbing          │
│  ★★★★★ 4.8 (42 reviews)     │
│  $65/hr                     │
│                             │
│  Bio: Expert plumber with   │
│  15 years experience...     │
│                             │
│  [View Profile Button]      │
└─────────────────────────────┘
```

### What's Shown:
- ✓ Profile picture (if available)
- ✓ Full name
- ✓ Service type
- ✓ Star rating and review count
- ✓ Hourly rate
- ✓ Bio/description
- ✓ "View Profile" button

---

## 3. SEARCH TAB - Results View

**Auto-switches to "Search Results" tab when:**
1. Service selected from dropdown
2. Global search keyword entered
3. Filters applied

**On Search Results Tab:**
- Title: "Search Results"
- Grid shows all matching artisans
- Can refine with filters on left
- Can perform new search anytime

---

## 4. EXAMPLE WORKFLOWS

### Workflow A: Find Plumber in Maseru
```
1. Select "Plumbing" from service dropdown
2. Type "Maseru" in location field
3. Click "Apply Filters"
4. → Shows plumbers in Maseru
```

### Workflow B: Find Affordable Electrician
```
1. Type "electrician" in search bar
2. Press Enter
3. → Shows all electricians
4. Adjust price slider to $50-80
5. Click "Apply Filters"
6. → Shows electricians under $80/hr
```

### Workflow C: Find Top-Rated Carpenter
```
1. Select "Carpentry" from dropdown
2. Set rating to 4.5+ stars
3. Click "Apply Filters"
4. → Shows top-rated carpenters
5. Click "View Profile" on preferred artisan
```

### Workflow D: Find Plumber in Budget
```
1. Service: "Plumbing"
2. Price: $40-70/hr
3. Rating: 4.0+
4. Location: (optional)
5. Click "Apply Filters"
6. → Perfect match found!
```

---

## 5. NOTIFICATIONS & FEEDBACK

### Success Notifications
```
✓ Found 3 artisans matching 'plumbing'
✓ Plumbing - Found 2 artisans
✓ Found 5 artisans in your price range
```

### Information Notifications
```
ℹ No artisans found matching criteria
ℹ Try different search terms
ℹ Adjust filters and try again
```

### Error Messages (if any)
```
✗ Search failed - please try again
✗ Connection error - please refresh
→ Check browser console for details
```

---

## 6. DEBUGGING (For Developers)

### View API Calls & Responses:
1. Press `F12` to open DevTools
2. Click "Console" tab
3. Perform a search
4. See detailed logs:
```
Search params: {keyword: "plumbing", service_type: "", ...}
Response: {status: "success", total: 2, artisans: [...]}
Artisans found: 2
```

### Test Specific Searches:
```javascript
// In DevTools Console, paste:

// Get all artisans
fetch('/api/search/artisans')
  .then(r => r.json())
  .then(d => console.log(d.artisans))

// Search keyword
fetch('/api/search/artisans?keyword=plumbing')
  .then(r => r.json())
  .then(d => console.log(d))

// Search service
fetch('/api/search/by-service/Plumbing')
  .then(r => r.json())
  .then(d => console.log(d))

// With filters
fetch('/api/search/artisans?price_min=50&price_max=100&min_rating=4.5')
  .then(r => r.json())
  .then(d => console.log(d))
```

---

## 7. FEATURES SUMMARY

| Feature | Status | Works |
|---------|--------|-------|
| Service Dropdown | ✓ | Yes |
| Global Search | ✓ | Yes |
| Location Filter | ✓ | Yes |
| Rating Filter | ✓ | Yes |
| Price Range Filter | ✓ | Yes |
| Combined Filters | ✓ | Yes |
| Result Display | ✓ | Yes |
| Tab Switching | ✓ | Yes |
| Notifications | ✓ | Yes |
| Empty States | ✓ | Yes |
| Error Handling | ✓ | Yes |
| Profile Links | ✓ | Yes |

---

## 8. CURRENT TEST DATA

**11 Artisans in System:**

| # | Name | Service | Rate | Rating | Reviews |
|---|------|---------|------|--------|---------|
| 1 | Admin User | Multiple | $50-95 | 4.7 | 24 |
| 2 | John Smith | Plumbing | $65 | 4.8 | 42 |
| 3 | Maria Garcia | Carpentry | $55 | 4.7 | 38 |
| 4 | David Johnson | Electrical | $85 | 4.9 | 51 |
| 5 | Sarah Wilson | Plumbing | $70 | 4.8 | 39 |
| 6 | Pule Ramontsoe | Plumbing | $60 | 4.6 | 29 |
| 7 | John Smith | Multi | $45 | 4.5 | 22 |
| 8 | Maria Garcia | Multi | $55 | 4.7 | 35 |
| 9 | David Johnson | Multi | $85 | 4.9 | 48 |
| 10 | Sarah Wilson | Multi | $70 | 4.8 | 37 |
| 11 | Ahmed Hassan | Multi | $50 | 4.6 | 25 |

---

## 9. TROUBLESHOOTING

### Problem: Search returns no results
**Solution:**
- Check spelling of search term
- Try different keywords
- Adjust filters (may be too restrictive)
- Try service dropdown instead
- Refresh page

### Problem: Dropdown not showing services
**Solution:**
- Clear browser cache (Ctrl+Shift+Del)
- Refresh page (F5)
- Check DevTools console for errors
- Verify Flask server is running

### Problem: Page not switching to results
**Solution:**
- Check browser console (F12)
- Look for JavaScript errors
- Try search again
- Refresh page if needed

### Problem: Results show incorrect data
**Solution:**
- Verify database is running (MySQL)
- Check that /api/health returns status
- Try different search terms
- Check DevTools network tab for API responses

---

## 10. VIDEO/DEMO SCRIPT

**For Demo Video:**
```
1. Start with "Find Artisans" tab visible
2. Show service dropdown - click to expand
3. Select "Plumbing" - show notification and results (2 artisans)
4. Scroll to show artisan cards with details
5. Type "electrician" in search bar
6. Press Enter - show results (1 artisan)
7. Demonstrate filters:
   - Set location to "Maseru"
   - Set rating to 4.5
   - Set price $50-80
   - Click Apply
8. Show combined filter results
9. Open DevTools to show API calls
10. End with "System fully operational"
```

---

## QUICK REFERENCE CARD

```
┌─ FIND ARTISANS TAB ────────────────────────────┐
│                                                 │
│ 🔽 Service Dropdown (Auto-fetches)             │
│ 🔍 Global Search Bar (Keyword search)          │
│ 📍 Location Filter                             │
│ ⭐ Rating Slider                               │
│ 💰 Price Range ($min - $max)                   │
│ [Apply Filters Button]                         │
│                                                 │
│ Results Grid:                                  │
│ ┌─┐ ┌─┐ ┌─┐ ┌─┐                              │
│ │A│ │B│ │C│ │D│ ... (Artisan cards)           │
│ └─┘ └─┘ └─┘ └─┘                              │
│                                                 │
└─────────────────────────────────────────────────┘

All searches fetch from database in real-time!
```

---

**Ready for Testing & User Acceptance** ✓

