#!/usr/bin/env python
"""
Comprehensive Search Implementation Test Suite
Tests all search endpoints and features
"""

import sys
import requests
import json
from datetime import datetime

BASE_URL = "http://localhost:5000"

def print_header(text):
    """Print a formatted header"""
    print("\n" + "="*70)
    print(f"  {text}")
    print("="*70)

def print_test(test_num, name):
    """Print test header"""
    print(f"\n[TEST {test_num}] {name}")
    print("-" * 70)

def print_result(status, message, data=None):
    """Print test result"""
    symbol = "✓" if status == "success" else "✗"
    print(f"{symbol} {message}")
    if data:
        print(json.dumps(data, indent=2))

def test_health_check():
    """Test API health check"""
    print_test(1, "API Health Check")
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_result("success", f"API is healthy: {data.get('message')}")
            return True
        else:
            print_result("error", f"API returned status {response.status_code}")
            return False
    except Exception as e:
        print_result("error", f"Failed to connect: {str(e)}")
        return False

def test_get_all_artisans():
    """Test getting all artisans"""
    print_test(2, "Get All Artisans")
    try:
        response = requests.get(f"{BASE_URL}/api/search/artisans", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            total = data.get('total', 0)
            print_result("success", f"Retrieved {total} artisans")
            
            if data.get('artisans'):
                print("\nTop 3 Artisans:")
                for artisan in data['artisans'][:3]:
                    print(f"  • {artisan['name']}")
                    print(f"    Service: {artisan.get('service_type', 'N/A')}")
                    print(f"    Rate: ${artisan.get('hourly_rate', 'N/A')}/hr")
                    print(f"    Rating: {artisan.get('rating', 'N/A')}/5 ({artisan.get('total_reviews', 0)} reviews)")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_search_by_service():
    """Test service-specific search"""
    print_test(3, "Search by Service Type (Plumbing)")
    try:
        response = requests.get(f"{BASE_URL}/api/search/by-service/Plumbing", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            service = data.get('service', {})
            artisans = data.get('artisans', [])
            
            print_result("success", f"Found {len(artisans)} artisans for {service.get('name', 'Plumbing')}")
            
            if artisans:
                print("\nArtisans offering Plumbing:")
                for artisan in artisans:
                    print(f"  • {artisan['name']} - ${artisan.get('hourly_rate')}/hr")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_keyword_search():
    """Test keyword search"""
    print_test(4, "Keyword Search (electrician)")
    try:
        response = requests.get(f"{BASE_URL}/api/search/artisans?keyword=electrician", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            artisans = data.get('artisans', [])
            print_result("success", f"Found {len(artisans)} artisan(s) matching 'electrician'")
            
            if artisans:
                for artisan in artisans:
                    print(f"  • {artisan['name']}: {artisan.get('bio', 'N/A')}")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_price_filter():
    """Test price range filter"""
    print_test(5, "Price Range Filter ($50-100/hr)")
    try:
        response = requests.get(f"{BASE_URL}/api/search/artisans?price_min=50&price_max=100", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            artisans = data.get('artisans', [])
            print_result("success", f"Found {len(artisans)} artisans in price range $50-100/hr")
            
            if artisans:
                print("\nArtisans by price:")
                for artisan in artisans:
                    print(f"  • {artisan['name']}: ${artisan.get('hourly_rate')}/hr")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_rating_filter():
    """Test rating filter"""
    print_test(6, "Rating Filter (4.5+ stars)")
    try:
        response = requests.get(f"{BASE_URL}/api/search/artisans?min_rating=4.5", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            artisans = data.get('artisans', [])
            print_result("success", f"Found {len(artisans)} artisans with 4.5+ rating")
            
            if artisans:
                print("\nTop rated artisans:")
                for artisan in artisans[:5]:
                    print(f"  • {artisan['name']}: {artisan.get('rating')}/5 ({artisan.get('total_reviews', 0)} reviews)")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_combined_filters():
    """Test combined filters"""
    print_test(7, "Combined Filters (Carpentry, $40-70/hr, 4.5+ rating)")
    try:
        response = requests.get(
            f"{BASE_URL}/api/search/artisans?service_type=Carpentry&price_min=40&price_max=70&min_rating=4.5",
            timeout=5
        )
        data = response.json()
        if data.get('status') == 'success':
            artisans = data.get('artisans', [])
            print_result("success", f"Found {len(artisans)} artisans matching all filters")
            
            if artisans:
                print("\nMatching artisans:")
                for artisan in artisans:
                    print(f"  • {artisan['name']}")
                    print(f"    Service: {artisan.get('service_type')}")
                    print(f"    Rate: ${artisan.get('hourly_rate')}/hr")
                    print(f"    Rating: {artisan.get('rating')}/5")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_location_filter():
    """Test location filter"""
    print_test(8, "Location Filter (Maseru)")
    try:
        response = requests.get(f"{BASE_URL}/api/search/artisans?location=Maseru", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            artisans = data.get('artisans', [])
            print_result("success", f"Found {len(artisans)} artisans in Maseru")
            
            if artisans:
                print("\nArtisans in Maseru:")
                for artisan in artisans[:5]:
                    print(f"  • {artisan['name']} ({artisan.get('location', 'N/A')})")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_services_endpoint():
    """Test get all services"""
    print_test(9, "Get All Available Services")
    try:
        response = requests.get(f"{BASE_URL}/api/services", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            services = data.get('services', [])
            print_result("success", f"Retrieved {len(services)} services")
            
            if services:
                print("\nAvailable Services:")
                for service in services[:10]:
                    print(f"  • {service['name']} ({service.get('artisan_count', 0)} artisans)")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def test_database_status():
    """Test database status"""
    print_test(10, "Database Status Check")
    try:
        response = requests.get(f"{BASE_URL}/api/db-status", timeout=5)
        data = response.json()
        if data.get('status') == 'success':
            print_result("success", f"Database: {data.get('database', 'unknown')}")
            print_result("success", f"Tables: {data.get('tables_count', 0)}")
            
            tables = data.get('tables', [])
            if tables:
                print("\nDatabase Tables:")
                for table in sorted(tables)[:10]:
                    print(f"  • {table}")
            return True
        else:
            print_result("error", data.get('message', 'Unknown error'))
            return False
    except Exception as e:
        print_result("error", f"Failed: {str(e)}")
        return False

def run_all_tests():
    """Run all tests"""
    print_header("SEARCH IMPLEMENTATION TEST SUITE")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Base URL: {BASE_URL}")
    
    results = []
    
    # Run all tests
    tests = [
        test_health_check,
        test_get_all_artisans,
        test_search_by_service,
        test_keyword_search,
        test_price_filter,
        test_rating_filter,
        test_combined_filters,
        test_location_filter,
        test_services_endpoint,
        test_database_status,
    ]
    
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"\n✗ Test crashed: {str(e)}")
            results.append(False)
    
    # Print summary
    print_header("TEST SUMMARY")
    passed = sum(results)
    total = len(results)
    
    print(f"\nTotal Tests: {total}")
    print(f"Passed: {passed}")
    print(f"Failed: {total - passed}")
    
    if passed == total:
        print("\n✓ ALL TESTS PASSED!")
        print("\nSearch implementation is fully functional:")
        print("  • Global search working")
        print("  • Service-specific search working")
        print("  • Keyword search working")
        print("  • Price filtering working")
        print("  • Rating filtering working")
        print("  • Location filtering working")
        print("  • Combined filters working")
        print("  • Database connected and healthy")
    else:
        print(f"\n✗ {total - passed} test(s) failed")
        print("Please check the errors above")
    
    print(f"\nCompleted at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

if __name__ == '__main__':
    try:
        run_all_tests()
    except KeyboardInterrupt:
        print("\n\nTests interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nFatal error: {str(e)}")
        sys.exit(1)
