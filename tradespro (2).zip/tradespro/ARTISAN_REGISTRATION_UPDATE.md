# Artisan Registration Data Collection - Implementation Summary

## Overview
Updated the artisan registration system to collect and display all professional information during registration. Previously, only basic user information was being saved. Now all the following information is captured and stored:

## Information Collected During Registration

### Contact Information
- **Email**: Stored in users table
- **Phone**: Stored in users table
- **Location**: Stored in artisan_profiles (with location_id reference)

### Professional Information
- **Service Type**: Linked to services table via artisan_services junction table
- **License Number**: Stored in artisan_profiles.license_number
- **Years of Experience**: Stored in artisan_profiles.experience_years
- **Bio/Description**: Stored in artisan_profiles.bio

### Additional Information
- **Service Coverage/Radius**: Stored in artisan_profiles.service_radius_km

## Files Modified

### 1. Backend API (`backend/app.py`)

#### Updated `/api/signup` Endpoint
- **Changed**: Enhanced the registration endpoint to accept and process artisan-specific fields
- **New Fields Accepted**:
  - `service_type`: Service category (e.g., "Electrician", "Plumber")
  - `experience_years`: Years of professional experience (integer)
  - `bio`: Professional biography/description
  - `location`: Operating location (city/area)
  - `service_radius`: Service coverage radius in kilometers
  - `license_number`: Professional license number (optional)

- **Processing Logic**:
  1. Validates and inserts user record
  2. For artisans:
     - Creates/finds location and stores location_id
     - Creates service record if it doesn't exist
     - Links service to artisan via artisan_services table
     - Updates artisan_profiles with all professional information
     - Defaults service_radius to 10 km if not provided

#### New `/api/artisan/<user_id>/profile` GET Endpoint
- **Purpose**: Retrieves complete artisan profile information
- **Returns**:
  ```json
  {
    "status": "success",
    "profile": {
      "id": artisan_id,
      "user_id": user_id,
      "name": full_name,
      "email": email_address,
      "phone": phone_number,
      "bio": biography,
      "experience_years": years,
      "location": location_name,
      "license_number": license,
      "service_radius_km": radius,
      "verified": boolean,
      "rating": float,
      "total_reviews": count,
      "company_name": company,
      "availability_status": status,
      "services": [
        { "id": service_id, "name": service_name }
      ]
    }
  }
  ```

### 2. Frontend Registration Form (`frontend/become-artisan.html`)

#### Form Data Submission Update
- **Changed**: Updated form submission to send all collected data to backend
- **New JSON Payload Fields**:
  ```javascript
  {
    name: fullName,
    email: email,
    phone: phone,
    password: password,
    is_artisan: true,
    service_type: service,
    experience_years: experience,
    bio: description,
    location: location,
    service_radius: coverage
  }
  ```

#### Updated Confirmation Message
- Now displays the registered artisan information to confirm successful registration
- Shows:
  - Service type
  - Years of experience
  - Operating location
  - Service radius

### 3. Frontend Artisan Dashboard (`frontend/js/artisan-dashboard.js`)

#### Updated `fetchArtisanData()` Function
- **Changed**: Now fetches from the new `/api/artisan/{user_id}/profile` endpoint
- **Enhanced**: Maps all profile data including services, location, and professional details
- **Benefits**: 
  - More targeted API call
  - Better data structure
  - Includes service information in one call

#### Updated `displayProfile()` Function
- **Changed**: Corrected field mapping for profile display
- **Fixes**:
  - Location now displays from `artisan.location` instead of `languages_spoken`
  - Service type now pulls from linked services array
  - Experience years display correctly
  - All contact and professional information displays properly

## Database Tables Used

### artisan_profiles
- `id`: Primary key
- `user_id`: Foreign key to users table
- `bio`: Text field for professional description
- `experience_years`: Integer for years of experience
- `location_id`: Foreign key to locations table
- `license_number`: Professional license number
- `service_radius_km`: Service coverage radius

### locations
- `id`: Primary key
- `city`: City/location name

### services
- `id`: Primary key
- `name`: Service type name
- `category`: Service category

### artisan_services
- `id`: Primary key
- `artisan_id`: Foreign key to artisan_profiles
- `service_id`: Foreign key to services

## Registration Flow

1. **Frontend**: User fills in artisan registration form with all information
2. **Frontend**: Form submits all data to `/api/signup` endpoint
3. **Backend**: 
   - Creates user record
   - Creates/finds location
   - Creates/finds service
   - Creates artisan profile with all information
   - Links service to artisan
4. **Backend**: Returns success response with user_id
5. **Frontend**: Displays confirmation message with registered information
6. **Frontend**: Redirects to login page
7. **After Login**: Artisan dashboard fetches full profile via GET endpoint and displays it

## Information Display After Registration

When an artisan logs in and views their profile:

### Contact Information Section
- Email: ✓
- Phone: ✓
- Location: ✓

### Professional Information Section
- Service Type: ✓ (from linked services)
- License Number: ✓
- Years of Experience: ✓
- Bio: ✓

## Testing Checklist

- [ ] Test artisan registration with all fields filled
- [ ] Verify all data is saved to database
- [ ] Test login after registration
- [ ] Verify profile page displays all information correctly
- [ ] Test with missing optional fields (license_number, bio)
- [ ] Verify service linking works
- [ ] Verify location creation/lookup works
- [ ] Test dashboard loads and displays profile correctly

## API Request Examples

### Registration Request
```bash
POST /api/signup
Content-Type: application/json

{
  "name": "John Electrician",
  "email": "john@example.com",
  "phone": "+26659387865",
  "password": "SecurePass123",
  "is_artisan": true,
  "service_type": "Admin Work",
  "experience_years": 0,
  "bio": "Professional in admin work",
  "location": "Maseru Central",
  "service_radius": 10,
  "license_number": "ADM-2024-12345"
}
```

### Get Profile Request
```bash
GET /api/artisan/1/profile
```

### Response Example
```json
{
  "status": "success",
  "profile": {
    "id": 1,
    "user_id": 1,
    "name": "John Electrician",
    "email": "john@example.com",
    "phone": "+26659387865",
    "bio": "Professional in admin work",
    "experience_years": 0,
    "location": "Maseru Central",
    "license_number": "ADM-2024-12345",
    "service_radius_km": 10,
    "verified": false,
    "rating": 0.0,
    "total_reviews": 0,
    "company_name": null,
    "availability_status": "available",
    "services": [
      {
        "id": 5,
        "name": "Admin Work"
      }
    ]
  }
}
```

## Notes

- All data is properly validated before insertion
- Transactions ensure data consistency
- Existing locations and services are reused to avoid duplicates
- Error handling provides clear feedback to users
- Database connections properly managed with try-catch-finally blocks
