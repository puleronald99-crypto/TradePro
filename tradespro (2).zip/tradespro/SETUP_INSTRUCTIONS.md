# TradePro Database Setup Instructions

## Prerequisites
- XAMPP installed on your system
- A code editor (VS Code, etc.)

## Step-by-Step Setup

### 1. Start XAMPP Services
1. Open XAMPP Control Panel
2. Start **Apache** (web server)
3. Start **MySQL** (database server)
4. Both should show green indicators when running

### 2. Create the Database

#### Option A: Using phpMyAdmin (GUI)
1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Click on "New" to create a new database
3. Database name: `tradespro`
4. Click "Create"
5. Click on the new `tradespro` database
6. Go to the "SQL" tab
7. Copy and paste the entire contents of `database/schema.sql`
8. Click "Go" to execute

#### Option B: Using Command Line
1. Open Command Prompt
2. Navigate to your MySQL bin folder:
   ```
   cd "C:\xampp\mysql\bin"
   ```
3. Connect to MySQL:
   ```
   mysql -u root -p
   ```
   (Press Enter when prompted for password - it's empty by default)
4. Run the SQL script:
   ```
   source C:\Users\kOOlesT\OneDrive\Documents\tradespro\database\schema.sql
   ```
5. Verify:
   ```
   USE tradespro;
   SHOW TABLES;
   ```

### 3. Set Up Project Files

1. Copy your entire `tradespro` folder to XAMPP's htdocs:
   ```
   C:\xampp\htdocs\tradespro
   ```

2. Your structure should look like:
   ```
   C:\xampp\htdocs\tradespro\
   ├── frontend/
   ├── backend/
   │   ├── config.php
   │   └── db_test.php
   └── database/
       └── schema.sql
   ```

### 4. Test the Connection

1. Start XAMPP (Apache + MySQL)
2. Open browser: `http://localhost/tradespro/backend/db_test.php`
3. You should see:
   - ✓ Database connection successful!
   - Database name
   - List of tables

### 5. Update PHP Files Configuration

If needed, edit `backend/config.php`:
```php
define('DB_HOST', 'localhost');  // Usually localhost
define('DB_USER', 'root');       // Default XAMPP user
define('DB_PASSWORD', '');       // Empty for XAMPP default
define('DB_NAME', 'tradespro');
```

## Database Structure

### Main Tables:
- **users**: Customers and Artisans
- **artisan_profiles**: Extended artisan information
- **services**: Types of services (Electrician, Plumber, etc.)
- **artisan_services**: Links artisans to their services
- **locations**: Cities and areas
- **artisan_locations**: Links artisans to service areas
- **reviews**: Customer ratings and feedback
- **bookings**: Jobs/requests between customers and artisans
- **messages**: Chat between users

## Sample Data

The schema includes:
- 8 sample services (Electrician, Plumber, Carpenter, etc.)
- 5 sample locations (Lesotho cities)

You can add more data through phpMyAdmin or PHP scripts.

## Troubleshooting

### "Access denied for user 'root'@'localhost'"
- Make sure MySQL is running (green indicator in XAMPP Control Panel)
- Check if password is correct in `config.php`

### "Unknown database 'tradespro'"
- Verify you imported the schema.sql file
- Check in phpMyAdmin that the database exists

### PHP files not working
- Ensure files are in `C:\xampp\htdocs\`
- Restart Apache in XAMPP Control Panel
- Check browser console for errors

## Next Steps

1. Create PHP files in `backend/` folder for:
   - User registration/login
   - Artisan profile management
   - Search functionality
   - Booking system

2. Connect your frontend HTML/JS to these PHP APIs

3. Add form validation and security measures (SQL injection prevention, password hashing)
