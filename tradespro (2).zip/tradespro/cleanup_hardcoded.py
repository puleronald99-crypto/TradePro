#!/usr/bin/env python3
"""Remove all hard-coded sample data from dashboard HTML files"""
import re

def clean_user_dashboard():
    """Remove hard-coded content from user-dashboard.html"""
    with open('frontend/user-dashboard.html', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove all hard-coded artisan cards from search grid (everything between searchArtisansGrid div opening and closing)
    content = re.sub(
        r'(<div class="artisans-grid" id="searchArtisansGrid">)[\s\S]*?(</div>\s*</div>\s*<!-- SEARCH ARTISANS TAB -->)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded booking items
    content = re.sub(
        r'(<div class="bookings-list">)[\s\S]*?(</div>\s*<!-- FAVORITES TAB -->)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded favorite artisans  
    content = re.sub(
        r'(<div class="favorites-grid"[^>]*>)[\s\S]*?(</div>\s*</div>\s*<!-- SERVICE HISTORY)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded service history items
    content = re.sub(
        r'(<div class="history-list"[^>]*>)[\s\S]*?(</div>\s*<!-- PAYMENTS TAB)',
        r'\1\2',
        content
    )
    
    with open('frontend/user-dashboard.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print('✓ Cleaned user-dashboard.html')


def clean_artisan_dashboard():
    """Remove hard-coded content from artisan-dashboard.html"""
    with open('frontend/artisan-dashboard.html', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Remove hard-coded stat values
    content = re.sub(
        r'<p class="stat-value">[\d\$\.\/%]+</p>\s*<small>[^<]*</small>',
        '<p class="stat-value" data-dynamic="true">--</p>\n                            <small>--</small>',
        content
    )
    
    # Remove hard-coded booking cards
    content = re.sub(
        r'(<div class="bookings-list"[^>]*>)[\s\S]*?(</div>\s*<!-- SCHEDULE TAB)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded service cards
    content = re.sub(
        r'(<div class="services-grid"[^>]*>)[\s\S]*?(</div>\s*</div>\s*<!-- BOOKINGS TAB)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded review cards
    content = re.sub(
        r'(<div class="review-list"[^>]*>)[\s\S]*?(</div>\s*</div>\s*<!-- MESSAGES TAB)',
        r'\1\2',
        content
    )
    
    # Remove hard-coded profile information
    content = re.sub(
        r'(<div class="profile-details">)[\s\S]*?(</div>\s*</div>\s*<!-- SERVICES TAB)',
        r'\1\2',
        content
    )
    
    with open('frontend/artisan-dashboard.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print('✓ Cleaned artisan-dashboard.html')


if __name__ == '__main__':
    clean_user_dashboard()
    clean_artisan_dashboard()
    print('\nAll hard-coded sample data has been removed!')
