#!/usr/bin/env python3
"""
Link checker for the TradePro project
Validates all href and src attributes in HTML files
"""

import os
import re
from pathlib import Path

def check_links():
    frontend_dir = Path(r"c:\xampp\htdocs\tradespro\frontend")
    
    # Get all HTML files
    html_files = sorted(frontend_dir.glob("*.html"))
    
    broken_links = []
    valid_links = []
    issues = []
    
    for html_file in html_files:
        print(f"\n📄 Checking: {html_file.name}")
        with open(html_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find all href and src attributes
        links = re.findall(r'(?:href|src)=["\']([^"\']+)["\']', content)
        
        for link in links:
            # Skip external URLs and anchor links
            if link.startswith('http') or link.startswith('javascript:') or link.startswith('#'):
                continue
            
            # Build full path
            if link.startswith('/'):
                full_path = frontend_dir.parent / link.lstrip('/')
            else:
                full_path = frontend_dir / link
            
            # Check if file exists
            if full_path.exists():
                valid_links.append((html_file.name, link))
                print(f"  ✓ {link}")
            else:
                broken_links.append((html_file.name, link))
                print(f"  ✗ BROKEN: {link}")
    
    # Report structure issues
    css_js_dir = frontend_dir / "css" / "js"
    if css_js_dir.exists():
        issues.append("⚠️  STRUCTURE ISSUE: Found css/js/ directory - js folder should only be at frontend/js/")
    
    # Print summary
    print("\n" + "="*60)
    print("LINK VALIDATION REPORT")
    print("="*60)
    print(f"\n✓ Valid links: {len(valid_links)}")
    print(f"✗ Broken links: {len(broken_links)}")
    print(f"⚠️  Structure issues: {len(issues)}")
    
    if broken_links:
        print("\n❌ BROKEN LINKS:")
        for file, link in broken_links:
            print(f"  {file}: {link}")
    
    if issues:
        print("\n⚠️  ISSUES:")
        for issue in issues:
            print(f"  {issue}")
    
    return broken_links, issues

if __name__ == "__main__":
    broken, issues = check_links()
    if not broken and not issues:
        print("\n✅ All links are valid!")
