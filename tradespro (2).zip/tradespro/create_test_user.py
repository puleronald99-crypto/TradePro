#!/usr/bin/env python3
"""Create test users for dashboard testing"""

import mysql.connector
import hashlib
import sys

try:
    # Connect to database
    conn = mysql.connector.connect(
        host='127.0.0.1',
        user='root',
        password='NewStrongPassword123!',
        database='tradespro'
    )

    cursor = conn.cursor()

    # Hash password
    password = 'password123'
    password_hash = hashlib.sha256(password.encode()).hexdigest()

    # Check if test user already exists
    cursor.execute("SELECT id FROM users WHERE email = %s", ('customer@test.com',))
    existing = cursor.fetchone()
    
    if existing:
        user_id = existing[0]
        print(f"Test customer already exists with ID: {user_id}")
    else:
        # Insert test customer
        cursor.execute("""
            INSERT INTO users (name, email, password, phone, is_artisan, created_at)
            VALUES (%s, %s, %s, %s, %s, NOW())
        """, ('Test Customer', 'customer@test.com', password_hash, '1234567890', 0))
        
        user_id = cursor.lastrowid
        conn.commit()
        print(f"Test customer created with ID: {user_id}")

    print(f"Email: customer@test.com")
    print(f"Password: password123")
    print(f"\nTest user login credentials set. Use these in localStorage:")
    print(f'  localStorage.setItem("userId", "{user_id}");')
    print(f'  localStorage.setItem("isArtisan", "0");')

    cursor.close()
    conn.close()

except Exception as e:
    print(f"Error: {e}", file=sys.stderr)
    sys.exit(1)
