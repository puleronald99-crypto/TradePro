// TEST SCRIPT FOR USER DASHBOARD URL HASH NAVIGATION
// Run this in browser console to test the functionality

console.log('=== USER DASHBOARD LINK TEST ===');

// Test 1: Check current URL and hash
function testCurrentURL() {
    console.log('\n✓ TEST 1: Current URL');
    console.log('Full URL:', window.location.href);
    console.log('Current Hash:', window.location.hash);
    console.log('Expected: http://localhost/tradespro/frontend/user-dashboard.html#search (or #home, #bookings, etc.)');
}

// Test 2: Check if tabs exist in DOM
function testTabElements() {
    console.log('\n✓ TEST 2: Tab Elements');
    const tabs = document.querySelectorAll('.tab-content');
    const navLinks = document.querySelectorAll('.nav-link');
    console.log('Tab contents found:', tabs.length);
    console.log('Nav links found:', navLinks.length);
    
    tabs.forEach(tab => {
        console.log(`  - Tab ID: ${tab.id}, Active: ${tab.classList.contains('active')}`);
    });
}

// Test 3: Simulate clicking a tab
function testClickTab(tabName) {
    console.log(`\n✓ TEST 3: Clicking "${tabName}" Tab`);
    
    // Find the nav link for this tab
    const link = document.querySelector(`a[href="#${tabName}"]`);
    if (link) {
        console.log(`Found link for ${tabName}`);
        link.click();
        
        // Check if URL updated
        setTimeout(() => {
            console.log('URL after click:', window.location.hash);
            console.log('Expected:', `#${tabName}`);
            
            // Check if tab is active
            const tab = document.getElementById(tabName);
            if (tab && tab.classList.contains('active')) {
                console.log(`✓ SUCCESS: ${tabName} tab is active`);
            } else {
                console.log(`✗ FAILED: ${tabName} tab is not active`);
            }
        }, 100);
    } else {
        console.log(`✗ Link for "${tabName}" not found`);
    }
}

// Test 4: Direct URL hash navigation
function testDirectHashNavigation(tabName) {
    console.log(`\n✓ TEST 4: Direct Hash Navigation to #${tabName}`);
    window.location.hash = tabName;
    
    setTimeout(() => {
        console.log('URL after hash assignment:', window.location.hash);
        const tab = document.getElementById(tabName);
        if (tab && tab.classList.contains('active')) {
            console.log(`✓ SUCCESS: Page loaded with ${tabName} tab active`);
        } else {
            console.log(`✗ FAILED: ${tabName} tab is not active`);
        }
    }, 100);
}

// Test 5: Check artisans are loaded
function testArtisansDisplay() {
    console.log('\n✓ TEST 5: Artisans Display');
    
    // Check if artisans are loaded in memory
    if (typeof userData !== 'undefined') {
        console.log('userData object exists');
        console.log(`Artisans loaded: ${userData.artisans.length}`);
        
        if (userData.artisans.length > 0) {
            console.log('First artisan:', userData.artisans[0].name);
        } else {
            console.log('✗ WARNING: No artisans loaded');
        }
    } else {
        console.log('✗ userData object not found');
    }
    
    // Check artisans grid
    const grid = document.getElementById('searchArtisansGrid');
    if (grid) {
        console.log(`Artisans grid found with ${grid.children.length} cards`);
    }
}

// Run all tests
function runAllTests() {
    console.clear();
    console.log('%c=== USER DASHBOARD URL TEST SUITE ===', 'color: blue; font-size: 14px; font-weight: bold;');
    
    testCurrentURL();
    testTabElements();
    testArtisansDisplay();
    
    console.log('\n%c--- MANUAL TESTS ---', 'color: green; font-size: 12px;');
    console.log('Run these manually:');
    console.log('  testClickTab("search")      - Click search tab');
    console.log('  testClickTab("bookings")    - Click bookings tab');
    console.log('  testDirectHashNavigation("search") - Test direct hash navigation');
}

// Auto-run all tests
runAllTests();

// Expose functions for manual testing
console.log('\n%c--- Available Commands ---', 'color: orange;');
console.log('testCurrentURL()');
console.log('testTabElements()');
console.log('testArtisansDisplay()');
console.log('testClickTab("search")');
console.log('testClickTab("bookings")');
console.log('testDirectHashNavigation("search")');
console.log('runAllTests()');
