# API REFERENCE - Search Endpoints

**Base URL:** `http://localhost:5000`

---

## 1. HEALTH CHECK ENDPOINT

### GET /api/health

**Purpose:** Verify API is running

**Parameters:** None

**Example Request:**
```bash
curl http://localhost:5000/api/health
```

**Example Response (200):**
```json
{
  "status": "healthy",
  "message": "API running",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## 2. SEARCH ARTISANS ENDPOINT

### GET /api/search/artisans

**Purpose:** Search artisans with filters

**Query Parameters (All Optional):**

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| keyword | string | Search in name, bio, service | `?keyword=plumbing` |
| service_type | string | Filter by service type | `?service_type=Carpentry` |
| location | string | Filter by city | `?location=Maseru` |
| min_rating | float | Minimum rating (0-5) | `?min_rating=4.5` |
| price_min | float | Minimum hourly rate | `?price_min=50` |
| price_max | float | Maximum hourly rate | `?price_max=100` |

**Example Requests:**

```bash
# All artisans
curl http://localhost:5000/api/search/artisans

# Search keyword
curl "http://localhost:5000/api/search/artisans?keyword=electrician"

# Filter by service
curl "http://localhost:5000/api/search/artisans?service_type=Plumbing"

# Combined filters
curl "http://localhost:5000/api/search/artisans?service_type=Carpentry&price_min=50&price_max=100&min_rating=4.5"
```

**Response Schema (200):**
```json
{
  "status": "success",
  "total": 11,
  "filters_applied": {
    "keyword": "plumbing",
    "service_type": "",
    "location": "",
    "min_rating": 0,
    "price_min": 0,
    "price_max": 999999
  },
  "artisans": [
    {
      "id": 1,
      "name": "John Smith",
      "bio": "Expert plumber with 15 years experience...",
      "service_type": "Plumbing",
      "hourly_rate": 65.00,
      "rating": 4.8,
      "total_reviews": 42,
      "location": "Maseru",
      "availability_status": "available",
      "experience_years": 15
    },
    {
      "id": 2,
      "name": "Sarah Wilson",
      "bio": "Licensed plumber, emergency services...",
      "service_type": "Plumbing",
      "hourly_rate": 70.00,
      "rating": 4.8,
      "total_reviews": 39,
      "location": "Maseru",
      "availability_status": "available",
      "experience_years": 12
    }
  ]
}
```

**Response Codes:**

| Code | Meaning |
|------|---------|
| 200 | Success - artisans returned |
| 400 | Bad request - invalid parameters |
| 500 | Server error - contact support |

---

## 3. SEARCH BY SERVICE ENDPOINT

### GET /api/search/by-service/\<service_type\>

**Purpose:** Get all artisans for a specific service

**URL Parameters:**

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| service_type | string | Service name (URL encoded) | `/api/search/by-service/Plumbing` |

**Example Requests:**

```bash
# Plumbing artisans
curl http://localhost:5000/api/search/by-service/Plumbing

# Carpentry artisans
curl http://localhost:5000/api/search/by-service/Carpentry

# HVAC artisans (URL encoded)
curl "http://localhost:5000/api/search/by-service/HVAC%20Repair"
```

**Response Schema (200):**
```json
{
  "status": "success",
  "service": {
    "id": 1,
    "name": "Plumbing",
    "description": "Plumbing services including repairs and installations",
    "category": "Home Services"
  },
  "artisans": [
    {
      "id": 1,
      "name": "John Smith",
      "bio": "Expert plumber with 15 years experience...",
      "hourly_rate": 65.00,
      "rating": 4.8,
      "total_reviews": 42,
      "location": "Maseru",
      "availability_status": "available",
      "experience_years": 15
    },
    {
      "id": 5,
      "name": "Sarah Wilson",
      "bio": "Licensed plumber, emergency services...",
      "hourly_rate": 70.00,
      "rating": 4.8,
      "total_reviews": 39,
      "location": "Maseru",
      "availability_status": "available",
      "experience_years": 12
    }
  ]
}
```

**Error Response (Service Not Found - 404):**
```json
{
  "status": "error",
  "message": "Service not found"
}
```

---

## 4. SERVICES LIST ENDPOINT

### GET /api/services

**Purpose:** Get all available services

**Parameters:** None

**Example Request:**
```bash
curl http://localhost:5000/api/services
```

**Response Schema (200):**
```json
{
  "status": "success",
  "services": [
    {
      "id": 1,
      "name": "Plumbing",
      "description": "Plumbing services including repairs and installations",
      "category": "Home Services",
      "artisan_count": 2
    },
    {
      "id": 2,
      "name": "Carpentry",
      "description": "Carpentry and woodworking services",
      "category": "Home Improvement",
      "artisan_count": 4
    },
    {
      "id": 3,
      "name": "Electrical",
      "description": "Electrical services and installations",
      "category": "Home Services",
      "artisan_count": 3
    },
    {
      "id": 4,
      "name": "Painting",
      "description": "Interior and exterior painting services",
      "category": "Home Improvement",
      "artisan_count": 2
    }
  ]
}
```

---

## 5. DATABASE STATUS ENDPOINT

### GET /api/db-status

**Purpose:** Check database connectivity

**Parameters:** None

**Example Request:**
```bash
curl http://localhost:5000/api/db-status
```

**Response Schema (200):**
```json
{
  "status": "success",
  "database": "tradespro_db",
  "tables_count": 8,
  "tables": [
    "artisan_profiles",
    "artisan_services",
    "locations",
    "reviews",
    "services",
    "users",
    "payments",
    "notifications"
  ]
}
```

---

## 6. FIELD MAPPINGS

### Artisan Card Fields

| Frontend Field | API Field | Type | Description |
|---|---|---|---|
| Name | `name` | string | Full name of artisan |
| Service | `service_type` | string | Primary service offered |
| Location | `location` | string | City/district |
| Rate | `hourly_rate` | float | Cost per hour ($) |
| Rating | `rating` | float | Average score (0-5) |
| Reviews | `total_reviews` | int | Number of reviews |
| Bio | `bio` | string | Description/bio |
| ID | `id` | int | Unique identifier |
| Status | `availability_status` | string | available/busy/unavailable |
| Experience | `experience_years` | int | Years of experience |

---

## 7. FILTER LOGIC & COMBINATIONS

### How Filters Work

**AND Logic:** Multiple filters are combined with AND
```
service_type=Plumbing AND price_min=50 AND price_max=100 AND min_rating=4.5
```

**Price Filter:** Uses MAX(hourly_rate) from artisan_services
```sql
MAX(asvc.hourly_rate) >= price_min
AND MAX(asvc.hourly_rate) <= price_max
```

**Rating Filter:** Checks artisan_profiles.rating
```sql
ap.rating >= min_rating
```

**Service Filter:** Matches artisan_services.service_id
```sql
s.name = service_type
```

**Keyword Filter:** Searches multiple fields
```sql
u.name LIKE '%keyword%'
OR ap.bio LIKE '%keyword%'
OR s.name LIKE '%keyword%'
```

---

## 8. ERROR HANDLING

### Common Error Responses

**Invalid Parameter (400):**
```json
{
  "status": "error",
  "message": "Invalid price_min value"
}
```

**Not Found (404):**
```json
{
  "status": "error",
  "message": "Service not found"
}
```

**Server Error (500):**
```json
{
  "status": "error",
  "message": "Database connection failed"
}
```

---

## 9. RATE LIMITING & CACHING

**Current Limits:** No rate limiting implemented

**Caching:** No caching implemented (real-time data always)

**Performance:**
- Typical response time: 50-200ms
- Max results per request: 100
- Database connection: Pooled (5-10 connections)

---

## 10. AUTHENTICATION & AUTHORIZATION

**Current Status:** No authentication required

**Security:**
- CORS enabled
- SQL injection protection (parameterized queries)
- Input validation on all parameters
- No sensitive data in responses

---

## 11. PAGINATION (Future)

**Not Yet Implemented**

When implemented, will support:
```
?page=1&limit=20
```

Response will include:
```json
{
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 100,
    "pages": 5
  },
  "artisans": [...]
}
```

---

## 12. SORTING (Future)

**Not Yet Implemented**

When implemented, will support:
```
?sort=rating&order=desc
?sort=hourly_rate&order=asc
?sort=total_reviews&order=desc
```

---

## 13. TESTING EXAMPLES

### JavaScript/Web

```javascript
// Get all artisans
fetch('/api/search/artisans')
  .then(res => res.json())
  .then(data => {
    console.log('Total artisans:', data.total);
    data.artisans.forEach(a => console.log(a.name, a.hourly_rate));
  })

// Search with keyword
fetch('/api/search/artisans?keyword=plumbing')
  .then(res => res.json())
  .then(data => console.log('Found:', data.artisans.length))

// Advanced search
const params = new URLSearchParams({
  service_type: 'Carpentry',
  price_min: 50,
  price_max: 100,
  min_rating: 4.5
});
fetch(`/api/search/artisans?${params}`)
  .then(res => res.json())
  .then(data => console.log(data))
```

### PowerShell

```powershell
# All artisans
(Invoke-WebRequest -Uri 'http://localhost:5000/api/search/artisans' | ConvertFrom-Json).artisans

# Service search
$response = Invoke-WebRequest -Uri 'http://localhost:5000/api/search/by-service/Plumbing' -UseBasicParsing
$data = $response.Content | ConvertFrom-Json
$data.artisans | ForEach-Object { "$($_.name) - `$$($_.hourly_rate)/hr" }
```

### cURL

```bash
# Get services
curl http://localhost:5000/api/services | jq '.services[] | {name, artisan_count}'

# Search with filters
curl "http://localhost:5000/api/search/artisans?price_min=50&price_max=100" | jq '.artisans | length'
```

---

## 14. INTEGRATION CHECKLIST

- ✓ All endpoints tested and working
- ✓ Error handling implemented
- ✓ CORS enabled for cross-origin
- ✓ Response times acceptable
- ✓ Database connection stable
- ✓ Input validation working
- ✓ SQL injection protection active
- ✓ Documentation complete
- ✓ Test data loaded

---

## 15. SUPPORT & TROUBLESHOOTING

**Server Not Responding:**
1. Check Flask is running: `http://localhost:5000/api/health`
2. Verify MySQL is running
3. Check firewall settings
4. Review Flask server logs

**Invalid Response:**
1. Check parameter names spelling
2. Verify values are properly encoded
3. Review response schema above
4. Check DevTools Network tab

**Empty Results:**
1. Filters may be too restrictive
2. Try without filters first
3. Check test data is loaded
4. Review database content

---

**API Documentation Complete** ✓

Last Updated: 2024
Version: 1.0

