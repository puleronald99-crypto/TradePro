// ARTISAN DASHBOARD - COMPREHENSIVE IMPLEMENTATION
// Properly fetches and displays all data from the database

console.log("✅ artisan-dashboard.js LOADED - Script is executing");

// Currency mapping based on country/location
const COUNTRY_CURRENCY_MAP = {
    'US': { symbol: '$', code: 'USD' },
    'CA': { symbol: 'C$', code: 'CAD' },
    'UK': { symbol: '£', code: 'GBP' },
    'GB': { symbol: '£', code: 'GBP' },
    'AU': { symbol: 'A$', code: 'AUD' },
    'ZA': { symbol: 'R', code: 'ZAR' },
    'NG': { symbol: '₦', code: 'NGN' },
    'KE': { symbol: 'KSh', code: 'KES' },
    'UG': { symbol: 'USh', code: 'UGX' },
    'ET': { symbol: 'Br', code: 'ETB' },
    'ER': { symbol: 'Nfk', code: 'ERN' },
    'IN': { symbol: '₹', code: 'INR' },
    'PK': { symbol: '₨', code: 'PKR' },
    'BD': { symbol: '৳', code: 'BDT' },
    'PH': { symbol: '₱', code: 'PHP' },
    'TH': { symbol: '฿', code: 'THB' },
    'SG': { symbol: 'S$', code: 'SGD' },
    'MY': { symbol: 'RM', code: 'MYR' },
    'ID': { symbol: 'Rp', code: 'IDR' },
    'VN': { symbol: '₫', code: 'VND' },
    'BR': { symbol: 'R$', code: 'BRL' },
    'MX': { symbol: '$', code: 'MXN' },
    'AR': { symbol: '$', code: 'ARS' },
    'CL': { symbol: '$', code: 'CLP' },
    'CO': { symbol: '$', code: 'COP' },
    'PE': { symbol: 'S/', code: 'PEN' },
    'ZW': { symbol: '$', code: 'ZWL' },
    'EU': { symbol: '€', code: 'EUR' },
    'JP': { symbol: '¥', code: 'JPY' },
    'CN': { symbol: '¥', code: 'CNY' },
    'RU': { symbol: '₽', code: 'RUB' },
    'SA': { symbol: 'ر.س', code: 'SAR' },
    'AE': { symbol: 'د.إ', code: 'AED' },
    'EG': { symbol: 'E£', code: 'EGP' },
    'IL': { symbol: '₪', code: 'ILS' }
};

let artisanData = {
    user: {
        id: null,
        name: '',
        email: '',
        phone: '',
        profile_picture: null,
        country: 'US'
    },
    artisan: {
        id: null,
        bio: '',
        experience_years: 0,
        rating: 0.0,
        total_reviews: 0,
        verified: false,
        company_name: '',
        license_number: '',
        availability_status: 'available',
        service_radius_km: 15,
        country: 'US'
    },
    bookings: [],
    bookingFilter: 'all',
    services: [],
    reviews: [],
    availability: [],
    messages: [],
    messagePollingInterval: null,
    currency: { symbol: '$', code: 'USD' },
    earnings: {
        total_earnings: 0,
        currency: 'USD',
        earnings_list: [],
        booking_count: 0
    },
    payout_settings: {
        settings: {
            payout_frequency: 'weekly',
            minimum_payout: 10.00,
            auto_payout_enabled: true,
            last_payout_date: null,
            next_payout_date: null,
            primary_method_id: null
        },
        payout_methods: []
    }
};

// ==================== CURRENCY HELPERS ====================

function getCurrencySymbol() {
    // Try to get country from artisan data first, then from user
    const country = artisanData.artisan.country || artisanData.user.country || 'US';
    const currencyInfo = COUNTRY_CURRENCY_MAP[country.toUpperCase()] || { symbol: '$', code: 'USD' };
    return currencyInfo.symbol;
}

function updateCurrencyDisplay() {
    const symbol = getCurrencySymbol();
    
    // Update all currency symbols in the page
    const currencyElements = document.querySelectorAll('.currencySymbol, #currencySymbol, #currencySymbol2, #currencySymbol3');
    currencyElements.forEach(el => {
        el.textContent = symbol;
    });
    
    // Store in artisanData for use in dynamic content
    artisanData.currency.symbol = symbol;
}

// ==================== INITIALIZATION ====================

function initializeDashboard() {
    const userId = localStorage.getItem("userId");
    const isArtisan = localStorage.getItem("isArtisan");
    
    if (!userId || (isArtisan !== "1" && isArtisan !== "true")) {
        console.warn("Not logged in as artisan");
        window.location.href = "login.html";
        return;
    }
    
    console.log("Initializing artisan dashboard for user:", userId);
    loadAllData(userId);
}

function loadAllData(userId) {
    // Load all data in parallel
    Promise.allSettled([
        fetchUserData(userId),
        fetchArtisanData(userId),
        fetchBookings(userId),
        fetchServices(userId),
        fetchReviews(userId),
        fetchEarnings(userId),
        fetchAvailability(userId),
        fetchCertifications(userId),
        fetchSkills(userId),
        fetchUnavailableDates(userId),
        fetchMessages(userId)
    ]).then(() => {
        console.log("All data loaded successfully");
        updateCurrencyDisplay();
        updateUserDisplay();
        displayProfile();
        displayDashboard();
        loadNotifications(userId);
    }).catch(err => {
        console.error("Error loading data:", err);
        showNotification("Error loading dashboard data", "error");
    });
}

function loadNotifications(userId) {
    return fetch(`http://localhost:5000/api/user/${userId}/notifications`)
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'success') return;
            const badge = document.getElementById('notificationCount');
            if (badge) {
                badge.textContent = data.unread_count || 0;
                badge.hidden = !(data.unread_count > 0);
            }
            const dropdown = document.getElementById('notificationDropdown');
            if (dropdown) {
                dropdown.innerHTML = data.notifications.length
                    ? data.notifications.map(notification => `<div class="notification-item${notification.is_read ? '' : ' unread'}" data-notification-id="${notification.id}"><strong>${notification.title}</strong><p>${notification.message}</p><small>${new Date(notification.created_at).toLocaleString()}</small></div>`).join('')
                    : '<div class="notification-item"><p>No new notifications</p></div>';
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
}

// ==================== DATA FETCHING ====================

function fetchUserData(userId) {
    return fetch(`http://localhost:5000/api/user/${userId}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success' && data.user) {
                artisanData.user = data.user;
                console.log("User data loaded:", artisanData.user);
            }
            return data;
        })
        .catch(err => console.error("Error fetching user data:", err));
}

function fetchArtisanData(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/profile`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success' && data.profile) {
                const profile = data.profile;
                artisanData.artisan = {
                    id: profile.id,
                    bio: profile.bio || '',
                    experience_years: profile.experience_years || 0,
                    rating: profile.rating || 0.0,
                    total_reviews: profile.total_reviews || 0,
                    verified: profile.verified || false,
                    company_name: profile.company_name || '',
                    license_number: profile.license_number || '',
                    availability_status: profile.availability_status || 'available',
                    service_radius_km: profile.service_radius_km || 15,
                    response_time_minutes: profile.response_time_minutes || 60,
                    buffer_time_minutes: profile.buffer_time_minutes || 30,
                    is_premium: profile.is_premium || false,
                    profile_visible: profile.profile_visible !== false,
                    workplace_address: profile.workplace_address || '',
                    workplace_latitude: profile.workplace_latitude || null,
                    workplace_longitude: profile.workplace_longitude || null,
                    fuel_consumption_l_per_100km: profile.fuel_consumption_l_per_100km || 8,
                    fuel_price_per_liter: profile.fuel_price_per_liter || 0,
                    location_id: profile.location_id || null,
                    location: profile.location || '',
                    services: profile.services || []
                };
                artisanData.user.name = profile.name;
                artisanData.user.email = profile.email;
                artisanData.user.phone = profile.phone;
                artisanData.user.profile_picture = profile.profile_picture || null;
                console.log("Artisan data loaded:", artisanData.artisan);
            }
            return data;
        })
        .catch(err => console.error("Error fetching artisan data:", err));
}

function fetchBookings(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/bookings`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.bookings = (data.bookings || []).sort(compareBookingsNewestFirst);
                console.log("Bookings loaded:", artisanData.bookings);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching bookings:", err);
            artisanData.bookings = [];
        });
}

function fetchServices(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/services`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.services = data.services || [];
                console.log("Services loaded:", artisanData.services);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching services:", err);
            artisanData.services = [];
        });
}

function fetchReviews(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/reviews`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.reviews = data.reviews || [];
                console.log("Reviews loaded:", artisanData.reviews);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching reviews:", err);
            artisanData.reviews = [];
        });
}

function fetchEarnings(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/earnings`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.earnings = {
                    total_earnings: data.total_earnings || 0,
                    currency: data.currency || 'USD',
                    earnings_list: data.earnings_list || [],
                    booking_count: data.booking_count || 0
                };
                console.log("Earnings loaded:", artisanData.earnings);
                
                // Fetch payout settings as well
                return fetchPayoutSettings(userId);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching earnings:", err);
            artisanData.earnings = {
                total_earnings: 0,
                currency: 'USD',
                earnings_list: [],
                booking_count: 0
            };
        });
}

function fetchPayoutSettings(userId) {
    console.log("Fetching payout settings for user:", userId);
    
    return fetch(`http://localhost:5000/api/artisan/${userId}/payout-settings`)
        .then(res => {
            console.log('Payout settings response status:', res.status);
            return res.json();
        })
        .then(data => {
            console.log("Payout settings response data:", data);
            if (data.status === 'success') {
                artisanData.payout_settings = {
                    settings: data.settings,
                    payout_methods: data.payout_methods
                };
                console.log("Payout settings loaded successfully:", artisanData.payout_settings);
                displayPayoutSettings();
            } else {
                console.warn("Payout settings fetch returned non-success status:", data.message);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching payout settings:", err);
            // Initialize with default values if request fails
            artisanData.payout_settings = {
                settings: {
                    payout_frequency: 'weekly',
                    minimum_payout: 10,
                    auto_payout_enabled: false,
                    next_payout_date: null,
                    last_payout_date: null
                },
                payout_methods: []
            };
            displayPayoutSettings();
        });
}

function fetchAvailability(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/availability`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.availability = data.availability || [];
                console.log("Availability loaded:", artisanData.availability);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching availability:", err);
            artisanData.availability = [];
        });
}

function fetchCertifications(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/certifications`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (!artisanData.artisan) artisanData.artisan = {};
                artisanData.artisan.certifications = data.certifications || [];
                console.log("Certifications loaded:", artisanData.artisan.certifications);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching certifications:", err);
            if (!artisanData.artisan) artisanData.artisan = {};
            artisanData.artisan.certifications = [];
        });
}

function fetchSkills(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/skills`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (!artisanData.artisan) artisanData.artisan = {};
                artisanData.artisan.skills = data.skills || [];
                console.log("Skills loaded:", artisanData.artisan.skills);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching skills:", err);
            if (!artisanData.artisan) artisanData.artisan = {};
            artisanData.artisan.skills = [];
        });
}

function fetchUnavailableDates(userId) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/unavailable-dates`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (!artisanData.artisan) artisanData.artisan = {};
                artisanData.artisan.unavailable_dates = data.unavailable_dates || [];
                console.log("Unavailable dates loaded:", artisanData.artisan.unavailable_dates);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching unavailable dates:", err);
            if (!artisanData.artisan) artisanData.artisan = {};
            artisanData.artisan.unavailable_dates = [];
        });
}

function fetchMessages(userId, startPolling = true) {
    return fetch(`http://localhost:5000/api/artisan/${userId}/messages`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                artisanData.messages = data.messages || [];
                console.log("Messages loaded:", artisanData.messages);
                if (startPolling) startMessagePolling(userId);
                const messagesTab = document.getElementById('messages');
                const messageInput = document.getElementById('messageInput');
                const activeChatId = window.currentChatUserId;
                if (messagesTab?.classList.contains('active') && activeChatId &&
                    messageInput && document.activeElement !== messageInput && !messageInput.value) {
                    openChat(activeChatId);
                }
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching messages:", err);
            artisanData.messages = [];
        });
}

function startMessagePolling(userId) {
    if (artisanData.messagePollingInterval) clearInterval(artisanData.messagePollingInterval);
    artisanData.messagePollingInterval = setInterval(() => {
        fetchMessages(userId, false);
        loadNotifications(userId);
    }, 5000);
}

// ==================== DISPLAY FUNCTIONS ====================

function displayDashboard() {
    updateUserDisplay();
    displayDashboardOverview();
    displayProfile();
    displayServices();
    displayBookings();
    displayReviews();
    displayEarnings();
    displayPayoutSettings();
    displayAvailability();
    displayUnavailableDates();
    displaySkills();
    displayMessages();
    displaySettings();
}


function updateUserDisplay() {
    // Update topbar
    const topbarUserName = document.getElementById("topbarUserName");
    if (topbarUserName) topbarUserName.textContent = artisanData.user.name || "Artisan";
    
    // Update dashboard welcome
    const dashboardUserName = document.getElementById("dashboardUserName");
    if (dashboardUserName) dashboardUserName.textContent = artisanData.user.name || "Artisan";
    updateProfileAvatars(artisanData.user.profile_picture);
}

function updateProfileAvatars(profilePicture) {
    const imageUrl = profilePicture
        ? (profilePicture.startsWith('http') ? profilePicture : `http://localhost:5000${profilePicture}`)
        : 'https://via.placeholder.com/40';
    document.querySelectorAll('.user-avatar').forEach(image => {
        image.src = imageUrl;
    });
}

function displayDashboardOverview() {
    // Update stats on dashboard
    const stats = document.querySelectorAll('.stat-value');
    const currency = getCurrencySymbol();
    if (stats[0]) stats[0].textContent = `${currency}${artisanData.earnings.total_earnings.toFixed(2)}`; // real earnings
    if (stats[1]) stats[1].textContent = artisanData.bookings.length; // total bookings
    if (stats[2]) stats[2].textContent = artisanData.artisan.rating.toFixed(1); // rating
    if (stats[3]) stats[3].textContent = artisanData.artisan.experience_years; // experience
    
    // Display upcoming bookings
    const bookingList = document.querySelector('.booking-list');
    if (bookingList) {
        if (artisanData.bookings.length === 0) {
            bookingList.innerHTML = '<div class="empty-state"><p>No upcoming bookings</p></div>';
        } else {
            const upcoming = artisanData.bookings
                .filter(booking => booking.status === 'pending')
                .slice(0, 2);
            if (upcoming.length === 0) {
                bookingList.innerHTML = '<div class="empty-state"><p>No pending bookings</p></div>';
                return;
            }
            let html = '';
            upcoming.forEach(booking => {
                html += `
                    <div class="booking-item">
                        <div class="booking-time">
                            <span class="date">${booking.date || 'N/A'}</span>
                            <span class="time">${booking.time || 'N/A'}</span>
                        </div>
                        <div class="booking-details">
                            <h4>${booking.service_name}</h4>
                            <p>${booking.customer_name}</p>
                            <small>${booking.notes || 'No notes'}</small>
                        </div>
                        <div class="booking-actions">
                            <button class="btn btn-sm btn-primary" onclick="acceptBooking(${booking.id})">Accept</button>
                            <button class="btn btn-sm btn-outline" onclick="viewBookingDetails(${booking.id})">Details</button>
                        </div>
                    </div>
                `;
            });
            bookingList.innerHTML = html;
        }
    }
    
    // Display reviews overview
    const reviewList = document.querySelector('.review-list');
    if (reviewList) {
        if (artisanData.reviews.length === 0) {
            reviewList.innerHTML = '<p style="text-align: center; color: #999;">No reviews yet</p>';
        } else {
            const recent = artisanData.reviews.slice(0, 2);
            let html = '';
            recent.forEach(review => {
                const stars = '⭐'.repeat(Math.floor(review.rating));
                html += `
                    <div class="review-item">
                        <div class="review-header">
                            <h4>${review.customer_name}</h4>
                            <div class="stars">${stars}</div>
                        </div>
                        <p>"${review.comment}"</p>
                    </div>
                `;
            });
            reviewList.innerHTML = html;
        }
    }
}

function displayProfile() {
    const user = artisanData.user;
    const artisan = artisanData.artisan;
    
    if (!user || !artisan) {
        console.log("User or artisan data not available yet", { user, artisan });
        return;
    }
    
    console.log("Displaying profile with data:", { user, artisan });
    
    // Update profile header
    const profileName = document.getElementById('profileUserName');
    if (profileName) profileName.textContent = user.name || 'N/A';
    const profileImage = document.getElementById('artisanProfileImage');
    if (profileImage) {
        const picture = user.profile_picture;
        profileImage.src = picture
            ? (picture.startsWith('http') ? picture : `http://localhost:5000${picture}`)
            : 'https://via.placeholder.com/120';
    }
    
    // Update profile verification badge if verified
    const verifiedBadge = document.getElementById('profileVerified');
    if (artisan.verified || artisan.license_number) {
        if (verifiedBadge) verifiedBadge.style.display = 'inline-block';
    }
    
    // Update profile stats (rating, reviews, completion, experience)
    const statElements = document.querySelectorAll('.profile-stats span strong');
    if (statElements[0]) statElements[0].textContent = (artisan.rating || 0).toFixed(1); // Rating
    if (statElements[1]) statElements[1].textContent = artisan.total_reviews || 0; // Reviews
    if (statElements[3]) statElements[3].textContent = (artisan.years_in_business || artisan.experience_years || 0); // Experience
    
    // Get all detail rows
    const detailRows = document.querySelectorAll('.detail-row');
    
    // Contact Information section (rows 0-2)
    const contactEmail = detailRows[0]?.querySelector('span:last-child');
    if (contactEmail) contactEmail.textContent = user.email || 'Not provided';
    
    const contactPhone = detailRows[1]?.querySelector('span:last-child');
    if (contactPhone) contactPhone.textContent = user.phone || 'Not provided';
    
    const contactLocation = detailRows[2]?.querySelector('span:last-child');
    if (contactLocation) contactLocation.textContent = (artisan.location || 'Not provided');
    
    // Professional Information section (rows 3-6)
    const serviceType = detailRows[3]?.querySelector('span:last-child');
    const serviceName = artisan.services && artisan.services.length > 0 
        ? artisan.services[0].name 
        : 'Not provided';
    if (serviceType) serviceType.textContent = serviceName;
    
    const licenseNumber = detailRows[4]?.querySelector('span:last-child');
    if (licenseNumber) licenseNumber.textContent = (artisan.license_number || 'Not provided');
    
    const experience = detailRows[5]?.querySelector('span:last-child');
    const expYears = artisan.experience_years || 0;
    if (experience) experience.textContent = (expYears + ' years');
    
    // Bio section - special case as it's a paragraph
    const bioPara = detailRows[6]?.querySelector('p');
    if (bioPara) {
        bioPara.textContent = (artisan.bio || 'Not provided');
    }
    
    // Display certifications
    displayCertifications();
}

function displayCertifications() {
    const certList = document.querySelector('.cert-list');
    if (!certList || !artisanData.artisan.certifications) return;
    
    const certs = artisanData.artisan.certifications;
    const userId = localStorage.getItem("userId");
    
    if (certs.length === 0) {
        certList.innerHTML = `
            <p style="color: #888;">No certifications added yet.</p>
            <button class="btn btn-primary btn-sm" onclick="addCertification()">Add Certification</button>
        `;
        return;
    }
    
    let html = '';
    certs.forEach(cert => {
        const expiry = cert.expiry_date ? ` (Expires: ${cert.expiry_date})` : '';
        const issuer = cert.issuer ? ` - ${cert.issuer}` : '';
        html += `
            <div class="cert-item" style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #eee;">
                <div style="flex: 1;">
                    <i class="fa fa-certificate"></i>
                    <span>${cert.name}${issuer}${expiry}</span>
                </div>
                <div style="display: flex; gap: 4px;">
                    <button class="btn btn-sm btn-warning" onclick="editCertification(${cert.id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteCertification(${cert.id})">Delete</button>
                </div>
            </div>
        `;
    });
    certList.innerHTML = html + `<button class="btn btn-primary btn-sm" onclick="addCertification()" style="margin-top: 8px;">Add another</button>`;
}

function displaySkills() {
    const skillsContainer = document.querySelector('.skills-container');
    if (!skillsContainer) return;
    
    // Create skills section if it doesn't exist
    const profileContainer = document.querySelector('.profile-detail');
    if (!profileContainer.querySelector('.skills-container')) {
        const skillsSection = document.createElement('div');
        skillsSection.className = 'skills-container';
        skillsSection.innerHTML = '<h3>Skills</h3><div class="skills-list"></div>';
        profileContainer.appendChild(skillsSection);
    }
    
    const skills = artisanData.artisan.skills || [];
    const skillsList = document.querySelector('.skills-list');
    
    if (!skillsList) return;
    
    if (skills.length === 0) {
        skillsList.innerHTML = `
            <p style="color: #888;">No skills added yet.</p>
            <button class="btn btn-primary btn-sm" onclick="addSkill()">Add Skill</button>
        `;
        return;
    }
    
    let html = '';
    skills.forEach(skill => {
        html += `
            <div class="skill-item" style="display: flex; justify-content: space-between; align-items: center; padding: 8px; background: #f5f5f5; margin: 4px 0; border-radius: 4px;">
                <div style="flex: 1;">
                    <strong>${skill.name}</strong> <span style="color: #666; font-size: 0.9em;">${skill.proficiency_level}</span>
                    ${skill.category ? `<br><span style="color: #999; font-size: 0.85em;">${skill.category}</span>` : ''}
                </div>
                <button class="btn btn-sm btn-danger" onclick="deleteSkill(${skill.artisan_skill_id})">Remove</button>
            </div>
        `;
    });
    skillsList.innerHTML = html + `<button class="btn btn-primary btn-sm" onclick="addSkill()" style="margin-top: 8px;">Add another</button>`;
}

function displaySettings() {
    // Update email display with real user data
    const emailDisplay = document.getElementById('emailDisplay');
    if (emailDisplay) {
        emailDisplay.textContent = artisanData.user.email || 'No email set';
    }
    
    // Update service area radius
    const serviceAreaDisplay = document.getElementById('serviceAreaDisplay');
    if (serviceAreaDisplay) {
        const radius = artisanData.artisan.service_radius_km || 15;
        serviceAreaDisplay.textContent = radius + ' km from your location';
    }
    
    // Update response time (default values from artisan data)
    const responseTimeDisplay = document.getElementById('responseTimeDisplay');
    if (responseTimeDisplay) {
        const responseTime = artisanData.artisan.response_time_minutes || 60;
        responseTimeDisplay.textContent = responseTime < 60 ? `Within ${responseTime} minutes` : `Within ${responseTime / 60} hour${responseTime === 60 ? '' : 's'}`;
    }
    
    // Update buffer time
    const bufferTimeDisplay = document.getElementById('bufferTimeDisplay');
    if (bufferTimeDisplay) {
        const bufferTime = artisanData.artisan.buffer_time_minutes ?? 30;
        bufferTimeDisplay.textContent = bufferTime === 0 ? 'No buffer' : `${bufferTime} minutes between jobs`;

    const premiumStatus = document.getElementById('premiumStatus');
    const premiumButton = document.getElementById('premiumToggleBtn');
    if (premiumStatus) premiumStatus.textContent = artisanData.artisan.is_premium ? 'Subscribed' : 'Not Subscribed';
    if (premiumButton) premiumButton.textContent = artisanData.artisan.is_premium ? 'Disable Premium' : 'Enable Premium';
    }
    
    console.log('Settings display updated with real user data');
}

function displayServices() {
    const servicesGrid = document.querySelector('.services-grid');
    if (!servicesGrid) return;
    
    const currency = getCurrencySymbol();
    
    if (artisanData.services.length === 0) {
        servicesGrid.innerHTML = `
            <div class="empty-state">
                <p>No services added yet.</p>
                <button class="btn btn-primary btn-sm" onclick="addService()">Add your first service</button>
            </div>
        `;
        return;
    }
    
    let html = '';
    artisanData.services.forEach(service => {
        html += `
            <div class="service-card">
                <div class="service-header">
                    <h3>${service.name}</h3>
                    <div class="service-actions">
                        <button class="btn-icon" title="Edit" onclick="editService(${service.id})">
                            <i class="fa fa-pencil"></i>
                        </button>
                        <button class="btn-icon" title="Delete" onclick="deleteService(${service.id})">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="service-details">
                    <p>${service.description || 'Professional service'}</p>
                    <div class="service-meta">
                        <span class="badge badge-info">${currency}${service.hourly_rate.toFixed(2)}/hour</span>
                        <span class="badge badge-success">Active</span>
                    </div>
                </div>
            </div>
        `;
    });
    
    servicesGrid.innerHTML = html;
}

function displayBookings() {
    const bookingsContainer = document.querySelector('.bookings-list');
    if (!bookingsContainer) return;
    
    const selectedFilter = artisanData.bookingFilter || 'all';
    const bookings = artisanData.bookings.filter(booking => selectedFilter === 'all' || booking.status === selectedFilter);

    if (bookings.length === 0) {
        bookingsContainer.innerHTML = '<div class="empty-state"><p>No bookings yet. Accept jobs to get started!</p></div>';
        return;
    }
    
    let html = '';
    bookings.forEach(booking => {
        const statusClass = `badge-${booking.status === 'pending' ? 'warning' : booking.status === 'confirmed' ? 'info' : booking.status === 'completed' ? 'success' : 'secondary'}`;
        
        html += `
            <div class="booking-card">
                <div class="booking-card-header">
                    <h3>${booking.service_name}</h3>
                    <span class="badge ${statusClass}">${booking.status}</span>
                </div>
                <div class="booking-card-body">
                    <div class="booking-info">
                        <div class="info-item">
                            <span class="label">Customer</span>
                            <span>${booking.customer_name}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">Date & Time</span>
                            <span>${booking.date} ${booking.time}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">Notes</span>
                            <span>${booking.notes || 'No notes'}</span>
                        </div>
                            <div class="info-item">
                                <span class="label">Travel estimate</span>
                                <span>${booking.distance_km ? `${booking.distance_km.toFixed(1)} km · about ${booking.estimated_travel_minutes || '?'} min` : 'Location not provided'}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Estimated fuel</span>
                                <span>${booking.estimated_fuel_cost !== null && booking.estimated_fuel_cost !== undefined ? `${getCurrencySymbol()}${booking.estimated_fuel_cost.toFixed(2)}` : 'Set fuel settings'}</span>
                            </div>
                    </div>
                </div>
                <div class="booking-card-footer">
                    ${booking.status === 'pending' ? `
                        <button class="btn btn-primary" onclick="acceptBooking(${booking.id})">Accept</button>
                        <button class="btn btn-secondary" onclick="declineBooking(${booking.id})">Decline</button>
                    ` : booking.status === 'confirmed' ? `
                        <button class="btn btn-info" onclick="startBooking(${booking.id})">Start Job</button>
                    ` : booking.status === 'in_progress' ? `
                        <button class="btn btn-success" onclick="completeBooking(${booking.id})">Complete Job</button>
                    ` : ''}
                    <button class="btn btn-outline" onclick="viewBookingDetails(${booking.id})">View Details</button>
                </div>
            </div>
        `;
    });
    
    bookingsContainer.innerHTML = html;
}

function compareBookingsNewestFirst(left, right) {
    const leftDate = new Date(`${left.date || '1970-01-01'}T${left.time || '00:00:00'}`).getTime();
    const rightDate = new Date(`${right.date || '1970-01-01'}T${right.time || '00:00:00'}`).getTime();
    return rightDate - leftDate;
}

function filterBookings(status) {
    artisanData.bookingFilter = status;
    document.querySelectorAll('.filter-buttons .btn').forEach(button => button.classList.remove('active'));
    const activeButton = Array.from(document.querySelectorAll('.filter-buttons .btn')).find(button => button.getAttribute('onclick') === `filterBookings('${status}')`);
    if (activeButton) activeButton.classList.add('active');
    displayBookings();
}

function displayReviews() {
    const reviewsContainer = document.querySelector('.reviews-container');
    const ratingBox = document.querySelector('.rating-box');
    
    if (!reviewsContainer) return;
    
    // Update rating summary if exists
    if (ratingBox) {
        const avgRating = artisanData.artisan.rating || 0;
        const ratingStars = Math.round(avgRating * 2) / 2; // Round to nearest 0.5
        const fullStars = Math.floor(ratingStars);
        const hasHalfStar = ratingStars % 1 !== 0;
        
        let starsHtml = '';
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                starsHtml += '<i class="fa fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                starsHtml += '<i class="fa fa-star-half-o"></i>';
            } else {
                starsHtml += '<i class="fa fa-star-o"></i>';
            }
        }
        
        ratingBox.innerHTML = `
            <p class="rating-value">${avgRating.toFixed(1)}</p>
            <div class="stars">${starsHtml}</div>
            <small>Based on ${artisanData.artisan.total_reviews || 0} reviews</small>
        `;
    }
    
    if (artisanData.reviews.length === 0) {
        reviewsContainer.innerHTML = '<div class="empty-state"><p>No reviews yet. Complete jobs to receive reviews!</p></div>';
        return;
    }
    
    let html = '';
    artisanData.reviews.forEach(review => {
        // Create star display
        let starsHtml = '';
        for (let i = 0; i < 5; i++) {
            if (i < review.rating) {
                starsHtml += '<i class="fa fa-star"></i>';
            } else {
                starsHtml += '<i class="fa fa-star-o"></i>';
            }
        }
        
        const reviewDate = new Date(review.created_at);
        const daysAgo = Math.floor((new Date() - reviewDate) / (1000 * 60 * 60 * 24));
        const timeStr = daysAgo === 0 ? 'Today' : daysAgo === 1 ? '1 day ago' : daysAgo + ' days ago';
        
        html += `
            <div class="review-card">
                <div class="review-header">
                    <div>
                        <h4>${review.customer_name}</h4>
                        <div class="stars">${starsHtml}</div>
                    </div>
                    <small>${timeStr}</small>
                </div>
                <p>"${review.comment || 'No comment provided'}"</p>
                <div class="review-actions">
                    <button class="btn btn-sm btn-primary" onclick="replyReview(${review.id})">Reply</button>
                </div>
            </div>
        `;
    });
    
    reviewsContainer.innerHTML = html;
}

function displayMessages() {
    const messagesList = document.getElementById('messagesList');
    const chatWindow = document.getElementById('chatWindow');
    const emptyMessagesState = document.getElementById('emptyMessagesState');
    
    if (!messagesList) return;
    
    // Check if there are any messages or conversations
    if (!artisanData.messages || artisanData.messages.length === 0) {
        // No messages - show empty state
        messagesList.style.display = 'none';
        chatWindow.style.display = 'none';
        if (emptyMessagesState) emptyMessagesState.style.display = 'flex';
        return;
    }
    
    // Show the messages list and hide empty state
    messagesList.style.display = 'flex';
    if (emptyMessagesState) emptyMessagesState.style.display = 'none';
    
    // Build message threads
    let html = '';
    artisanData.messages.forEach(thread => {
        const lastMessage = thread.last_message || '';
        const unreadCount = thread.unread_count || 0;
        const unreadBadge = unreadCount > 0 ? `<div class="unread-badge">${unreadCount}</div>` : '';
        html += `
            <div class="message-thread" onclick="openChat(${thread.user_id || thread.id}, event)">
                <div class="message-avatar">
                    <img src="${thread.avatar || 'https://via.placeholder.com/50'}" alt="${thread.user_name || 'User'}" />
                </div>
                <div class="message-preview">
                    <h4>${thread.user_name || 'Unknown User'}</h4>
                    <p>${lastMessage}</p>
                    <small>${thread.last_message_time || 'Just now'}</small>
                </div>
                ${unreadBadge}
            </div>
        `;
    });
    
    messagesList.innerHTML = `<div class="messages-list-heading"><strong>Inbox</strong><span>${artisanData.messages.length}</span></div>` + html;
    chatWindow.style.display = 'flex';
}

function openChat(userId, event) {
    if (event) event.stopPropagation();
    
    const chatWindow = document.getElementById('chatWindow');
    const chatWindowTitle = document.getElementById('chatWindowTitle');
    const chatMessages = document.getElementById('chatMessages');
    const messagesList = document.getElementById('messagesList');
    
    // Find the conversation
    const conversation = artisanData.messages.find(m => m.user_id === userId || m.id === userId);
    
    if (!conversation) {
        console.warn("Conversation not found for user:", userId);
        return;
    }

    const currentUserId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/user/${currentUserId}/messages/${userId}`, { method: 'PUT' })
        .then(() => {
            conversation.unread = false;
            conversation.unread_count = 0;
            event?.currentTarget?.querySelector('.unread-badge')?.remove();
            loadNotifications(currentUserId);
        })
        .catch(error => console.error('Unable to mark conversation read:', error));
    
    // Update UI
    chatWindowTitle.textContent = conversation.user_name || 'Chat';
    chatWindow.style.display = 'flex';
    window.currentChatUserId = userId;
    const chatImage = document.getElementById('chatProfileImage');
    if (chatImage) chatImage.src = conversation.avatar || 'https://via.placeholder.com/40';
    const chatPanel = document.getElementById('chatProfilePanel');
    if (chatPanel) chatPanel.innerHTML = `<i class="fa fa-user-circle"></i><h3>${conversation.user_name || 'Client'}</h3><p>Client conversation on TradePro</p>`;
    
    // Mark active thread
    const threads = document.querySelectorAll('.message-thread');
    threads.forEach(t => t.classList.remove('active'));
    event?.currentTarget?.classList.add('active');
    
    // Display chat messages
    let messagesHtml = '';
    const messages = conversation.messages || [];
    
    if (messages.length === 0) {
        messagesHtml = '<div style="text-align: center; color: #999; padding: 20px;">No messages yet. Start the conversation!</div>';
    } else {
        messages.forEach(msg => {
            const msgClass = msg.sender === 'artisan' ? 'sent' : 'received';
            messagesHtml += `
                <div class="message ${msgClass}">
                    <p>${msg.content || msg.message_text || msg.text || ''}</p>
                    <small>${msg.timestamp || msg.time || ''}</small>
                </div>
            `;
        });
    }
    
    chatMessages.innerHTML = messagesHtml;
    
    // Scroll to bottom
    setTimeout(() => {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 100);
}

function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value.trim();
    
    if (!messageText) {
        return;
    }
    
    // Get current conversation
    const chatWindowTitle = document.getElementById('chatWindowTitle');
    const currentUserName = chatWindowTitle.textContent;
    
    const conversation = artisanData.messages.find(m => m.user_name === currentUserName);
    if (!conversation) {
        showNotification('Select a conversation before sending a message.', 'warning');
        messageInput.focus();
        return;
    }
    
    const userId = localStorage.getItem("userId");
    const recipientId = conversation.user_id || conversation.id;
    
    // Send message to backend
    fetch(`http://localhost:5000/api/user/${userId}/messages`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            sender_id: userId,
            recipient_id: recipientId,
            content: messageText
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            // Clear input
            messageInput.value = '';
            
            // Add message to UI immediately
            const chatMessages = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message sent';
            messageDiv.innerHTML = `
                <p>${messageText}</p>
                <small>Just now</small>
            `;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            console.log("Message sent successfully");
        } else {
            showNotification("Failed to send message", "error");
        }
    })
    .catch(err => {
        console.error("Error sending message:", err);
        showNotification("Error sending message", "error");
    });
}

function callCustomer() {
    const customerId = window.currentChatUserId;
    if (!customerId) return showNotification('Select a client conversation first.', 'warning');
    fetch(`http://localhost:5000/api/user/${customerId}`)
        .then(response => response.json())
        .then(result => {
            const phone = result.user?.phone;
            if (!phone) throw new Error('This client has not added a phone number.');
            window.location.href = `tel:${phone}`;
        })
        .catch(error => showNotification(error.message, 'warning'));
}

function closeChat() {
    const chatWindow = document.getElementById('chatWindow');
    if (chatWindow) chatWindow.style.display = 'none';
    const messagesList = document.getElementById('messagesList');
    if (messagesList) messagesList.style.display = 'flex';
}

function displayEarnings() {
    const earnings = artisanData.earnings;
    if (!earnings) return;
    
    const currency = getCurrencySymbol();
    
    // Update summary cards
    const summaryCards = document.querySelectorAll('.summary-card');
    const totalEarnings = earnings.total_earnings || 0;
    const jobCount = earnings.booking_count || 0;
    const avgPerJob = jobCount > 0 ? (totalEarnings / jobCount).toFixed(2) : 0;
    
    if (summaryCards[0]) {
        summaryCards[0].innerHTML = `<h3>Total Earnings</h3><p class="summary-value">${currency}${totalEarnings.toFixed(2)}</p><small>All time</small>`;
    }
    if (summaryCards[1]) {
        summaryCards[1].innerHTML = `<h3>Completed Jobs</h3><p class="summary-value">${jobCount}</p><small>Total completed</small>`;
    }
    if (summaryCards[2]) {
        summaryCards[2].innerHTML = `<h3>Average Per Job</h3><p class="summary-value">${currency}${avgPerJob}</p><small>Average earnings</small>`;
    }
    
    // Update transaction list
    const transactionList = document.querySelector('.transaction-list');
    if (!transactionList) return;
    
    if (!earnings.earnings_list || earnings.earnings_list.length === 0) {
        transactionList.innerHTML = '<div class="empty-state"><p>No completed bookings yet. Complete jobs to earn money!</p></div>';
        return;
    }
    
    let html = '';
    earnings.earnings_list.forEach(earning => {
        const statusBadge = earning.status === 'completed' ? 'badge-success' : earning.status === 'paid' ? 'badge-success' : 'badge-warning';
        html += `
            <div class="transaction-item">
                <div class="transaction-info">
                    <h4>${earning.service_name} - ${earning.customer_name}</h4>
                    <small>${earning.date}</small>
                </div>
                <div class="transaction-amount">
                    <span class="amount">+${currency}${earning.amount.toFixed(2)}</span>
                    <span class="status ${statusBadge}">${earning.status}</span>
                </div>
            </div>
        `;
    });
    
    transactionList.innerHTML = html;
}

function openBusinessDocument(type) {
    const isInvoice = type === 'invoice';
    const title = isInvoice ? 'Create Invoice' : 'Create Quotation';
    const actionLabel = isInvoice ? 'Invoice' : 'Quotation';
    showModal(title, `
        <form class="form" onsubmit="event.preventDefault(); previewBusinessDocument('${type}');">
            <div class="form-group"><label for="documentCustomer">Customer name</label><input id="documentCustomer" required placeholder="Customer or company" /></div>
            <div class="form-group"><label for="documentService">Service</label><input id="documentService" required placeholder="Service description" /></div>
            <div class="form-group"><label for="documentAmount">Amount</label><input id="documentAmount" type="number" min="0" step="0.01" required placeholder="0.00" /></div>
            <div class="form-group"><label for="documentDate">${isInvoice ? 'Due date' : 'Valid until'}</label><input id="documentDate" type="date" required /></div>
            <div class="form-group"><label for="documentNotes">Notes</label><textarea id="documentNotes" placeholder="Terms, scope, or payment notes"></textarea></div>
            <button class="btn btn-primary" type="submit"><i class="fa fa-eye"></i> Preview ${actionLabel}</button>
        </form>
    `);
}

function previewBusinessDocument(type) {
    const customer = document.getElementById('documentCustomer').value.trim();
    const service = document.getElementById('documentService').value.trim();
    const amount = Number(document.getElementById('documentAmount').value || 0).toFixed(2);
    const date = document.getElementById('documentDate').value;
    const notes = document.getElementById('documentNotes').value.trim() || 'Thank you for choosing TradePro.';
    const isInvoice = type === 'invoice';
    const documentNumber = `${isInvoice ? 'INV' : 'QUO'}-${Date.now().toString().slice(-6)}`;
    const currency = artisanData.currency.symbol || '$';
    const artisanName = artisanData.artisan.company_name || artisanData.user.name || 'TradePro Artisan';
    const documentHtml = `
        <article class="business-document" id="businessDocument">
            <header><div><h2>${isInvoice ? 'INVOICE' : 'QUOTATION'}</h2><p>${documentNumber}</p></div><strong>${artisanName}</strong></header>
            <hr><p><strong>Customer:</strong> ${customer}</p><p><strong>${isInvoice ? 'Due date' : 'Valid until'}:</strong> ${date}</p>
            <table><thead><tr><th>Description</th><th>Amount</th></tr></thead><tbody><tr><td>${service}</td><td>${currency}${amount}</td></tr></tbody><tfoot><tr><th>Total</th><th>${currency}${amount}</th></tr></tfoot></table>
            <p><strong>Notes</strong><br>${notes}</p>
        </article>
        <div class="document-actions"><button class="btn btn-primary" onclick="printBusinessDocument()"><i class="fa fa-print"></i> Print / Save PDF</button><button class="btn btn-secondary" onclick="copyBusinessDocument()"><i class="fa fa-copy"></i> Copy</button></div>
    `;
    showModal(`${isInvoice ? 'Invoice' : 'Quotation'} Preview`, documentHtml);
}

function printBusinessDocument() {
    const content = document.getElementById('businessDocument')?.outerHTML;
    if (!content) return;
    const printWindow = window.open('', '_blank', 'width=800,height=900');
    printWindow.document.write(`<html><head><title>TradePro document</title><style>body{font:14px Arial;color:#172033;padding:40px}header{display:flex;justify-content:space-between}table{width:100%;border-collapse:collapse;margin:30px 0}th,td{border-bottom:1px solid #dbe3ef;padding:12px;text-align:left}th:last-child,td:last-child{text-align:right}</style></head><body>${content}</body></html>`);
    printWindow.document.close();
    printWindow.print();
}

function copyBusinessDocument() {
    const content = document.getElementById('businessDocument')?.innerText;
    if (!content) return;
    navigator.clipboard.writeText(content).then(() => showNotification('Document copied to clipboard.', 'success'));
}

function displayPayoutSettings() {
    if (!artisanData.payout_settings) return;
    
    const { settings, payout_methods } = artisanData.payout_settings;
    
    // Find primary payment method
    const primaryMethod = payout_methods.find(m => m.is_primary);
    let paymentMethodDisplay = 'Not configured';
    
    if (primaryMethod) {
        const methodName = {
            'mpesa': 'M-Pesa',
            'ecocash': 'EcoCash',
            'mywallet': 'MyWallet',
            'bank_transfer': 'Bank Transfer',
            'paypal': 'PayPal',
            'stripe': 'Stripe',
            'flutterwave': 'Flutterwave',
            'afrimozo': 'AfriMozo',
            'innov8': 'Innov8'
        };
        
        paymentMethodDisplay = `${methodName[primaryMethod.payment_method] || primaryMethod.payment_method} • ${primaryMethod.account_number}`;
    }
    
    // Update payout info display
    const primaryPayoutMethod = document.getElementById('primaryPayoutMethod');
    if (primaryPayoutMethod) {
        primaryPayoutMethod.textContent = paymentMethodDisplay;
    }
    
    const nextPayoutDate = document.getElementById('nextPayoutDate');
    if (nextPayoutDate) {
        nextPayoutDate.textContent = settings.next_payout_date || 'Not scheduled';
    }
    
    const payoutFrequency = document.getElementById('payoutFrequency');
    if (payoutFrequency) {
        const frequencyLabels = {
            'weekly': 'Weekly',
            'biweekly': 'Bi-weekly',
            'monthly': 'Monthly',
            'manual': 'Manual only'
        };
        payoutFrequency.textContent = frequencyLabels[settings.payout_frequency] || settings.payout_frequency;
    }
}


// ==================== PAYOUT SETTINGS ====================

function editPayoutMethod() {
    try {
        console.log("=== editPayoutMethod CALLED ===");
        
        const userId = localStorage.getItem("userId");
        console.log("userId from localStorage:", userId);
        
        if (!userId) {
            console.warn("No userId found - user not logged in");
            alert("Please log in first to manage payment methods");
            return;
        }
        
        console.log("Loading payout settings for user:", userId);
        
        // Show loading state
        showNotification('Loading payment methods...', 'info');
        
        fetch(`http://localhost:5000/api/artisan/${userId}/payout-settings`)
            .then(res => {
                console.log('Response status:', res.status);
                if (!res.ok) {
                    throw new Error(`HTTP ${res.status}`);
                }
                return res.json();
            })
            .then(data => {
                console.log('Payout data received:', data);
                if (data.status === 'success') {
                    console.log('Building payment method modal...');
                    showPayoutMethodModal(userId, data.payout_methods || []);
                    showNotification('Payment methods loaded', 'success');
                } else {
                    throw new Error(data.message || 'Unknown error');
                }
            })
            .catch(err => {
                console.error('Error in editPayoutMethod:', err);
                alert('Error: ' + err.message + '\n\nMake sure the backend is running on localhost:5000');
            });
    } catch (error) {
        console.error("CRITICAL ERROR in editPayoutMethod:", error);
        alert("Critical Error: " + error.message);
    }
}

function showPayoutMethodModal(userId, payoutMethods) {
    console.log("=== showPayoutMethodModal CALLED ===");
    console.log("User ID:", userId);
    console.log("Payment Methods:", payoutMethods);
    
    const paymentMethodsOptions = [
        { code: 'mpesa', label: 'M-Pesa' },
        { code: 'ecocash', label: 'EcoCash' },
        { code: 'mywallet', label: 'MyWallet' },
        { code: 'bank_transfer', label: 'Bank Transfer' },
        { code: 'paypal', label: 'PayPal' },
        { code: 'stripe', label: 'Stripe' },
        { code: 'flutterwave', label: 'Flutterwave' },
        { code: 'afrimozo', label: 'AfriMozo' },
        { code: 'innov8', label: 'Innov8' }
    ];
    
    let methodsHTML = '';
    
    if (payoutMethods && payoutMethods.length > 0) {
        methodsHTML = '<div style="margin-bottom: 20px;"><h4>Your Payment Methods</h4>';
        payoutMethods.forEach(method => {
            const methodLabel = paymentMethodsOptions.find(m => m.code === method.payment_method)?.label || method.payment_method;
            const primaryBadge = method.is_primary ? '<span style="background: #4caf50; color: white; padding: 2px 8px; border-radius: 3px; font-size: 0.8em; margin-left: 8px;">Primary</span>' : '';
            const verifiedBadge = method.is_verified ? '<span style="background: #2196f3; color: white; padding: 2px 8px; border-radius: 3px; font-size: 0.8em; margin-left: 4px;">✓ Verified</span>' : '';
            
            methodsHTML += `
                <div style="border: 1px solid #ddd; padding: 12px; margin-bottom: 10px; border-radius: 4px; background: #f9f9f9;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong>${methodLabel}</strong> ${primaryBadge} ${verifiedBadge}
                            <br><small>${method.account_holder_name || 'Account'} • ${method.account_number || 'No account'}</small>
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button class="btn btn-sm btn-warning" onclick="editPayoutMethodModal(${method.id}, '${method.payment_method}', ${userId})">Edit</button>
                            <button class="btn btn-sm btn-danger" onclick="deletePayoutMethod(${method.id}, ${userId})">Delete</button>
                        </div>
                    </div>
                </div>
            `;
        });
        methodsHTML += '</div>';
    } else {
        methodsHTML = '<div style="padding: 16px; background: #f5f5f5; border-radius: 4px; margin-bottom: 20px;"><p style="margin: 0; color: #666;">No payment methods added yet. Add your first payment method below.</p></div>';
    }
    
    const form = `
        <div>
            ${methodsHTML}
            <hr style="margin: 20px 0;">
            <h4>Add New Payment Method</h4>
            <form onsubmit="saveNewPayoutMethod(event, ${userId})" class="form">
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select id="paymentMethod" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- Select Payment Method --</option>
                        ${paymentMethodsOptions.map(m => `<option value="${m.code}">${m.label}</option>`).join('')}
                    </select>
                </div>
                <div id="methodFields"></div>
                <button type="submit" class="btn btn-primary" style="margin-top: 12px;">Add Payment Method</button>
            </form>
        </div>
    `;
    
    console.log("Showing modal with form...");
    showModalWithForm('Manage Payment Methods', form);
    
    // Use setTimeout to ensure DOM is updated before attaching listeners
    setTimeout(() => {
        try {
            const paymentMethodSelect = document.getElementById('paymentMethod');
            if (paymentMethodSelect) {
                console.log("Attaching change listener to payment method select");
                paymentMethodSelect.addEventListener('change', function() {
                    console.log("Payment method changed to:", this.value);
                    updatePaymentMethodFields(this.value);
                });
            } else {
                console.warn("paymentMethod select element not found in DOM");
            }
        } catch (err) {
            console.error("Error attaching event listener:", err);
        }
    }, 100);
}

function updatePaymentMethodFields(method) {
    const fieldsContainer = document.getElementById('methodFields');
    let fieldsHTML = '';
    
    const commonFields = {
        account_holder_name: { label: 'Account Holder Name', type: 'text', required: true },
        account_type: { label: 'Account Type', type: 'text', placeholder: 'Savings/Checking' }
    };
    
    const methodSpecificFields = {
        mpesa: {
            phone_number: { label: 'M-Pesa Phone Number', type: 'tel', placeholder: '+256...', required: true }
        },
        ecocash: {
            phone_number: { label: 'EcoCash Phone Number', type: 'tel', required: true }
        },
        mywallet: {
            email: { label: 'MyWallet Email', type: 'email', required: true }
        },
        bank_transfer: {
            bank_name: { label: 'Bank Name', type: 'text', required: true },
            account_number: { label: 'Account Number', type: 'text', required: true },
            branch_code: { label: 'Branch Code', type: 'text' }
        },
        paypal: {
            email: { label: 'PayPal Email', type: 'email', required: true }
        },
        stripe: {
            email: { label: 'Stripe Email', type: 'email', required: true }
        },
        flutterwave: {
            email: { label: 'Flutterwave Email', type: 'email', required: true }
        },
        afrimozo: {
            phone_number: { label: 'AfriMozo Phone Number', type: 'tel', required: true }
        },
        innov8: {
            phone_number: { label: 'Innov8 Phone Number', type: 'tel', required: true }
        }
    };
    
    const fields = { ...commonFields, ...(methodSpecificFields[method] || {}) };
    
    Object.entries(fields).forEach(([key, config]) => {
        const required = config.required ? 'required' : '';
        fieldsHTML += `
            <div class="form-group">
                <label>${config.label}</label>
                <input type="${config.type}" id="${key}" placeholder="${config.placeholder || ''}" ${required} 
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
            </div>
        `;
    });
    
    fieldsContainer.innerHTML = fieldsHTML;
}

function saveNewPayoutMethod(event, userId) {
    event.preventDefault();
    
    const method = document.getElementById('paymentMethod');
    if (!method || !method.value) {
        showNotification('Please select a payment method', 'error');
        return;
    }
    
    const data = {
        payment_method: method.value,
        account_holder_name: document.getElementById('account_holder_name')?.value || '',
        account_type: document.getElementById('account_type')?.value || '',
        account_number: document.getElementById('account_number')?.value || '',
        bank_name: document.getElementById('bank_name')?.value || '',
        branch_code: document.getElementById('branch_code')?.value || '',
        phone_number: document.getElementById('phone_number')?.value || '',
        email: document.getElementById('email')?.value || ''
    };
    
    console.log('Adding new payment method:', data);
    
    fetch(`http://localhost:5000/api/artisan/${userId}/payout-method`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => {
        console.log('Response status:', res.status);
        return res.json();
    })
    .then(data => {
        console.log('Response:', data);
        if (data.status === 'success') {
            closeModal();
            showNotification('Payment method added successfully!', 'success');
            displayDashboard();
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Fetch error:', err);
        showNotification('Failed to add payment method. Check backend connection.', 'error');
    });
}

function editPayoutMethodModal(methodId, method, userId) {
    // Fetch current method details and show edit form
    fetch(`http://localhost:5000/api/artisan/${userId}/payout-settings`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const currentMethod = data.payout_methods.find(m => m.id === methodId);
                if (currentMethod) {
                    showEditPayoutMethodForm(methodId, currentMethod, userId);
                }
            }
        })
        .catch(err => showNotification('Error loading method details', 'error'));
}

function showEditPayoutMethodForm(methodId, method, userId) {
    const form = `
        <form onsubmit="updatePayoutMethod(event, ${methodId}, ${userId})" class="form">
            <div class="form-group">
                <label>Account Holder Name</label>
                <input type="text" id="edit_account_holder" value="${method.account_holder_name || ''}" 
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
            </div>
            <div class="form-group">
                <label>Account Type</label>
                <input type="text" id="edit_account_type" value="${method.account_type || ''}" 
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
            </div>
            ${method.bank_name ? `
                <div class="form-group">
                    <label>Bank Name</label>
                    <input type="text" id="edit_bank_name" value="${method.bank_name || ''}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
                </div>
            ` : ''}
            ${method.phone_number ? `
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" id="edit_phone_number" value="${method.phone_number || ''}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
                </div>
            ` : ''}
            ${method.email ? `
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="edit_email" value="${method.email || ''}" 
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
                </div>
            ` : ''}
            <div class="form-group">
                <label>
                    <input type="checkbox" id="edit_is_primary" ${method.is_primary ? 'checked' : ''} />
                    Set as Primary Payment Method
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    `;
    
    showModalWithForm('Edit Payment Method', form);
}

function updatePayoutMethod(event, methodId, userId) {
    event.preventDefault();
    
    const editAccountHolder = document.getElementById('edit_account_holder');
    const editAccountType = document.getElementById('edit_account_type');
    
    if (!editAccountHolder || !editAccountType) {
        showNotification('Error: Form elements missing', 'error');
        return;
    }
    
    const data = {
        account_holder_name: editAccountHolder.value,
        account_type: editAccountType.value,
        bank_name: document.getElementById('edit_bank_name')?.value,
        phone_number: document.getElementById('edit_phone_number')?.value,
        email: document.getElementById('edit_email')?.value,
        is_primary: document.getElementById('edit_is_primary')?.checked || false
    };
    
    console.log('Updating payment method:', data);
    
    fetch(`http://localhost:5000/api/artisan/payout-method/${methodId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => {
        console.log('Response status:', res.status);
        return res.json();
    })
    .then(data => {
        console.log('Update response:', data);
        if (data.status === 'success') {
            closeModal();
            showNotification('Payment method updated successfully!', 'success');
            displayDashboard();
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Fetch error:', err);
        showNotification('Failed to update payment method. Check backend connection.', 'error');
    });
}

function deletePayoutMethod(methodId, userId) {
    if (!confirm('Are you sure you want to delete this payment method?')) return;
    
    console.log('Deleting payment method:', methodId);
    
    fetch(`http://localhost:5000/api/artisan/payout-method/${methodId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(res => {
        console.log('Delete response status:', res.status);
        return res.json();
    })
    .then(data => {
        console.log('Delete response:', data);
        if (data.status === 'success') {
            showNotification('Payment method deleted successfully!', 'success');
            displayDashboard();
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Delete fetch error:', err);
        showNotification('Failed to delete payment method. Check backend connection.', 'error');
    });
}

function editPayoutFrequency() {
    console.log("=== editPayoutFrequency CALLED ===");
    
    const userId = localStorage.getItem("userId");
    console.log("userId from localStorage:", userId);
    
    if (!userId) {
        showNotification('Please log in first', 'error');
        return;
    }
    
    console.log("Loading payout frequency settings for user:", userId);
    
    fetch(`http://localhost:5000/api/artisan/${userId}/payout-settings`)
        .then(res => {
            console.log('Response status:', res.status);
            return res.json();
        })
        .then(data => {
            console.log('Payout settings data:', data);
            if (data.status === 'success') {
                const settings = data.settings;
                const form = `
                    <form onsubmit="savePayoutSettings(event, ${userId})" class="form">
                        <div class="form-group">
                            <label>Payout Frequency</label>
                            <select id="payoutFrequencyForm" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="weekly" ${settings.payout_frequency === 'weekly' ? 'selected' : ''}>Weekly</option>
                                <option value="biweekly" ${settings.payout_frequency === 'biweekly' ? 'selected' : ''}>Bi-weekly</option>
                                <option value="monthly" ${settings.payout_frequency === 'monthly' ? 'selected' : ''}>Monthly</option>
                                <option value="manual" ${settings.payout_frequency === 'manual' ? 'selected' : ''}>Manual only</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Minimum Payout Amount ($)</label>
                            <input type="number" id="minimumPayoutForm" value="${settings.minimum_payout}" step="0.01" min="1" 
                                   style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="autoPayoutForm" ${settings.auto_payout_enabled ? 'checked' : ''} />
                                Enable Automatic Payouts
                            </label>
                        </div>
                        <div class="info-box" style="background: #f0f0f0; padding: 12px; border-radius: 4px; margin-bottom: 12px;">
                            <strong>Next Payout:</strong> ${settings.next_payout_date || 'Not scheduled'}<br>
                            <strong>Last Payout:</strong> ${settings.last_payout_date || 'Never'}
                        </div>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </form>
                `;
                showModalWithForm('Payout Settings', form);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Fetch error:', err);
            showNotification('Failed to load payout settings. Make sure backend is running.', 'error');
        });
}

function savePayoutSettings(event, userId) {
    event.preventDefault();
    
    const payoutFrequency = document.getElementById('payoutFrequencyForm');
    const minimumPayout = document.getElementById('minimumPayoutForm');
    const autoPayout = document.getElementById('autoPayoutForm');
    
    if (!payoutFrequency || !minimumPayout) {
        console.error('Form elements not found');
        showNotification('Error: Form elements missing', 'error');
        return;
    }
    
    const data = {
        payout_frequency: payoutFrequency.value,
        minimum_payout: parseFloat(minimumPayout.value),
        auto_payout_enabled: autoPayout ? autoPayout.checked : false
    };
    
    console.log('Saving payout settings:', data);
    
    fetch(`http://localhost:5000/api/artisan/${userId}/payout-settings`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => {
        console.log('Response status:', res.status);
        return res.json();
    })
    .then(responseData => {
        console.log('Response data:', responseData);
        if (responseData.status === 'success') {
            closeModal();
            showNotification('Payout settings updated successfully!', 'success');
            // Reload payout settings to reflect changes - ensure displayPayoutSettings is called
            fetchPayoutSettings(userId).then(() => {
                console.log('Payout settings refreshed and displayed');
            });
        } else {
            showNotification('Error: ' + responseData.message, 'error');
        }
    })
    .catch(err => {
        console.error('Fetch error:', err);
        showNotification('Failed to save payout settings. Check backend connection.', 'error');
    });
}

function displayAvailability() {
    const scheduleTable = document.querySelector('.schedule-table');
    if (!scheduleTable || !artisanData.availability) return;
    
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    
    if (artisanData.availability.length === 0) {
        // Display default availability if none set in DB
        let html = '';
        const defaultHours = {
            'Monday': { start: '09:00', end: '17:00' },
            'Tuesday': { start: '09:00', end: '17:00' },
            'Wednesday': { start: '09:00', end: '17:00' },
            'Thursday': { start: '09:00', end: '17:00' },
            'Friday': { start: '09:00', end: '17:00' },
            'Saturday': { start: '10:00', end: '15:00' },
            'Sunday': { start: null, end: null }
        };
        
        daysOfWeek.forEach(day => {
            const hours = defaultHours[day];
            const timeStr = hours.start ? `${hours.start} - ${hours.end}` : 'Closed';
            html += `
                <div class="schedule-row">
                    <span class="day">${day}</span>
                    <span class="time">${timeStr}</span>
                    <button class="btn-icon" onclick="editSchedule('${day.toLowerCase()}')">
                        <i class="fa fa-pencil"></i>
                    </button>
                </div>
            `;
        });
        scheduleTable.innerHTML = html;
        return;
    }
    
    // Display availability from database
    let html = '';
    daysOfWeek.forEach(day => {
        const dayAvail = artisanData.availability.find(a => a.day_of_week?.toLowerCase() === day.toLowerCase());
        const timeStr = dayAvail && dayAvail.start_time && dayAvail.end_time 
            ? `${dayAvail.start_time} - ${dayAvail.end_time}` 
            : 'Not set';
        
        html += `
            <div class="schedule-row">
                <span class="day">${day}</span>
                <span class="time">${timeStr}</span>
                <button class="btn-icon" onclick="editSchedule('${day.toLowerCase()}')">
                    <i class="fa fa-pencil"></i>
                </button>
            </div>
        `;
    });
    scheduleTable.innerHTML = html;
}

function displayUnavailableDates() {
    const list = document.getElementById('unavailableDatesList');
    if (!list || !artisanData.artisan || !artisanData.artisan.unavailable_dates) return;
    
    const dates = artisanData.artisan.unavailable_dates;
    
    if (dates.length === 0) {
        list.innerHTML = '<p style="color: #999; margin-top: 12px;">No unavailable dates set</p>';
        return;
    }
    
    let html = '';
    dates.forEach(date => {
        const startDate = new Date(date.start_date).toLocaleDateString();
        const endDate = new Date(date.end_date).toLocaleDateString();
        const reason = date.reason ? ` (${date.reason})` : '';
        
        html += `
            <div class="unavailable-item" style="padding: 12px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <p style="margin: 0; font-weight: 500;">${startDate} to ${endDate}${reason}</p>
                    <small style="color: #666;"></small>
                </div>
                <button class="btn btn-sm btn-danger" onclick="removeUnavailableDate(${date.id})" style="padding: 6px 12px; font-size: 0.85em;">Remove</button>
            </div>
        `;
    });
    list.innerHTML = html;
}

function acceptBooking(id) {
    if (confirm('Accept this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'confirmed' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking accepted!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to accept booking', 'error'));
    }
}

function declineBooking(id) {
    if (confirm('Decline this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'declined' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking declined', 'info');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to decline booking', 'error'));
    }
}

function startBooking(id) {
    const userId = localStorage.getItem("userId");
    
    fetch(`http://localhost:5000/api/booking/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'in_progress' })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('Job started!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to start job', 'error'));
}

function completeBooking(id) {
    if (confirm('Mark this job as complete?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'completed' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking completed!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to complete booking', 'error'));
    }
}

function viewBookingDetails(id) {
    const booking = artisanData.bookings.find(b => b.id === id);
    if (booking) {
        const details = `
            <div style="text-align: left;">
                <p><strong>Customer:</strong> ${booking.customer_name}</p>
                <p><strong>Service:</strong> ${booking.service_name}</p>
                <p><strong>Date & Time:</strong> ${booking.date} ${booking.time}</p>
                <p><strong>Status:</strong> ${booking.status}</p>
                <p><strong>Client location:</strong> ${booking.client_location_address || 'Not provided'}</p>
                <p><strong>Travel estimate:</strong> ${booking.distance_km ? `${booking.distance_km.toFixed(1)} km, about ${booking.estimated_travel_minutes || '?'} minutes` : 'Unavailable until both locations are set'}</p>
                <p><strong>Estimated fuel:</strong> ${booking.estimated_fuel_cost !== null && booking.estimated_fuel_cost !== undefined ? `${getCurrencySymbol()}${booking.estimated_fuel_cost.toFixed(2)}` : 'Set fuel assumptions in your profile'}</p>
                ${booking.client_latitude && booking.client_longitude && artisanData.artisan.workplace_latitude && artisanData.artisan.workplace_longitude ? `<p><a href="https://www.google.com/maps/dir/?api=1&origin=${artisanData.artisan.workplace_latitude},${artisanData.artisan.workplace_longitude}&destination=${booking.client_latitude},${booking.client_longitude}" target="_blank" rel="noopener"><i class="fa fa-map-marker"></i> Open route in Google Maps</a></p>` : ''}
                <p><strong>Notes:</strong> ${booking.notes || 'No notes'}</p>
            </div>
        `;
        showModalWithForm('Booking Details', details);
    }
}

function addService() {
    const userId = localStorage.getItem("userId");
    
    const form = `
        <form onsubmit="saveService(event, ${userId})" class="form">
            <div class="form-group">
                <label>Service Name *</label>
                <input type="text" id="serviceName" placeholder="e.g., Electrical Installation" required />
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea id="serviceDescription" placeholder="Describe your service..."></textarea>
            </div>
            <div class="form-group">
                <label>Category</label>
                <input type="text" id="serviceCategory" placeholder="e.g., Electrical" />
            </div>
            <div class="form-group">
                <label>Price per Hour ($) *</label>
                <input type="number" id="serviceRate" step="0.01" min="0" required />
            </div>
            <button type="submit" class="btn btn-primary">Add Service</button>
        </form>
    `;
    showModalWithForm('Add New Service', form);
}

function saveService(event, userId) {
    event.preventDefault();
    
    const serviceName = document.getElementById('serviceName').value;
    const description = document.getElementById('serviceDescription').value;
    const category = document.getElementById('serviceCategory').value;
    const hourlyRate = parseFloat(document.getElementById('serviceRate').value);
    
    fetch(`http://localhost:5000/api/artisan/${userId}/services`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            service_name: serviceName,
            description: description,
            category: category,
            hourly_rate: hourlyRate
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Service added!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to add service', 'error'));
}

function editService(id) {
    const userId = localStorage.getItem("userId");
    const service = artisanData.services.find(s => s.id === id);
    if (!service) return;
    
    const form = `
        <form onsubmit="updateService(${id}, ${userId}, event)" class="form">
            <div class="form-group">
                <label>Service Name</label>
                <input type="text" value="${service.name}" disabled />
            </div>
            <div class="form-group">
                <label>Price per Hour ($) *</label>
                <input type="number" id="editRate" value="${service.hourly_rate}" step="0.01" min="0" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Service</button>
        </form>
    `;
    showModalWithForm('Edit Service', form);
}

function updateService(id, userId, event) {
    event.preventDefault();
    
    const hourlyRate = parseFloat(document.getElementById('editRate').value);
    
    fetch(`http://localhost:5000/api/artisan/service/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hourly_rate: hourlyRate })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Service updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update service', 'error'));
}

function deleteService(id) {
    if (confirm('Delete this service?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/artisan/service/${id}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Service deleted!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to delete service', 'error'));
    }
}

// ==================== CERTIFICATIONS MANAGEMENT ====================

function addCertification() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="saveCertification(event, ${userId})" class="form">
            <div class="form-group">
                <label>Certification Name *</label>
                <input type="text" id="certName" required placeholder="e.g., ISO 9001 Certified" />
            </div>
            <div class="form-group">
                <label>Issuing Organization</label>
                <input type="text" id="certIssuer" placeholder="e.g., ISO International" />
            </div>
            <div class="form-group">
                <label>Issue Date</label>
                <input type="date" id="certIssueDate" />
            </div>
            <div class="form-group">
                <label>Expiration Date</label>
                <input type="date" id="certExpireDate" />
            </div>
            <div class="form-group">
                <label>Certificate Number</label>
                <input type="text" id="certNumber" placeholder="Optional" />
            </div>
            <button type="submit" class="btn btn-primary">Add Certification</button>
        </form>
    `;
    showModalWithForm('Add Certification', form);
}

function editCertification(certId) {
    const cert = artisanData.artisan.certifications?.find(c => c.id === certId);
    if (!cert) {
        showNotification('Certification not found', 'error');
        return;
    }
    
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="saveCertification(event, ${userId}, ${certId})" class="form">
            <div class="form-group">
                <label>Certification Name *</label>
                <input type="text" id="certName" required value="${cert.name || ''}" />
            </div>
            <div class="form-group">
                <label>Issuing Organization</label>
                <input type="text" id="certIssuer" value="${cert.issuer || ''}" />
            </div>
            <div class="form-group">
                <label>Issue Date</label>
                <input type="date" id="certIssueDate" value="${cert.issue_date || ''}" />
            </div>
            <div class="form-group">
                <label>Expiration Date</label>
                <input type="date" id="certExpireDate" value="${cert.expiry_date || ''}" />
            </div>
            <div class="form-group">
                <label>Certificate Number</label>
                <input type="text" id="certNumber" value="${cert.certificate_number || ''}" />
            </div>
            <button type="submit" class="btn btn-primary">Update Certification</button>
        </form>
    `;
    showModalWithForm('Edit Certification', form);
}

function saveCertification(event, userId, certId = null) {
    event.preventDefault();
    
    const data = {
        certification_name: document.getElementById('certName').value,
        issuing_organization: document.getElementById('certIssuer').value,
        issue_date: document.getElementById('certIssueDate').value || null,
        expiration_date: document.getElementById('certExpireDate').value || null,
        certificate_number: document.getElementById('certNumber').value
    };
    
    const url = certId 
        ? `http://localhost:5000/api/artisan/certification/${certId}`
        : `http://localhost:5000/api/artisan/${userId}/certifications`;
    
    const method = certId ? 'PUT' : 'POST';
    
    fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification(certId ? 'Certification updated!' : 'Certification added!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to save certification', 'error'));
}

function deleteCertification(certId) {
    if (confirm('Delete this certification?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/artisan/certification/${certId}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Certification deleted!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to delete certification', 'error'));
    }
}

// ==================== SKILLS MANAGEMENT ====================

function addSkill() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="saveSkill(event, ${userId})" class="form">
            <div class="form-group">
                <label>Skill Name *</label>
                <input type="text" id="skillName" required placeholder="e.g., Plumbing, Carpentry" />
            </div>
            <div class="form-group">
                <label>Category</label>
                <input type="text" id="skillCategory" placeholder="e.g., Repair, Construction" />
            </div>
            <div class="form-group">
                <label>Proficiency Level</label>
                <select id="skillLevel">
                    <option value="beginner">Beginner</option>
                    <option value="intermediate" selected>Intermediate</option>
                    <option value="advanced">Advanced</option>
                    <option value="expert">Expert</option>
                </select>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea id="skillDescription" placeholder="Optional description of this skill"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Skill</button>
        </form>
    `;
    showModalWithForm('Add Skill', form);
}

function saveSkill(event, userId) {
    event.preventDefault();
    
    const data = {
        skill_name: document.getElementById('skillName').value,
        category: document.getElementById('skillCategory').value,
        proficiency_level: document.getElementById('skillLevel').value,
        description: document.getElementById('skillDescription').value
    };
    
    fetch(`http://localhost:5000/api/artisan/${userId}/skills`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Skill added!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to add skill', 'error'));
}

function deleteSkill(artisanSkillId) {
    if (confirm('Delete this skill?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/artisan/skill/${artisanSkillId}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Skill deleted!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to delete skill', 'error'));
    }
}

function editProfile() {
    const userId = localStorage.getItem("userId");
    
    const form = `
        <form onsubmit="saveProfile(event, ${userId})" class="form">
            <div class="form-group">
                <label>Bio</label>
                <textarea id="profileBio" placeholder="Tell customers about yourself...">${artisanData.artisan.bio || ''}</textarea>
            </div>
            <div class="form-group">
                <label>Years of Experience</label>
                <input type="number" id="profileExp" value="${artisanData.artisan.experience_years}" min="0" />
            </div>
            <div class="form-group">
                <label>Location (City, Country)</label>
                <input type="text" id="locationSearch" placeholder="Search for your city..." 
                       oninput="searchLocations(this.value)" autocomplete="off" 
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />
                <div id="locationResults" style="max-height: 150px; overflow-y: auto; margin-top: 4px;"></div>
                <input type="hidden" id="profileLocation" value="${artisanData.artisan.location_id || ''}" />
                <div id="selectedLocation" style="margin-top: 8px; padding: 8px; background: #f0f0f0; border-radius: 4px; display: none;">
                    <strong>Selected:</strong> <span id="selectedLocationName"></span>
                </div>
            </div>
            <div class="form-group">
                <label>Company Name</label>
                <input type="text" id="profileCompany" value="${artisanData.artisan.company_name || ''}" />
            </div>
            <div class="form-group">
                <label>License Number</label>
                <input type="text" id="profileLicense" value="${artisanData.artisan.license_number || ''}" />
            </div>
            <div class="form-group">
                <label>Service Radius (km)</label>
                <input type="number" id="profileRadius" value="${artisanData.artisan.service_radius_km}" min="1" />
            </div>
            <div class="form-group">
                <label>Workplace Address</label>
                <input type="text" id="workplaceAddress" value="${artisanData.artisan.workplace_address || ''}" placeholder="Your workshop or starting location" />
            </div>
            <div class="form-group">
                <label>Workplace Latitude</label>
                <input type="number" id="workplaceLatitude" value="${artisanData.artisan.workplace_latitude || ''}" step="any" placeholder="e.g. -29.315" />
            </div>
            <div class="form-group">
                <label>Workplace Longitude</label>
                <input type="number" id="workplaceLongitude" value="${artisanData.artisan.workplace_longitude || ''}" step="any" placeholder="e.g. 27.486" />
            </div>
            <div class="form-group">
                <label>Fuel consumption (litres / 100 km)</label>
                <input type="number" id="fuelConsumption" value="${artisanData.artisan.fuel_consumption_l_per_100km || 8}" min="0" step="0.1" required />
            </div>
            <div class="form-group">
                <label>Fuel price per litre</label>
                <input type="number" id="fuelPrice" value="${artisanData.artisan.fuel_price_per_liter || 0}" min="0" step="0.01" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Profile</button>
        </form>
    `;
    showModalWithForm('Edit Profile', form);
    
    // Display current location if one is selected
    if (artisanData.artisan.location && artisanData.artisan.location.trim()) {
        document.getElementById('locationSearch').value = artisanData.artisan.location;
        document.getElementById('selectedLocation').style.display = 'block';
        document.getElementById('selectedLocationName').textContent = artisanData.artisan.location;
    }
}

// ==================== LOCATION SEARCH ====================

function searchLocations(query) {
    const resultsDiv = document.getElementById('locationResults');
    const locationInput = document.getElementById('locationSearch');
    
    if (!query || query.trim().length < 2) {
        resultsDiv.innerHTML = '';
        return;
    }
    
    fetch(`http://localhost:5000/api/locations/search?q=${encodeURIComponent(query)}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success' && data.locations) {
                let html = '<div style="border: 1px solid #ddd; border-radius: 4px; background: white;">';
                
                if (data.locations.length === 0) {
                    html += `
                        <div style="padding: 12px;">
                            <p style="margin: 0 0 8px 0; font-size: 0.9em;">No results found. Create new location?</p>
                            <button type="button" class="btn btn-sm btn-success" onclick="createCustomLocation('${query}')">
                                + Add "${query}"
                            </button>
                        </div>
                    `;
                } else {
                    data.locations.forEach(loc => {
                        html += `
                            <div onclick="selectLocation(${loc.id}, '${loc.display_name}')" 
                                 style="padding: 10px; cursor: pointer; border-bottom: 1px solid #eee; hover: background: #f5f5f5;">
                                ${loc.display_name}
                            </div>
                        `;
                    });
                }
                html += '</div>';
                resultsDiv.innerHTML = html;
            }
        })
        .catch(err => {
            console.error("Search error:", err);
            resultsDiv.innerHTML = '<p style="color: red;">Error searching locations</p>';
        });
}

function selectLocation(locId, locName) {
    document.getElementById('profileLocation').value = locId;
    document.getElementById('locationSearch').value = locName;
    document.getElementById('locationResults').innerHTML = '';
    
    const selectedDiv = document.getElementById('selectedLocation');
    selectedDiv.style.display = 'block';
    document.getElementById('selectedLocationName').textContent = locName;
}

function createCustomLocation(city) {
    const country = prompt("Enter country for " + city + ":", "");
    if (!country) return;
    
    const district = prompt("Enter district/state (optional):", "");
    
    fetch('http://localhost:5000/api/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            city: city,
            district: district || '',
            country: country
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            selectLocation(data.location_id, `${city}, ${district ? district + ', ' : ''}${country}`);
            showNotification('Location created!', 'success');
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to create location', 'error'));
}

function saveProfile(event, userId) {
    event.preventDefault();
    
    const bio = document.getElementById('profileBio').value;
    const experience = parseInt(document.getElementById('profileExp').value) || 0;
    const location = parseInt(document.getElementById('profileLocation').value) || null;
    const company = document.getElementById('profileCompany').value;
    const license = document.getElementById('profileLicense').value;
    const radius = parseInt(document.getElementById('profileRadius').value) || 15;
    const workplaceAddress = document.getElementById('workplaceAddress').value;
    const workplaceLatitude = document.getElementById('workplaceLatitude').value || null;
    const workplaceLongitude = document.getElementById('workplaceLongitude').value || null;
    const fuelConsumption = parseFloat(document.getElementById('fuelConsumption').value) || 8;
    const fuelPrice = parseFloat(document.getElementById('fuelPrice').value) || 0;
    
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            bio: bio,
            experience_years: experience,
            location_id: location,
            company_name: company,
            license_number: license,
            service_radius_km: radius,
            workplace_address: workplaceAddress,
            workplace_latitude: workplaceLatitude,
            workplace_longitude: workplaceLongitude,
            fuel_consumption_l_per_100km: fuelConsumption,
            fuel_price_per_liter: fuelPrice
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Profile updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update profile', 'error'));
}

function setAvailability() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="saveAvailability(event, ${userId})" class="form">
            <div class="form-group">
                <label>Monday<input type="checkbox" checked style="margin-left: 8px;" /></label>
                <div style="display: flex; gap: 8px;">
                    <input type="time" id="monStart" value="09:00" />
                    <span>to</span>
                    <input type="time" id="monEnd" value="17:00" />
                </div>
            </div>
            <div class="form-group">
                <label>Tuesday<input type="checkbox" checked style="margin-left: 8px;" /></label>
                <div style="display: flex; gap: 8px;">
                    <input type="time" id="tueStart" value="09:00" />
                    <span>to</span>
                    <input type="time" id="tueEnd" value="17:00" />
                </div>
            </div>
            <div class="form-group">
                <label>Wednesday<input type="checkbox" checked style="margin-left: 8px;" /></label>
                <div style="display: flex; gap: 8px;">
                    <input type="time" id="wedStart" value="09:00" />
                    <span>to</span>
                    <input type="time" id="wedEnd" value="17:00" />
                </div>
            </div>
            <div class="form-group">
                <label>Thursday<input type="checkbox" checked style="margin-left: 8px;" /></label>
                <div style="display: flex; gap: 8px;">
                    <input type="time" id="thuStart" value="09:00" />
                    <span>to</span>
                    <input type="time" id="thuEnd" value="17:00" />
                </div>
            </div>
            <div class="form-group">
                <label>Friday<input type="checkbox" checked style="margin-left: 8px;" /></label>
                <div style="display: flex; gap: 8px;">
                    <input type="time" id="friStart" value="09:00" />
                    <span>to</span>
                    <input type="time" id="friEnd" value="17:00" />
                </div>
            </div>
            
            <div style="background: #e3f2fd; border-left: 4px solid #2196F3; padding: 12px; margin: 16px 0; border-radius: 4px;">
                <strong style="color: #1976d2;">⏳ Coming Soon:</strong>
                <ul style="margin: 8px 0 0 0; padding-left: 20px; font-size: 0.9em;">
                    <li><strong>Schedule Editing:</strong> Advanced scheduling with more flexibility</li>
                    <li><strong>Unavailable Dates:</strong> Block specific dates when you're not available (holidays, vacation, etc.)</li>
                </ul>
            </div>
            
            <button type="submit" class="btn btn-primary">Save Availability</button>
        </form>
    `;
    showModalWithForm('Set Availability', form);
}

function saveAvailability(event, userId) {
    event.preventDefault();
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const dayIds = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
    const availability = [];
    
    dayIds.forEach((dayId, index) => {
        const startEl = document.getElementById(dayId + 'Start');
        const endEl = document.getElementById(dayId + 'End');
        
        if (startEl && endEl) {
            availability.push({
                day: days[index],
                start_time: startEl.value,
                end_time: endEl.value
            });
        }
    });
    
    fetch(`http://localhost:5000/api/artisan/${userId}/availability`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ availability: availability })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Availability updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update availability', 'error'));
}

function logout() {
    if (confirm('Logout?')) {
        localStorage.removeItem("user");
        localStorage.removeItem("userId");
        localStorage.removeItem("isArtisan");
        window.location.href = "login.html";
    }
}

// ==================== UI FUNCTIONS ====================

function switchTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) selectedTab.classList.add('active');
    
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    
    const activeLink = document.querySelector(`a[href="#${tabName}"]`);
    if (activeLink) activeLink.classList.add('active');
    
    const titleMap = {
        'dashboard': 'Dashboard',
        'profile': 'My Profile',
        'services': 'My Services',
        'bookings': 'Bookings',
        'schedule': 'Availability',
        'earnings': 'Earnings',
        'reviews': 'Reviews',
        'messages': 'Messages',
        'settings': 'Settings'
    };
    document.getElementById('pageTitle').textContent = titleMap[tabName] || 'Dashboard';
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

function toggleNotifications() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.toggle('active');
    if (dropdown.classList.contains('active')) {
        const userId = localStorage.getItem('userId');
        fetch(`http://localhost:5000/api/user/${userId}/notifications`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: '{}' })
            .then(() => loadNotifications(userId));
    }
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
}

function showModal(title, content) {
    console.log("=== showModal CALLED ===");
    console.log("Title:", title);
    
    let modal = document.getElementById('customModal');
    if (!modal) {
        console.log("Creating new modal element...");
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle"></h2>
                <div id="modalBody"></div>
            </div>
        `;
        document.body.appendChild(modal);
        console.log("Modal element created and added to DOM");
    }
    
    const titleElement = document.getElementById('modalTitle');
    const bodyElement = document.getElementById('modalBody');
    
    if (titleElement && bodyElement) {
        titleElement.textContent = title;
        bodyElement.innerHTML = content;
        modal.style.display = 'block';
        console.log("Modal displayed successfully");
        
        // Scroll modal into view
        modal.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
        console.error("Modal title or body element not found!");
    }
}

function showModalWithForm(title, formHtml) {
    showModal(title, formHtml);
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) modal.style.display = 'none';
}

function showNotification(message, type = 'info') {
    let container = document.getElementById('notificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notificationContainer';
        document.body.appendChild(container);
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove();">&times;</button>
        </div>
    `;
    
    container.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}

// ==================== SETTINGS FUNCTIONS ====================

function replyReview(reviewId) {
    const form = `
        <form onsubmit="sendReply(${reviewId}, event)" class="form">
            <div class="form-group">
                <label>Your Reply</label>
                <textarea id="replyText" placeholder="Write your reply..." required style="min-height: 100px;"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send Reply</button>
        </form>
    `;
    showModalWithForm('Reply to Review', form);
}

function sendReply(reviewId, event) {
    event.preventDefault();
    const replyText = document.getElementById('replyText').value;
    const userId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/artisan/${userId}/reviews/${reviewId}/reply`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply: replyText })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Reply failed');
            closeModal();
            showNotification('Reply sent to the client.', 'success');
            loadAllData(userId);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function togglePremiumSubscription() {
    showNotification('Premium subscription management coming soon!', 'info');
}

function changeEmail() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="updateEmail(event, ${userId})" class="form">
            <div class="form-group">
                <label>Current Email</label>
                <input type="email" value="${artisanData.user.email}" disabled style="background: #f5f5f5;" />
            </div>
            <div class="form-group">
                <label>New Email Address</label>
                <input type="email" id="newEmail" placeholder="Enter new email" required />
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" id="passwordConfirm" placeholder="Enter your password to confirm" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Email</button>
        </form>
    `;
    showModalWithForm('Change Email', form);
}

function updateEmail(event, userId) {
    event.preventDefault();
    const newEmail = document.getElementById('newEmail').value;
    const password = document.getElementById('passwordConfirm').value;
    
    fetch(`http://localhost:5000/api/user/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            email: newEmail,
            password: password
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Email updated successfully!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update email', 'error'));
}

function changePassword() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="updatePassword(event, ${userId})" class="form">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" id="currentPassword" required />
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" id="newPassword" required />
            </div>
            <div class="form-group">
                <label>Confirm New Password</label>
                <input type="password" id="confirmPassword" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
    `;
    showModalWithForm('Change Password', form);
}

function updatePassword(event, userId) {
    event.preventDefault();
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword !== confirmPassword) {
        showNotification('Passwords do not match!', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showNotification('Password must be at least 6 characters!', 'error');
        return;
    }
    
    fetch(`http://localhost:5000/api/user/${userId}/password`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            current_password: currentPassword,
            new_password: newPassword
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Password updated successfully!', 'success');
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update password', 'error'));
}

function enableTwoFactor() {
    const form = `
        <div class="form">
            <p style="margin-bottom: 16px;">Two-Factor Authentication adds an extra layer of security to your account.</p>
            <div class="form-group">
                <label>Authenticator App</label>
                <p style="font-size: 0.9em; color: #666;">Use an app like Google Authenticator or Authy to generate codes.</p>
                <button type="button" class="btn btn-primary" onclick="setupAuthenticator()">Set Up Authenticator</button>
            </div>
            <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee;">
                <label>SMS Authentication</label>
                <p style="font-size: 0.9em; color: #666;">Receive codes via SMS for added security.</p>
                <button type="button" class="btn btn-primary" onclick="setupSMS()">Set Up SMS</button>
            </div>
        </div>
    `;
    showModalWithForm('Enable Two-Factor Authentication', form);
}

function setupAuthenticator() {
    showNotification('Authenticator setup selected. Scan setup will be added to your account next.', 'info');
    closeModal();
}

function setupSMS() {
    showNotification('SMS authentication selected. Add a verified phone number to continue.', 'info');
    closeModal();
}

function changeProfileVisibility() {
    const userId = localStorage.getItem('userId');
    const visible = artisanData.artisan.profile_visible !== false;
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile_visible: !visible })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Unable to update visibility');
            artisanData.artisan.profile_visible = !visible;
            showNotification(`Profile is now ${!visible ? 'visible' : 'hidden'} to customers.`, 'success');
            loadAllData(userId);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function downloadData() {
    const exportData = {
        user: artisanData.user,
        profile: artisanData.artisan,
        bookings: artisanData.bookings,
        services: artisanData.services,
        reviews: artisanData.reviews
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'tradepro-artisan-data.json';
    link.click();
    URL.revokeObjectURL(link.href);
    showNotification('Your data download has started.', 'success');
}

function deleteAccount() {
    if (!confirm('Delete your account permanently? This cannot be undone.')) return;
    const userId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/user/${userId}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Unable to delete account');
            logout();
        })
        .catch(error => showNotification(error.message, 'error'));
}

function changeServiceArea() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="updateServiceArea(event, ${userId})" class="form">
            <div class="form-group">
                <label>Service Radius (km)</label>
                <input type="number" id="serviceRadius" value="${artisanData.artisan.service_radius_km || 15}" min="1" max="100" required />
                <small style="color: #666;">How far you're willing to travel for services</small>
            </div>
            <button type="submit" class="btn btn-primary">Update Service Area</button>
        </form>
    `;
    showModalWithForm('Change Service Area', form);
}

function updateServiceArea(event, userId) {
    event.preventDefault();
    const radius = document.getElementById('serviceRadius').value;
    
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ service_radius_km: parseInt(radius) })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Service area updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update service area', 'error'));
}

function changeResponseTime() {
    const form = `
        <form onsubmit="updateResponseTime(event)" class="form">
            <div class="form-group">
                <label>Response Time</label>
                <select id="responseTime">
                    <option value="15">Within 15 minutes</option>
                    <option value="30">Within 30 minutes</option>
                    <option value="60" selected>Within 1 hour</option>
                    <option value="240">Within 4 hours</option>
                    <option value="1440">Within 24 hours</option>
                </select>
                <small style="color: #666;">How quickly you respond to booking requests</small>
            </div>
            <button type="submit" class="btn btn-primary">Update Response Time</button>
        </form>
    `;
    showModalWithForm('Change Response Time', form);
}

function updateResponseTime(event) {
    event.preventDefault();
    const userId = localStorage.getItem("userId");
    const responseTime = document.getElementById('responseTime').value;
    
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ response_time_minutes: parseInt(responseTime) })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Response time updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update response time', 'error'));
}

function changeBufferTime() {
    const form = `
        <form onsubmit="updateBufferTime(event)" class="form">
            <div class="form-group">
                <label>Booking Buffer Time</label>
                <select id="bufferTime">
                    <option value="0">No buffer</option>
                    <option value="15">15 minutes</option>
                    <option value="30" selected>30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="120">2 hours</option>
                </select>
                <small style="color: #666;">Time to prepare between consecutive bookings</small>
            </div>
            <button type="submit" class="btn btn-primary">Update Buffer Time</button>
        </form>
    `;
    showModalWithForm('Change Booking Buffer Time', form);
}

function updateBufferTime(event) {
    event.preventDefault();
    const userId = localStorage.getItem("userId");
    const bufferTime = document.getElementById('bufferTime').value;
    
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ buffer_time_minutes: parseInt(bufferTime) })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Buffer time updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update buffer time', 'error'));
}

function togglePremiumSubscription() {
    const userId = localStorage.getItem('userId');
    const enabled = artisanData.artisan.is_premium === true;

    if (enabled) {
        updatePremiumStatus(userId, false);
        return;
    }

    const form = `
        <form onsubmit="processPremiumUpgrade(event, ${userId})" class="form">
            <h3>Enable Premium</h3>
            <p>Choose a payment method to activate your Premium artisan account.</p>
            <div class="form-group">
                <label>Payment Method</label>
                <select id="premiumPaymentMethod" required>
                    <option value="">Choose method</option>
                    <option value="mpesa">M-Pesa</option>
                    <option value="ecocash">EcoCash</option>
                    <option value="card">Card</option>
                </select>
            </div>
            <div class="form-group">
                <label>Phone number or card reference</label>
                <input id="premiumPaymentReference" required placeholder="Enter payment reference" />
            </div>
            <button class="btn btn-success" type="submit">Pay and Enable Premium</button>
        </form>
    `;
    showModalWithForm('Premium Subscription', form);
}

function processPremiumUpgrade(event, userId) {
    event.preventDefault();
    const methodType = document.getElementById('premiumPaymentMethod').value;
    const reference = document.getElementById('premiumPaymentReference').value.trim();
    fetch(`http://localhost:5000/api/user/${userId}/payment-methods`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method_type: methodType, account_reference: reference, account_label: 'Premium subscription' })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Payment method could not be saved');
            updatePremiumStatus(userId, true);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function updatePremiumStatus(userId, enabled) {
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_premium: enabled })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Unable to update Premium status');
            closeModal();
            showNotification(enabled ? 'Premium enabled after payment.' : 'Premium disabled.', 'success');
            loadAllData(userId);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function editLocation() {
    editProfile();
}

function editSchedule(day) {
    const userId = localStorage.getItem("userId");
    const dayName = day.charAt(0).toUpperCase() + day.slice(1);
    
    // Find existing availability for this day
    const dayAvail = artisanData.availability?.find(a => a.day_of_week?.toLowerCase() === day.toLowerCase());
    const startTime = dayAvail?.start_time || '09:00';
    const endTime = dayAvail?.end_time || '17:00';
    
    const form = `
        <form onsubmit="updateDaySchedule(event, '${day}', ${userId})" class="form">
            <div class="form-group">
                <label>${dayName} Schedule</label>
            </div>
            <div class="form-group">
                <label>Working</label>
                <input type="checkbox" id="isWorking" ${dayAvail ? 'checked' : ''} onchange="toggleWorking()" />
                <span style="margin-left: 8px;">I'm available this day</span>
            </div>
            <div id="timeInputs" ${dayAvail ? '' : 'style="display: none;"'}>
                <div class="form-group">
                    <label>Start Time</label>
                    <input type="time" id="startTime" value="${startTime}" />
                </div>
                <div class="form-group">
                    <label>End Time</label>
                    <input type="time" id="endTime" value="${endTime}" />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Save ${dayName}</button>
        </form>
    `;
    showModalWithForm(`Edit ${dayName}`, form);
}

function toggleWorking() {
    const checkbox = document.getElementById('isWorking');
    const timeInputs = document.getElementById('timeInputs');
    if (checkbox.checked) {
        timeInputs.style.display = 'block';
    } else {
        timeInputs.style.display = 'none';
    }
}

function updateDaySchedule(event, day, userId) {
    event.preventDefault();
    const isWorking = document.getElementById('isWorking').checked;
    
    if (!isWorking) {
        // Delete this day's availability
        const dayAvail = artisanData.availability?.find(a => a.day_of_week?.toLowerCase() === day.toLowerCase());
        if (dayAvail) {
            // For now, just show success - availability management would need a delete endpoint
            closeModal();
            showNotification(`${day.charAt(0).toUpperCase() + day.slice(1)} set as unavailable`, 'success');
            return;
        }
    }
    
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;
    
    if (startTime >= endTime) {
        showNotification('End time must be after start time!', 'error');
        return;
    }
    
    // Update availability through the SET API
    const availability = [];
    artisanData.availability.forEach(a => {
        if (a.day_of_week.toLowerCase() !== day.toLowerCase()) {
            availability.push({
                day: a.day_of_week,
                start_time: a.start_time,
                end_time: a.end_time
            });
        }
    });
    
    if (isWorking) {
        availability.push({
            day: day.charAt(0).toUpperCase() + day.slice(1),
            start_time: startTime,
            end_time: endTime
        });
    }
    
    fetch(`http://localhost:5000/api/artisan/${userId}/availability`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ availability: availability })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Schedule updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => showNotification('Failed to update schedule', 'error'));
}

function showComingSoon() {
    showNotification('Unavailable dates feature coming soon!', 'info');
}

function addUnavailableDate() {
    const userId = localStorage.getItem("userId");
    const form = `
        <form onsubmit="saveUnavailableDate(event, ${userId})" class="form">
            <div class="form-group">
                <label>Start Date *</label>
                <input type="date" id="unavailStartDate" required />
            </div>
            <div class="form-group">
                <label>End Date *</label>
                <input type="date" id="unavailEndDate" required />
            </div>
            <div class="form-group">
                <label>Reason (Optional)</label>
                <select id="unavailReason">
                    <option value="vacation">Vacation</option>
                    <option value="sick">Sick Leave</option>
                    <option value="personal">Personal</option>
                    <option value="maintenance">Equipment Maintenance</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea id="unavailNotes" placeholder="Any additional notes..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Add Unavailable Period</button>
        </form>
    `;
    showModalWithForm('Add Unavailable Date', form);
}

function saveUnavailableDate(event, userId) {
    event.preventDefault();
    
    const startDate = document.getElementById('unavailStartDate').value;
    const endDate = document.getElementById('unavailEndDate').value;
    const reason = document.getElementById('unavailReason').value;
    
    if (new Date(startDate) > new Date(endDate)) {
        showNotification('End date cannot be before start date!', 'error');
        return;
    }
    
    fetch(`http://localhost:5000/api/artisan/${userId}/unavailable-dates`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            start_date: startDate,
            end_date: endDate,
            reason: reason
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Unavailable period added successfully!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to add unavailable date', 'error');
    });
}

function removeUnavailableDate(id) {
    if (confirm('Remove this unavailable period?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/unavailable-date/${id}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Unavailable date removed!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to remove unavailable date', 'error'));
    }
}

function declineBooking(id) {
    if (confirm('Decline this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'declined' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking declined!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to decline booking', 'error'));
    }
}

function changePhoto() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.onchange = () => {
        const file = input.files[0];
        if (!file) return;
        if (file.size > 2 * 1024 * 1024) {
            showNotification('Please choose an image smaller than 2 MB', 'warning');
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            const userId = localStorage.getItem('userId');
            const formData = new FormData();
            formData.append('image', file);
            fetch(`http://localhost:5000/api/user/${userId}/profile-picture`, {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Upload failed');
                    artisanData.user.profile_picture = data.profile_picture;
                    const image = document.getElementById('artisanProfileImage');
                    if (image) image.src = data.profile_picture.startsWith('http') ? data.profile_picture : `http://localhost:5000${data.profile_picture}`;
                    updateProfileAvatars(data.profile_picture);
                    showNotification('Profile photo updated!', 'success');
                })
                .catch(error => showNotification(error.message, 'error'));
        };
        reader.readAsDataURL(file);
    };
    input.click();
}

// ==================== INITIALIZATION ====================

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    switchTab('dashboard');
});

// Add modal styles
const style = document.createElement('style');
style.textContent = `
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 30px;
        border-radius: 8px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover { color: #000; }
    #notificationContainer {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 3000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .notification {
        background-color: white;
        padding: 16px;
        border-radius: 8px;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        border-left: 4px solid;
    }
    .notification-success { border-left-color: #10b981; }
    .notification-error { border-left-color: #ef4444; }
    .notification-info { border-left-color: #3b82f6; }
    .notification-warning { border-left-color: #f59e0b; }
`;
document.head.appendChild(style);
