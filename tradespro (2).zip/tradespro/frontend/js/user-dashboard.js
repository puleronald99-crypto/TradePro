

// USER DASHBOARD - COMPREHENSIVE IMPLEMENTATION
// Properly fetches and displays all data from the database

let userData = {
    user: {
        id: null,
        name: '',
        email: '',
        phone: '',
        profile_picture: null
    },
    bookings: [],
    artisans: [],
    favorites: [],
    services: [],
    payments: [],
    paymentMethods: [],
    settings: { booking_notifications: true, message_notifications: true, profile_visibility: true },
    messages: [],
    bookingPollingInterval: null,
    messagePollingInterval: null
};

// ...existing code (restore all original helpers, initialization, data fetching, display, and UI logic as in the last working version)...


// ==================== LOCALSTORAGE PERSISTENCE ====================
function saveUserDataToLocalStorage() {
    try {
        const persistentData = {
            user: userData.user,
            favorites: userData.favorites,
            messages: userData.messages
        };
        localStorage.setItem('userDataPersistent', JSON.stringify(persistentData));
        console.log('✓ Data saved to localStorage');
    } catch (err) {
        console.error('✗ Error saving to localStorage:', err);
    }
}

function loadUserDataFromLocalStorage() {
    try {
        const saved = localStorage.getItem('userDataPersistent');
        if (saved) {
            const persistentData = JSON.parse(saved);
            if (persistentData.user) userData.user = { ...userData.user, ...persistentData.user };
            if (persistentData.favorites) userData.favorites = persistentData.favorites;
            if (persistentData.messages) userData.messages = persistentData.messages;
        }

        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            const loggedInUser = JSON.parse(storedUser);
            if (loggedInUser && loggedInUser.id) {
                userData.user = { ...userData.user, ...loggedInUser };
            }
        }

        console.log('✓ Data loaded from localStorage');
        return Boolean(storedUser || saved);
    } catch (err) {
        console.error('✗ Error loading from localStorage:', err);
    }
    return false;
}


// ==================== INITIALIZATION ====================
function initializeDashboard() {
    const userId = localStorage.getItem("userId");
    const isArtisan = localStorage.getItem("isArtisan");
    console.log("🚀 initializeDashboard() called");
    console.log("  userId:", userId);
    console.log("  isArtisan:", isArtisan);
    if (!userId || (isArtisan === "1" || isArtisan === "true")) {
        console.warn("✗ Not logged in as customer or wrong user type");
        window.location.href = "login.html";
        return;
    }
    console.log("✓ Initializing customer dashboard for user:", userId);
    loadAllData(userId);
}


function loadAllData(userId) {
    console.log("📦 loadAllData() called");
    loadUserDataFromLocalStorage();
    updateUserDisplay();
    Promise.allSettled([
        fetchUserData(userId),
        fetchBookings(userId),
        fetchArtisans(),
        fetchServices(),
        fetchFavorites(userId),
        fetchPayments(userId),
        fetchPaymentMethods(userId),
        fetchClientSettings(userId),
        fetchMessages(userId)
    ]).then(() => {
        updateCurrencyDisplay();
        saveUserDataToLocalStorage();
        updateUserDisplay();
        displayProfile();
        displayDashboard();
        loadNotifications(userId);
        startBookingPolling(userId);
        handlePendingArtisanAction();
    }).catch(err => {
        console.error("✗ Error loading data:", err);
        showNotification("Error loading dashboard", "error");
    });
}

function handlePendingArtisanAction() {
    const pendingId = sessionStorage.getItem('tradeproBookArtisanId');
    const pendingMessageId = sessionStorage.getItem('tradeproMessageArtisanId');
    if (!pendingId && !pendingMessageId) return;

    const artisanId = Number(pendingId || pendingMessageId);
    const artisan = pendingId
        ? userData.artisans.find(item => item.id === artisanId)
        : userData.artisans.find(item => item.user_id === artisanId);
    if (pendingId) sessionStorage.removeItem('tradeproBookArtisanId');
    if (pendingMessageId) sessionStorage.removeItem('tradeproMessageArtisanId');
    if (!artisan) {
        showNotification('That artisan is not available in the current search results. Open Find Artisans and try again.', 'warning');
        return;
    }
    if (pendingId) {
        bookArtisan(artisan.id, artisan.name);
        return;
    }
    switchTab('messages');
    selectArtisanToChat(artisan.id, artisan.user_id, artisan.name);
}

function loadNotifications(userId) {
    return fetch(`http://localhost:5000/api/user/${userId}/notifications`)
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'success') return;
            const badge = document.getElementById('notificationCount');
            if (badge) {
                badge.textContent = data.unread_count || 0;
                badge.hidden = !(data.unread_count > 0);
            }
            const dropdown = document.getElementById('notificationDropdown');
            if (dropdown) {
                dropdown.innerHTML = data.notifications.length
                    ? data.notifications.map(notification => `<div class="notification-item${notification.is_read ? '' : ' unread'}" data-notification-id="${notification.id}"><strong>${notification.title}</strong><p>${notification.message}</p><small>${new Date(notification.created_at).toLocaleString()}</small></div>`).join('')
                    : '<div class="notification-item"><p>No new notifications</p></div>';
            }
        })
        .catch(error => console.error('Error loading notifications:', error));
}

function startBookingPolling(userId) {
    if (userData.bookingPollingInterval) clearInterval(userData.bookingPollingInterval);
    userData.bookingPollingInterval = setInterval(() => {
        fetchBookings(userId).then(() => {
            if (document.getElementById('home')?.classList.contains('active')) displayHomeOverview();
            if (document.getElementById('bookings')?.classList.contains('active')) displayBookings();
            if (document.getElementById('history')?.classList.contains('active')) displayHistory();
        });
    }, 10000);
}
// ==================== UI HELPERS (MODALS, NOTIFICATIONS, TABS) ====================
function showModal(title, content) {
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle"></h2>
                <div id="modalBody"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    const titleElement = document.getElementById('modalTitle');
    const bodyElement = document.getElementById('modalBody');
    if (titleElement && bodyElement) {
        titleElement.textContent = title;
        bodyElement.innerHTML = content;
        modal.style.display = 'block';
        modal.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function showModalWithForm(title, formHtml) {
    showModal(title, formHtml);
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) modal.style.display = 'none';
}

function showNotification(message, type = 'info') {
    let container = document.getElementById('notificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notificationContainer';
        document.body.appendChild(container);
    }
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove();">&times;</button>
        </div>
    `;
    container.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}

function switchTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) selectedTab.classList.add('active');
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    const activeLink = document.querySelector(`a[href="#${tabName}"]`);
    if (activeLink) activeLink.classList.add('active');
    const titleMap = {
        'dashboard': 'Dashboard',
        'profile': 'My Profile',
        'search': 'Find Artisans',
        'bookings': 'Bookings',
        'favorites': 'Favorites',
        'messages': 'Messages',
        'settings': 'Settings'
    };
    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) pageTitle.textContent = titleMap[tabName] || 'Dashboard';
}

// ==================== DATA FETCHING ====================

function fetchUserData(userId) {
    return fetch(`http://localhost:5000/api/user/${userId}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success' && data.user) {
                userData.user = data.user;
                console.log("User data loaded:", userData.user);
            }
            return data;
        })
        .catch(err => console.error("Error fetching user data:", err));
}

function fetchBookings(userId) {
    return fetch(`http://localhost:5000/api/client/${userId}/bookings`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                userData.bookings = (data.bookings || []).sort(compareBookingsNewestFirst);
                console.log("Bookings loaded:", userData.bookings);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching bookings:", err);
            userData.bookings = [];
        });
}

function compareBookingsNewestFirst(left, right) {
    const leftDate = new Date(`${left.date || '1970-01-01'}T${left.time || '00:00:00'}`).getTime();
    const rightDate = new Date(`${right.date || '1970-01-01'}T${right.time || '00:00:00'}`).getTime();
    return rightDate - leftDate;
}

function fetchArtisans() {
    console.log("🔍 fetchArtisans() called - fetching from http://localhost:5000/api/search/artisans");
    
    return fetch(`http://localhost:5000/api/search/artisans`)
        .then(response => {
            console.log("✓ API Response status:", response.status);
            return response.json();
        })
        .then(data => {
            console.log("✓ API Response data received:", data);
            
            if (data.status === 'success' && data.artisans) {
                // Convert API data to expected format (same as find-artisans.html)
                userData.artisans = data.artisans.map((a, index) => ({
                    id: a.id || index,
                    user_id: a.user_id,
                    name: a.name,
                    service_type: a.service_type || a.service_types,
                    experience_years: a.experience_years || 0,
                    rating: a.rating || 4.5,
                    total_reviews: a.total_reviews || 0,
                    hourly_rate: a.hourly_rate || 75,
                    bio: a.bio || 'Professional service provider',
                    phone: a.phone || 'Contact via email',
                    email: a.email || 'no-email@tradepro.ls',
                    location: a.location || 'Lesotho',
                    profile_picture: getArtisanProfileImage(a.profile_picture)
                }));
                
                console.log(`✓ Successfully loaded ${userData.artisans.length} artisans`);
                if (userData.artisans.length > 0) {
                    console.log("First artisan:", userData.artisans[0]);
                }
                return data;
            } else {
                console.error("✗ API error:", data.message || 'Unknown error');
                userData.artisans = [];
                return data;
            }
        })
        .catch(error => {
            console.error("✗ Error fetching artisans:", error);
            console.error("   Is the Flask server running on http://localhost:5000?");
            userData.artisans = [];
        });
}

function fetchServices() {
    return fetch(`http://localhost:5000/api/services`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                userData.services = data.services || [];
                console.log("Services loaded:", userData.services);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching services:", err);
            userData.services = [];
        });
}

function fetchFavorites(userId) {
    return fetch(`http://localhost:5000/api/user/${userId}/favorites`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                userData.favorites = data.favorites || [];
                console.log("Favorites loaded:", userData.favorites);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching favorites:", err);
            userData.favorites = [];
        });
}

function fetchPayments(userId) {
    return fetch(`http://localhost:5000/api/client/${userId}/payments`)
        .then(res => res.json())
        .then(data => {
            userData.payments = data.status === 'success' ? (data.payments || []) : [];
            return data;
        })
        .catch(err => {
            console.error('Error fetching payments:', err);
            userData.payments = [];
        });
}

function fetchPaymentMethods(userId) {
    return fetch(`http://localhost:5000/api/client/${userId}/payment-methods`)
        .then(res => res.json())
        .then(data => { userData.paymentMethods = data.status === 'success' ? (data.payment_methods || []) : []; return data; })
        .catch(() => { userData.paymentMethods = []; });
}

function fetchClientSettings(userId) {
    return fetch(`http://localhost:5000/api/client/${userId}/settings`)
        .then(res => res.json())
        .then(data => { if (data.status === 'success') userData.settings = data.settings; return data; })
        .catch(() => null);
}

function fetchMessages(userId, startPolling = true) {
    return fetch(`http://localhost:5000/api/user/${userId}/messages`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                userData.messages = data.messages || [];
                console.log("Messages loaded:", userData.messages);
                // Start polling for new messages
                if (startPolling) startMessagePolling(userId);
            }
            return data;
        })
        .catch(err => {
            console.error("Error fetching messages:", err);
            userData.messages = [];
        });
}

function startMessagePolling(userId) {
    // Clear existing interval if any
    if (userData.messagePollingInterval) {
        clearInterval(userData.messagePollingInterval);
    }
    
    // Poll for new messages every 3 seconds
    userData.messagePollingInterval = setInterval(() => {
        loadNotifications(userId);
        fetch(`http://localhost:5000/api/user/${userId}/messages`)
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    userData.messages = data.messages || [];
                    const messagesTab = document.getElementById('messages');
                    const chatWindow = document.getElementById('chatWindow');
                    const messageInput = document.getElementById('messageInput');
                    const chatIsOpen = chatWindow && chatWindow.style.display !== 'none';
                    const inputHasDraft = messageInput && (document.activeElement === messageInput || messageInput.value.length > 0);

                    if (messagesTab?.classList.contains('active') && !chatIsOpen && !inputHasDraft) {
                        displayMessages();
                    }
                }
            })
            .catch(err => console.error("Error polling messages:", err));
    }, 3000);
}

// ==================== DISPLAY FUNCTIONS ====================

function displayDashboard() {
    updateUserDisplay();
    populateServiceFilter();
    displayHomeOverview();
    displayArtisans();
    displayBookings();
    displayFavorites();
    displayHistory();
    displayProfile();
    displayPayments();
    displayPaymentMethods();
    displayClientSettings();
    displayMessages();
}

function updateUserDisplay() {
    const topbarUserName = document.getElementById("topbarUserName");
    if (topbarUserName) topbarUserName.textContent = userData.user.name || "Customer";
    
    const dashboardUserName = document.getElementById("dashboardUserName");
    if (dashboardUserName) dashboardUserName.textContent = userData.user.name || "Customer";
    updateProfileAvatars(userData.user.profile_picture);
}

function updateProfileAvatars(profilePicture) {
    const imageUrl = profilePicture
        ? (profilePicture.startsWith('http') ? profilePicture : `http://localhost:5000${profilePicture}`)
        : 'https://via.placeholder.com/40';
    document.querySelectorAll('.user-avatar').forEach(image => {
        image.src = imageUrl;
    });
}

function populateServiceFilter() {
    const serviceFilter = document.getElementById('serviceFilter');
    const serviceOptions = document.getElementById('serviceOptions');
    if (!serviceFilter) return;
    
    // Fetch all services from backend
    fetch('http://localhost:5000/api/services')
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const services = data.services || [];
                
                serviceOptions.innerHTML = services
                    .map(service => `<option value="${service.name}"></option>`)
                    .join('');
                console.log("Service filter populated with:", services.length, "services");
            }
        })
        .catch(err => console.error('Error loading services:', err));
}

function displayHomeOverview() {
    // ==================== DISPLAY QUICK STATS ====================
    const statsSection = document.getElementById('statsSection');
    if (statsSection) {
        const totalBookings = userData.bookings.length;
        const completedBookings = userData.bookings.filter(b => b.status === 'completed').length;
        const upcomingBookings = userData.bookings.filter(b => b.status !== 'completed' && b.status !== 'declined' && b.status !== 'cancelled').length;
        const totalSpent = userData.bookings
            .filter(b => b.status === 'completed')
            .reduce((sum, b) => sum + (b.amount || 0), 0)
            .toFixed(2);
        
        let statsHtml = `
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 16px;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 8px;">${totalBookings}</div>
                    <div style="font-size: 14px; opacity: 0.9;">Total Bookings</div>
                </div>
                <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 8px;">${completedBookings}</div>
                    <div style="font-size: 14px; opacity: 0.9;">Completed Services</div>
                </div>
                <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 8px;">${upcomingBookings}</div>
                    <div style="font-size: 14px; opacity: 0.9;">Upcoming Services</div>
                </div>
                <div style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 20px; border-radius: 8px; text-align: center;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 8px;">$${totalSpent}</div>
                    <div style="font-size: 14px; opacity: 0.9;">Total Spent</div>
                </div>
            </div>
        `;
        statsSection.innerHTML = statsHtml;
    }
    
    // ==================== DISPLAY UPCOMING SERVICES ====================
    const upcomingServices = document.getElementById('upcomingServicesOverview');
    if (upcomingServices) {
        const upcoming = userData.bookings.filter(b => b.status === 'pending');
        
        if (upcoming.length === 0) {
            upcomingServices.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">No upcoming services. <a href="#search" onclick="switchTab(\'search\')" style="color: #007bff; text-decoration: none;">Book now!</a></p>';
        } else {
            let html = '';
            upcoming.slice(0, 3).forEach(booking => {
                html += `
                    <div class="service-item" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: all 0.3s;" onclick="viewBookingDetails(${booking.id})" onmouseover="this.style.backgroundColor='#f9f9f9'" onmouseout="this.style.backgroundColor='white'">
                        <h4 style="margin: 0 0 4px 0; color: #333;">${booking.service_name}</h4>
                        <p style="margin: 4px 0; color: #666; font-size: 14px;"><i class="fa fa-user"></i> ${booking.artisan_name}</p>
                        <small style="color: #999;"><i class="fa fa-calendar"></i> ${booking.date} at ${booking.time}</small>
                        <div class="status-badge" style="margin-top: 8px;">
                            <span class="badge badge-${booking.status === 'completed' ? 'success' : booking.status === 'pending' ? 'warning' : 'info'}" style="font-size: 11px; padding: 4px 8px;">${booking.status}</span>
                        </div>
                    </div>
                `;
            });
            upcomingServices.innerHTML = html;
        }
    }
    
    // ==================== DISPLAY RECENT ARTISANS ====================
    const recentArtisans = document.getElementById('recentArtisansPreview');
    if (recentArtisans) {
        // Get top 3 artisans from bookings history (recent)
        const recentArtisansList = [];
        const seenIds = new Set();
        
        userData.bookings.forEach(booking => {
            if (!seenIds.has(booking.artisan_id)) {
                const artisan = userData.artisans.find(a => a.id === booking.artisan_id);
                if (artisan) {
                    recentArtisansList.push(artisan);
                    seenIds.add(booking.artisan_id);
                }
            }
        });
        
        if (recentArtisansList.length === 0) {
            recentArtisans.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">No recent artisans. <a href="#search" onclick="switchTab(\'search\')" style="color: #007bff; text-decoration: none;">Find artisans</a></p>';
        } else {
            let html = '';
            recentArtisansList.slice(0, 3).forEach(artisan => {
                const isFavorite = userData.favorites.some(f => f.id === artisan.id);
                html += `
                    <div style="display: flex; align-items: center; padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: all 0.3s;" onclick="viewProfile(${artisan.id})" onmouseover="this.style.backgroundColor='#f9f9f9'" onmouseout="this.style.backgroundColor='white'">
                        <img src="${artisan.profile_picture || 'https://via.placeholder.com/50'}" alt="${artisan.name}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; margin-right: 12px;" />
                        <div style="flex: 1;">
                            <h4 style="margin: 0; font-size: 14px; color: #333;">${artisan.name}</h4>
                            <p style="margin: 4px 0 0 0; font-size: 12px; color: #666;">${artisan.service_type || 'Service Provider'}</p>
                            <div style="font-size: 12px; color: #f59e0b; margin-top: 2px;">
                                <i class="fa fa-star"></i> ${artisan.rating || 4.5}/5 (${artisan.total_reviews || 0})
                            </div>
                        </div>
                        <button class="favorite-btn" onclick="event.stopPropagation(); toggleFavorite(${artisan.id}, this)" style="background: none; border: none; color: ${isFavorite ? '#ef4444' : '#ddd'}; cursor: pointer; font-size: 18px;">
                            <i class="fa fa-heart${isFavorite ? '' : '-o'}"></i>
                        </button>
                    </div>
                `;
            });
            recentArtisans.innerHTML = html;
        }
    }
    
    // ==================== DISPLAY RECOMMENDED ARTISANS ====================
    const recommendedArtisans = document.getElementById('recommendedArtisansList');
    if (recommendedArtisans) {
        // Get top rated artisans overall
        const topRatedArtisans = userData.artisans
            .filter(a => !userData.bookings.some(b => b.artisan_id === a.id)) // Exclude recently booked
            .sort((a, b) => (b.rating || 0) - (a.rating || 0))
            .slice(0, 3);
        
        if (topRatedArtisans.length === 0) {
            recommendedArtisans.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">No recommendations available yet.</p>';
        } else {
            let html = '';
            topRatedArtisans.forEach(artisan => {
                const isFavorite = userData.favorites.some(f => f.id === artisan.id);
                html += `
                    <div style="display: flex; align-items: center; padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: all 0.3s;" onclick="viewProfile(${artisan.id})" onmouseover="this.style.backgroundColor='#f9f9f9'" onmouseout="this.style.backgroundColor='white'">
                        <img src="${artisan.profile_picture || 'https://via.placeholder.com/50'}" alt="${artisan.name}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; margin-right: 12px;" />
                        <div style="flex: 1;">
                            <h4 style="margin: 0; font-size: 14px; color: #333;">${artisan.name}</h4>
                            <p style="margin: 4px 0 0 0; font-size: 12px; color: #666;">${artisan.service_type || 'Service Provider'}</p>
                            <div style="font-size: 12px; color: #f59e0b; margin-top: 2px;">
                                <i class="fa fa-star"></i> ${artisan.rating || 4.5}/5 (${artisan.total_reviews || 0})
                            </div>
                        </div>
                        <button class="favorite-btn" onclick="event.stopPropagation(); toggleFavorite(${artisan.id}, this)" style="background: none; border: none; color: ${isFavorite ? '#ef4444' : '#ddd'}; cursor: pointer; font-size: 18px;">
                            <i class="fa fa-heart${isFavorite ? '' : '-o'}"></i>
                        </button>
                    </div>
                `;
            });
            recommendedArtisans.innerHTML = html;
        }
    }
}

function displayBookings(filterStatus = 'all') {
    const bookingsContainer = document.querySelector('.bookings-list');
    if (!bookingsContainer) return;
    
    // Filter bookings by status
    let filteredBookings = userData.bookings;
    if (filterStatus === 'upcoming') {
        filteredBookings = userData.bookings.filter(b => b.status !== 'completed' && b.status !== 'declined' && b.status !== 'cancelled');
    } else if (filterStatus === 'completed') {
        filteredBookings = userData.bookings.filter(b => b.status === 'completed' || b.status === 'paid');
    } else if (filterStatus === 'cancelled') {
        filteredBookings = userData.bookings.filter(b => b.status === 'cancelled' || b.status === 'declined');
    }
    
    if (filteredBookings.length === 0) {
        bookingsContainer.innerHTML = '<div class="empty-state"><p>No ' + (filterStatus !== 'all' ? filterStatus : '') + ' bookings. <button class="btn btn-primary btn-sm" onclick="switchTab(\'search\')">Find Artisans</button></p></div>';
        return;
    }
    
    let html = '';
    filteredBookings.forEach(booking => {
        const statusClass = `badge-${booking.status === 'pending' ? 'warning' : booking.status === 'confirmed' ? 'info' : booking.status === 'completed' ? 'success' : 'secondary'}`;
        
        html += `
            <div class="booking-item">
                <div class="booking-artisan">
                    <img src="https://via.placeholder.com/60" alt="${booking.artisan_name}" />
                    <div>
                        <h4>${booking.artisan_name}</h4>
                        <p>${booking.service_name}</p>
                    </div>
                </div>
                <div class="booking-service">
                    <h3>${booking.service_name}</h3>
                    <p>${booking.notes || 'No special notes'}</p>
                </div>
                <div class="booking-details">
                    <span><i class="fa fa-calendar"></i>${booking.date}</span>
                    <span><i class="fa fa-clock-o"></i>${booking.time}</span>
                </div>
                <div class="booking-status">
                    <span class="badge ${statusClass}">${booking.status}</span>
                </div>
                <div class="booking-actions">
                    ${booking.status === 'completed' ? `
                        <button class="btn btn-sm btn-primary" onclick="payBooking(${booking.id})"><i class="fa fa-credit-card"></i> Pay now</button>
                        <button class="btn btn-sm btn-outline" onclick="rateBooking(${booking.id})">Rate</button>
                        <button class="btn btn-sm btn-secondary" onclick="bookAgain(${booking.id})">Book Again</button>
                    ` : booking.status === 'paid' ? `
                        <span class="badge badge-success"><i class="fa fa-check"></i> Paid</span>
                    ` : booking.status === 'pending' || booking.status === 'confirmed' ? `
                        <button class="btn btn-sm btn-outline" onclick="contactArtisan(${booking.artisan_id})">Contact</button>
                        <button class="btn btn-sm btn-danger" onclick="cancelBooking(${booking.id})">Cancel</button>
                    ` : `
                        <button class="btn btn-sm btn-outline" onclick="viewBookingDetails(${booking.id})">Details</button>
                    `}
                </div>
            </div>
        `;
    });
    
    bookingsContainer.innerHTML = html;
}

function displayProfile() {
    const profileContainer = document.getElementById('profileContainer');
    if (profileContainer) {
        const picture = userData.user.profile_picture
            ? (userData.user.profile_picture.startsWith('http') ? userData.user.profile_picture : `http://localhost:5000${userData.user.profile_picture}`)
            : 'https://via.placeholder.com/120';
        profileContainer.innerHTML = `
            <div class="client-profile-card">
                <div class="client-profile-hero">
                    <div class="profile-image">
                        <img id="userProfileImage" src="${picture}" alt="Profile photo" />
                        <button class="btn-change-photo" type="button" onclick="changePhoto()" aria-label="Change profile photo"><i class="fa fa-camera"></i></button>
                    </div>
                    <div><span class="profile-eyebrow">Your account</span><h2>${userData.user.name || 'Client'}</h2><p>${userData.user.email || ''}</p></div>
                    <button class="btn btn-primary" type="button" onclick="editProfile()"><i class="fa fa-pencil"></i> Edit profile</button>
                </div>
                <div class="client-profile-details"><div><span>Email address</span><strong>${userData.user.email || 'Not provided'}</strong></div><div><span>Cell phone</span><strong>${userData.user.phone || 'Add a cell phone number'}</strong></div><div><span>Member since</span><strong>${userData.user.created_at ? new Date(userData.user.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : 'Recently'}</strong></div></div>
            </div>`;
    }
    const profileName = document.getElementById('profileUserName') || document.querySelector('.profile-info h2');
    if (profileName) profileName.textContent = userData.user.name || 'N/A';
    const profileImage = document.getElementById('userProfileImage');
    if (profileImage) {
        const picture = userData.user.profile_picture;
        profileImage.src = picture
            ? (picture.startsWith('http') ? picture : `http://localhost:5000${picture}`)
            : 'https://via.placeholder.com/120';
    }
    
    const detailRows = document.querySelectorAll('.detail-row span:last-child');
    if (detailRows[0]) detailRows[0].textContent = userData.user.email || 'Not provided';
    if (detailRows[1]) detailRows[1].textContent = userData.user.phone || 'Not provided';

    const profileStats = document.querySelectorAll('.profile-stats span');
    if (profileStats[0]) profileStats[0].innerHTML = `<strong>${userData.bookings.length}</strong><small>Services</small>`;
    if (profileStats[1]) profileStats[1].innerHTML = `<strong>${userData.favorites.length}</strong><small>Favorites</small>`;
    if (profileStats[2]) profileStats[2].innerHTML = `<strong>${userData.bookings.filter(booking => booking.status === 'completed' || booking.status === 'paid').length}</strong><small>Completed</small>`;

    const memberSince = document.querySelector('.profile-info p');
    if (memberSince) {
        const date = userData.user.created_at ? new Date(userData.user.created_at) : null;
        memberSince.textContent = date && !Number.isNaN(date.getTime())
            ? `Member since ${date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}`
            : 'Client account';
    }
}

function displayFavorites() {
    const favoritesGrid = document.querySelector('.favorites-grid');
    if (!favoritesGrid) return;
    
    if (userData.favorites.length === 0) {
        favoritesGrid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>No favorite artisans yet. <button class="btn btn-primary btn-sm" onclick="switchTab(\'search\')">Find Artisans</button></p></div>';
        return;
    }
    
    let html = '';
    userData.favorites.forEach(artisan => {
        html += `
            <div class="artisan-card">
                <div class="artisan-header">
                    <img src="${getArtisanProfileImage(artisan.profile_picture)}" alt="${artisan.name}" />
                    <button class="favorite-btn" onclick="toggleFavorite(${artisan.id}, this)">
                        <i class="fa fa-heart"></i>
                    </button>
                </div>
                <div class="artisan-details">
                    <h3>${artisan.name}</h3>
                    <p class="service-type">${artisan.service_type || 'Service Provider'}</p>
                    <div class="rating-bar">
                        <span class="stars"><i class="fa fa-star"></i> ${artisan.rating || 4.5}/5</span>
                        <small>(${artisan.total_reviews || 0} reviews)</small>
                    </div>
                    <div class="price">$${artisan.hourly_rate || 75}/hour</div>
                    <p class="bio">${artisan.bio || 'Professional service provider'}</p>
                </div>
                <div class="artisan-footer">
                    <button class="btn btn-primary" onclick="viewProfile(${artisan.id})">View Profile</button>
                    <button class="btn btn-secondary" onclick="bookArtisan(${artisan.id}, '${artisan.name}')">Book Now</button>
                </div>
            </div>
        `;
    });
    favoritesGrid.innerHTML = html;
}

function displayHistory() {
    const historyList = document.querySelector('.history-list');
    if (!historyList) return;
    
    // Get completed bookings
    const completedBookings = userData.bookings.filter(b => b.status === 'completed' || b.status === 'paid');
    
    if (completedBookings.length === 0) {
        historyList.innerHTML = '<div style="text-align: center; padding: 40px; color: #999;"><p>No service history yet</p></div>';
        return;
    }
    
    let html = '';
    completedBookings.forEach(booking => {
        html += `
            <div class="booking-item" style="background-color: #f0f9ff;">
                <div class="booking-artisan">
                    <img src="https://via.placeholder.com/60" alt="${booking.artisan_name}" />
                    <div>
                        <h4>${booking.artisan_name}</h4>
                        <p>${booking.service_name}</p>
                    </div>
                </div>
                <div class="booking-service">
                    <h3>${booking.service_name}</h3>
                    <p>${booking.notes || 'Service completed'}</p>
                </div>
                <div class="booking-details">
                    <span><i class="fa fa-calendar"></i>${booking.date}</span>
                    <span><i class="fa fa-check"></i>Completed</span>
                </div>
                <div class="booking-status">
                    <span class="badge badge-${booking.status === 'paid' ? 'success' : 'warning'}">${booking.status === 'paid' ? 'Paid' : 'Payment due'}</span>
                </div>
                <div class="booking-actions">
                    ${booking.status === 'completed' ? `<button class="btn btn-sm btn-primary" onclick="payBooking(${booking.id})"><i class="fa fa-credit-card"></i> Pay now</button>` : ''}
                    <button class="btn btn-sm btn-outline" onclick="rateBooking(${booking.id})">Rate</button>
                    <button class="btn btn-sm btn-secondary" onclick="bookAgain(${booking.id}, '${booking.artisan_name}', '${booking.service_name}')">Book Again</button>
                </div>
            </div>
        `;
    });
    historyList.innerHTML = html;
}

function displayMessages() {
    const messagesContainer = document.querySelector('.messages-container');
    if (!messagesContainer) return;
    
    const threadsContainer = messagesContainer.querySelector('.messages-list');
    const chatWindow = messagesContainer.querySelector('.chat-window');
    
    if (!threadsContainer || !chatWindow) return;
    
    // If no messages, show empty state
    if (!userData.messages || userData.messages.length === 0) {
        threadsContainer.innerHTML = `
            <div style="padding: 20px; text-align: center; color: #999;">
                <i class="fa fa-envelope" style="font-size: 32px; margin-bottom: 12px; opacity: 0.5; display: block;"></i>
                <p>No messages yet</p>
                <p style="font-size: 12px;">Messages will appear when artisans respond</p>
            </div>
        `;
        chatWindow.style.display = 'none';
        return;
    }
    
    // Build message threads
    let html = '';
    userData.messages.forEach((thread, index) => {
        const lastMessage = thread.last_message || 'No messages';
        const unreadCount = thread.unread_count || (thread.unread ? 1 : 0);
        const unreadBadge = unreadCount > 0 ? `<div class="unread-badge">${unreadCount}</div>` : '';
        const activeClass = index === 0 ? 'active' : '';
        
        html += `
            <div class="message-thread ${activeClass}" onclick="openChat(${thread.artisan_id || thread.id}, event)">
                <div class="message-avatar">
                    <img src="${thread.avatar || thread.profile_picture || 'https://via.placeholder.com/50'}" alt="${thread.artisan_name || 'Artisan'}" />
                </div>
                <div class="message-preview">
                    <h4>${thread.artisan_name || 'Unknown'}</h4>
                    <p>${lastMessage}</p>
                    <small>${thread.last_message_time || thread.timestamp || 'Just now'}</small>
                </div>
                ${unreadBadge}
            </div>
        `;
    });
    
    threadsContainer.innerHTML = html;
    
    // Show first conversation by default
    if (userData.messages.length > 0) {
        setTimeout(() => {
            openChat(userData.messages[0].user_id || userData.messages[0].artisan_id || userData.messages[0].id);
        }, 100);
    }
}

function displayPayments() {
    const paymentList = document.getElementById('paymentList') || document.querySelector('.payment-table tbody');
    if (!paymentList) return;

    if (!userData.payments.length) {
        paymentList.innerHTML = '<p style="text-align: center; color: #999; padding: 24px;">No payment records yet.</p>';
        return;
    }

    const total = userData.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    const summary = document.getElementById('paymentSummary');
    if (summary) {
        summary.innerHTML = `<div class="summary-card"><h3>Total Spent</h3><p class="amount">$${total.toFixed(2)}</p><small>Completed services</small></div><div class="summary-card"><h3>Completed Services</h3><p class="amount">${userData.payments.length}</p><small>Linked to artisans</small></div>`;
    }

    const rows = userData.payments.map(payment => `
        <div class="payment-row">
            <strong>${payment.service_name}</strong>
            <span>${payment.artisan_name}</span>
            <span>$${Number(payment.amount || 0).toFixed(2)}</span>
            <span class="badge badge-success">${payment.status}</span>
        </div>
    `).join('');
    paymentList.innerHTML = rows;
}

function displayPaymentMethods() {
    const list = document.getElementById('paymentMethodsList');
    if (!list) return;
    list.innerHTML = userData.paymentMethods.length
        ? userData.paymentMethods.map(method => `<div class="setting-item"><strong>${method.method_type.toUpperCase()}</strong><span>${method.account_label || method.account_reference}</span></div>`).join('')
        : '<p class="settings-empty">No payment methods saved.</p>';
}

function displayClientSettings() {
    const settings = userData.settings;
    const booking = document.getElementById('bookingNotifications');
    const message = document.getElementById('messageNotifications');
    const visibility = document.getElementById('profileVisibility');
    if (booking) booking.checked = Boolean(settings.booking_notifications);
    if (message) message.checked = Boolean(settings.message_notifications);
    if (visibility) visibility.checked = Boolean(settings.profile_visibility);
}

function openChat(artisanId, event) {
    if (event) event.stopPropagation();
    
    const conversation = userData.messages.find(m => m.artisan_id === artisanId || m.id === artisanId);
    if (!conversation) return;

    if (!conversation.messages) {
        fetch(`http://localhost:5000/api/user/${localStorage.getItem('userId')}/messages/${artisanId}`)
            .then(res => res.json())
            .then(data => {
                conversation.messages = data.status === 'success' ? (data.messages || []) : [];
                openChat(artisanId);
            })
            .catch(err => console.error('Error loading conversation:', err));
        return;
    }
    
    // Update active thread
    const threads = document.querySelectorAll('.message-thread');
    threads.forEach(t => t.classList.remove('active'));
    if (event && event.currentTarget) {
        event.currentTarget.classList.add('active');
    }
    
    // Update chat window
    const chatWindow = document.querySelector('.chat-window');
    const chatHeader = chatWindow.querySelector('.chat-header h3');
    const chatMessages = chatWindow.querySelector('.chat-messages');
    const messageInput = chatWindow.querySelector('.chat-input input');
    
    if (chatHeader) chatHeader.textContent = conversation.artisan_name || 'Chat';
    
    // Display messages
    let messagesHtml = '';
    const messages = conversation.messages || [];
    
    if (messages.length === 0) {
        messagesHtml = '<div style="text-align: center; color: #999; padding: 20px;">No messages yet. Start the conversation!</div>';
    } else {
        messages.forEach(msg => {
            const msgClass = msg.is_sender || msg.sender === 'customer' ? 'sent' : 'received';
            messagesHtml += `
                <div class="message ${msgClass}">
                    <p>${msg.content || msg.message_text || msg.text || ''}</p>
                    <small>${msg.timestamp || msg.time || ''}</small>
                </div>
            `;
        });
    }
    
    chatMessages.innerHTML = messagesHtml;
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    // Store current chat ID for sending messages
    messageInput.dataset.artisanId = artisanId;
    messageInput.onkeypress = (e) => {
        if (e.key === 'Enter') {
            sendMessage(localStorage.getItem('userId'), artisanId);
            e.preventDefault();
        }
    };
    
    chatWindow.style.display = 'block';
}

function sendMessage(userId, artisanId) {
    const messageInput = document.querySelector('.chat-input input');
    const messageText = messageInput.value.trim();
    
    if (!messageText) return;
    
    fetch(`http://localhost:5000/api/user/${userId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            sender_id: userId || localStorage.getItem('userId'),
            recipient_id: artisanId,
            content: messageText
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            messageInput.value = '';
            
            // Add message to UI immediately
            const chatMessages = document.querySelector('.chat-messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message sent';
            messageDiv.innerHTML = `
                <p>${messageText}</p>
                <small>Just now</small>
            `;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        } else {
            showNotification('Failed to send message', 'error');
        }
    })
    .catch(err => {
        console.error("Error sending message:", err);
        showNotification('Error sending message', 'error');
    });
}

function displayArtisans() {
    console.log("📺 displayArtisans() called");
    const grid = document.getElementById('searchArtisansGrid');
    console.log("✓ Grid element found:", !!grid);
    console.log("✓ userData.artisans length:", userData.artisans ? userData.artisans.length : 0);
    
    if (!grid) {
        console.error("✗ Grid element #searchArtisansGrid not found!");
        return;
    }
    
    // If artisans haven't been fetched yet
    if (!userData.artisans) {
        console.warn("⚠ userData.artisans not yet initialized, showing loading");
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>Loading artisans...</p></div>';
        return;
    }
    
    // If no artisans in the array
    if (userData.artisans.length === 0) {
        console.warn("⚠ No artisans loaded from API");
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>No artisans available. Is the Flask server running on http://localhost:5000?</p></div>';
        return;
    }
    
    console.log(`✓ Rendering ${userData.artisans.length} artisan cards`);
    
    let html = '';
    userData.artisans.forEach((artisan, index) => {
        console.log(`  - Card ${index + 1}: ${artisan.name}`);
        const isFavorite = userData.favorites.some(f => f.id === artisan.id);
        html += `
            <div class="artisan-card">
                <div class="artisan-header">
                    <img src="${getArtisanProfileImage(artisan.profile_picture)}" alt="${artisan.name}" />
                    <button class="favorite-btn" onclick="toggleFavorite(${artisan.id}, this)">
                        <i class="fa fa-heart${isFavorite ? '' : '-o'}"></i>
                    </button>
                </div>
                <div class="artisan-details">
                    <h3>${artisan.name}</h3>
                    <p class="service-type">${artisan.service_type || 'Service Provider'}</p>
                    <div class="rating-bar">
                        <span class="stars"><i class="fa fa-star"></i> ${artisan.rating || 4.5}/5</span>
                        <small>(${artisan.total_reviews || 0} reviews)</small>
                    </div>
                    <div class="price">$${artisan.hourly_rate || 75}/hour</div>
                    <p class="bio">${artisan.bio || 'Professional service provider'}</p>
                </div>
                <div class="artisan-footer">
                    <button class="btn btn-primary" onclick="viewProfile(${artisan.id})">View Profile</button>
                    <button class="btn btn-secondary" onclick="bookArtisan(${artisan.id}, '${artisan.name}')">Book Now</button>
                </div>
            </div>
        `;
    });
    
    grid.innerHTML = html;
    console.log("✓ Artisans rendered successfully");
}

// ==================== ACTION FUNCTIONS ====================

function viewProfile(artisanId) {
    if (!userData.artisans.some(artisan => artisan.id === artisanId)) return;
    window.location.href = `artisan-profile.html?id=${encodeURIComponent(artisanId)}`;
}

function bookArtisan(artisanId, artisanName) {
    const artisan = userData.artisans.find(a => a.id === artisanId);
    if (!artisan) return;
    
    // Generate service options dropdown
    let serviceOptions = '<option value="">-- Select a service --</option>';
    userData.services.forEach(service => {
        serviceOptions += `<option value="${service.id}">${service.name} ($${service.average_rate}/hr)</option>`;
    });
    
    const form = `
        <form onsubmit="submitBooking(${artisanId}, '${artisanName}', event)" class="form booking-form">
            <div class="form-group">
                <label>Service *</label>
                <select id="serviceId" required>
                    ${serviceOptions}
                </select>
            </div>
            <div class="form-group">
                <label>Service Date *</label>
                <input type="date" id="bookingDate" required />
            </div>
            <div class="form-group">
                <label>Service Time *</label>
                <input type="time" id="bookingTime" required />
            </div>
            <div class="form-group">
                <label>Service Duration (hours) *</label>
                <input type="number" id="duration" value="1" min="1" required />
            </div>
            <div class="form-group">
                <label>Service Location *</label>
                <input type="text" id="clientLocationAddress" placeholder="Client address or landmark" required />
                <button type="button" class="btn btn-outline location-button" onclick="useCurrentLocation()"><i class="fa fa-location-arrow"></i> Use my current location</button>
                <input type="hidden" id="clientLatitude" />
                <input type="hidden" id="clientLongitude" />
                <small id="locationStatus" class="form-hint">Your location helps the artisan estimate arrival and travel cost.</small>
            </div>
            <div class="form-group">
                <label>Special Notes</label>
                <textarea id="bookingNotes" placeholder="Any special requests..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Confirm Booking</button>
        </form>
    `;
    showModalWithForm(`Book ${artisanName}`, form);
}

function useCurrentLocation() {
    const status = document.getElementById('locationStatus');
    if (!navigator.geolocation) {
        if (status) status.textContent = 'Location is not supported by this browser.';
        return;
    }
    if (status) status.textContent = 'Requesting your location...';
    navigator.geolocation.getCurrentPosition(position => {
        document.getElementById('clientLatitude').value = position.coords.latitude;
        document.getElementById('clientLongitude').value = position.coords.longitude;
        if (status) status.textContent = 'Location captured. The artisan will receive a route estimate.';
    }, () => {
        if (status) status.textContent = 'Location permission was not granted. Enter your address instead.';
    }, { enableHighAccuracy: true, timeout: 10000 });
}

function submitBooking(artisanId, artisanName, event) {
    event.preventDefault();
    const userId = localStorage.getItem("userId");
    const serviceId = document.getElementById('serviceId').value;
    const date = document.getElementById('bookingDate').value;
    const time = document.getElementById('bookingTime').value;
    const duration = document.getElementById('duration').value;
    const notes = document.getElementById('bookingNotes').value;
    const clientLocationAddress = document.getElementById('clientLocationAddress')?.value || '';
    const clientLatitude = document.getElementById('clientLatitude')?.value || null;
    const clientLongitude = document.getElementById('clientLongitude')?.value || null;
    
    if (!serviceId) {
        showNotification('Please select a service', 'warning');
        return;
    }
    
    const artisanAvailabilityCheck = fetch(`http://localhost:5000/api/artisan-profile/${artisanId}/unavailable-dates`)
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') {
                throw new Error('Could not verify artisan availability. Booking was not submitted.');
            }
            const unavailable = (data.unavailable_dates || []).find(period =>
                date >= period.start_date && date <= period.end_date
            );
            if (unavailable) {
                throw new Error(`${artisanName} is unavailable from ${unavailable.start_date} to ${unavailable.end_date} (${unavailable.reason}). Please choose another date.`);
            }
        });

    artisanAvailabilityCheck.then(() => fetch(`http://localhost:5000/api/booking`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            customer_id: userId,
            artisan_id: artisanId,
            service_id: parseInt(serviceId),
            booking_date: date,
            booking_time: time,
            notes: notes,
            duration: duration,
            client_location_address: clientLocationAddress,
            client_latitude: clientLatitude,
            client_longitude: clientLongitude
        })
    }))
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification(`Booking confirmed with ${artisanName}!`, 'success');
            loadAllData(userId);
        } else {
            showNotification(data.message || 'This artisan is unavailable on the selected date.', 'error');
        }
    })
    .catch(err => showNotification(err.message || 'Failed to create booking', 'error'));
}

function toggleFavorite(artisanId, buttonElement) {
    const userId = localStorage.getItem("userId");
    const isFavorite = userData.favorites.some(f => f.id === artisanId);

    if (isFavorite) {
        fetch(`http://localhost:5000/api/user/${userId}/favorites/${artisanId}`, { method: 'DELETE' })
            .then(res => res.json())
            .then(data => {
                if (data.status !== 'success') throw new Error(data.message || 'Unable to remove favorite');
                userData.favorites = userData.favorites.filter(f => f.id !== artisanId);
                if (buttonElement) buttonElement.innerHTML = '<i class="fa fa-heart-o"></i>';
                displayFavorites();
                showNotification('Removed from favorites', 'info');
            })
            .catch(err => showNotification(err.message, 'error'));
    } else {
        const artisan = userData.artisans.find(a => a.id === artisanId);
        if (artisan) {
            fetch(`http://localhost:5000/api/user/${userId}/favorites`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ artisan_id: artisanId })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Unable to add favorite');
                    userData.favorites.push(artisan);
                    if (buttonElement) buttonElement.innerHTML = '<i class="fa fa-heart"></i>';
                    displayFavorites();
                    showNotification('Added to favorites!', 'success');
                })
                .catch(err => showNotification(err.message, 'error'));
        }
    }
}

function filterBookings(status) {
    // Update tab button active states
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    displayBookings(status);
}

function viewBookingDetails(bookingId) {
    const booking = userData.bookings.find(b => b.id === bookingId);
    if (!booking) return;
    
    let details = `
        <div style="text-align: left;">
            <h3>${booking.service_name}</h3>
            <p><strong>Artisan:</strong> ${booking.artisan_name}</p>
            <p><strong>Date:</strong> ${booking.date}</p>
            <p><strong>Time:</strong> ${booking.time}</p>
            <p><strong>Status:</strong> <span class="badge badge-${booking.status === 'pending' ? 'warning' : booking.status === 'confirmed' ? 'info' : booking.status === 'completed' ? 'success' : 'secondary'}">${booking.status}</span></p>
            <p><strong>Notes:</strong> ${booking.notes || 'No notes'}</p>
            <div style="margin-top: 16px; display: flex; gap: 8px;">
                ${booking.status === 'completed' ? `
                    <button class="btn btn-primary" onclick="closeModal(); rateBooking(${booking.id})">Leave Review</button>
                    <button class="btn btn-secondary" onclick="closeModal(); bookAgain(${booking.id}, '${booking.artisan_name}', '${booking.service_name}')">Book Again</button>
                ` : `
                    <button class="btn btn-outline" onclick="closeModal(); contactArtisan(${booking.artisan_id})">Contact Artisan</button>
                    <button class="btn btn-danger" onclick="closeModal(); cancelBooking(${booking.id})">Cancel Booking</button>
                `}
            </div>
        </div>
    `;
    showModalWithForm('Booking Details', details);
}

// Load artisans specifically for the search tab (direct fetch pattern from find-artisans.html)
function loadArtisansForSearch() {
    console.log("🔍 loadArtisansForSearch() called - fetching from http://localhost:5000/api/search/artisans");
    
    const grid = document.getElementById('searchArtisansGrid');
    if (!grid) {
        console.error("✗ Grid element not found!");
        return;
    }
    
    // Show loading state
    grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>⏳ Loading artisans...</p></div>';
    
    fetch('http://localhost:5000/api/search/artisans')
        .then(response => {
            console.log("✓ API Response status:", response.status);
            return response.json();
        })
        .then(data => {
            console.log("✓ API Response data received:", data);
            
            if (data.status === 'success' && data.artisans) {
                // Convert API data to expected format (same as find-artisans.html)
                userData.artisans = data.artisans.map((a, index) => ({
                    id: a.id || index,
                    user_id: a.user_id,
                    name: a.name,
                    service_type: a.service_type,
                    experience_years: a.experience_years || 0,
                    rating: a.rating || 4.5,
                    total_reviews: a.total_reviews || 0,
                    hourly_rate: a.hourly_rate || 75,
                    bio: a.bio || 'Professional service provider',
                    phone: a.phone || 'Contact via email',
                    email: a.email || 'no-email@tradepro.ls',
                    location: a.location || 'Lesotho',
                    profile_picture: getArtisanProfileImage(a.profile_picture)
                }));
                
                console.log(`✓ Successfully loaded ${userData.artisans.length} artisans`);
                displayArtisansInSearch();
                
                if (userData.artisans.length > 0) {
                    showNotification(`Loaded ${userData.artisans.length} artisans`, 'success');
                }
            } else {
                console.error("✗ API error:", data.message || 'Unknown error');
                grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>Failed to load artisans</p></div>';
                showNotification('Failed to load artisans: ' + (data.message || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error("✗ Error fetching artisans:", error);
            console.error("   Is the Flask server running on http://localhost:5000?");
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>❌ Error loading artisans. Is the Flask server running on port 5000?</p></div>';
            showNotification('Error loading artisans. Is Flask running?', 'error');
        });
}

function getArtisanProfileImage(profilePicture) {
    if (!profilePicture) return 'https://via.placeholder.com/150';
    if (profilePicture.startsWith('data:') || profilePicture.startsWith('http://') || profilePicture.startsWith('https://')) {
        return profilePicture;
    }
    return `http://localhost:5000${profilePicture.startsWith('/') ? '' : '/'}${profilePicture}`;
}

// Display artisans in the search grid
function displayArtisansInSearch() {
    console.log("📺 displayArtisansInSearch() called");
    const grid = document.getElementById('searchArtisansGrid');
    
    if (!grid) {
        console.error("✗ Grid element not found!");
        return;
    }
    
    if (!userData.artisans || userData.artisans.length === 0) {
        console.warn("⚠ No artisans to display");
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>No artisans available</p></div>';
        return;
    }
    
    console.log(`✓ Rendering ${userData.artisans.length} artisan cards`);
    
    let html = '';
    userData.artisans.forEach((artisan, index) => {
        console.log(`  - Card ${index + 1}: ${artisan.name}`);
        const isFavorite = userData.favorites.some(f => f.id === artisan.id);
        html += `
            <div class="artisan-card">
                <div class="artisan-header">
                    <img src="${getArtisanProfileImage(artisan.profile_picture)}" alt="${artisan.name}" />
                    <button class="favorite-btn" onclick="toggleFavorite(${artisan.id}, this)">
                        <i class="fa fa-heart${isFavorite ? '' : '-o'}"></i>
                    </button>
                </div>
                <div class="artisan-details">
                    <h3>${artisan.name}</h3>
                    <p class="service-type">${artisan.service_type || 'Service Provider'}</p>
                    <div class="rating-bar">
                        <span class="stars"><i class="fa fa-star"></i> ${artisan.rating || 4.5}/5</span>
                        <small>(${artisan.total_reviews || 0} reviews)</small>
                    </div>
                    <div class="price">$${artisan.hourly_rate || 75}/hour</div>
                    <p class="bio">${artisan.bio || 'Professional service provider'}</p>
                </div>
                <div class="artisan-footer">
                    <button class="btn btn-primary" onclick="viewProfile(${artisan.id})">View Profile</button>
                    <button class="btn btn-secondary" onclick="bookArtisan(${artisan.id}, '${artisan.name}')">Book Now</button>
                </div>
            </div>
        `;
    });
    
    grid.innerHTML = html;
    console.log("✓ Artisans rendered successfully");
}

function handleServiceFilterChange() {
    // Get the selected service value
    const serviceFilter = document.getElementById('serviceFilter')?.value || '';
    
    // If "All Services" is selected (empty value), reset all filters and show all artisans
    if (serviceFilter === '') {
        // Reset all other filters
        document.getElementById('locationFilter').value = '';
        document.getElementById('ratingFilter').value = '';
        document.getElementById('priceMin').value = '';
        document.getElementById('priceMax').value = '';
        
        // Load all artisans from API
        loadArtisansForSearch();
        
        showNotification(`Loading all artisans...`, 'info');
    } else {
        // Service is selected, show a hint that user should click Search
        showNotification(`Service selected: ${serviceFilter}. Click Search to filter.`, 'info');
    }
}

function applyFilters() {
    // Get filter values
    const serviceFilter = document.getElementById('serviceFilter')?.value || '';
    const locationFilter = document.getElementById('locationFilter')?.value || '';
    const ratingFilter = document.getElementById('ratingFilter')?.value || '';
    const priceMin = document.getElementById('priceMin')?.value || '';
    const priceMax = document.getElementById('priceMax')?.value || '';
    
    // Build search parameters
    let url = 'http://localhost:5000/api/search/artisans?';
    let params = [];
    
    if (serviceFilter) {
        params.push(`service_type=${encodeURIComponent(serviceFilter)}`);
    }
    
    if (locationFilter) {
        params.push(`location=${encodeURIComponent(locationFilter)}`);
    }
    
    if (ratingFilter) {
        params.push(`min_rating=${encodeURIComponent(ratingFilter)}`);
    }
    
    if (priceMin) params.push(`price_min=${encodeURIComponent(priceMin)}`);
    if (priceMax) params.push(`price_max=${encodeURIComponent(priceMax)}`);
    
    url += params.join('&');
    console.log('Applying filters with URL:', url);
    
    // Fetch filtered artisans from backend
    fetch(url)
        .then(res => res.json())
        .then(data => {
            console.log('Filter response:', data);
            if (data.status === 'success') {
                userData.artisans = data.artisans || [];
                if (data.artisans.length === 0) {
                    showNotification('No artisans match your filters', 'info');
                } else {
                    showNotification(`Found ${data.total} artisans`, 'success');
                }
                displayFilteredArtisans(data.artisans || []);
            } else {
                showNotification('Error fetching search results: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            showNotification('Error performing search', 'error');
        });
}

let filterTimer;
function applyFiltersRealtime() {
    clearTimeout(filterTimer);
    filterTimer = setTimeout(applyFilters, 250);
}

function displayFilteredArtisans(artisans) {
    const grid = document.getElementById('searchArtisansGrid');
    if (!grid) return;
    
    if (artisans.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;"><p>No artisans match your filters</p></div>';
        return;
    }
    
    let html = '';
    artisans.forEach(artisan => {
        const isFavorite = userData.favorites.some(f => f.id === artisan.id);
        html += `
            <div class="artisan-card">
                <div class="artisan-header">
                    <img src="${getArtisanProfileImage(artisan.profile_picture)}" alt="${artisan.name}" />
                    <button class="favorite-btn" onclick="toggleFavorite(${artisan.id}, this)">
                        <i class="fa fa-heart${isFavorite ? '' : '-o'}"></i>
                    </button>
                </div>
                <div class="artisan-details">
                    <h3>${artisan.name}</h3>
                    <p class="service-type">${artisan.service_type || 'Service Provider'}</p>
                    <div class="rating-bar">
                        <span class="stars"><i class="fa fa-star"></i> ${artisan.rating || 4.5}/5</span>
                        <small>(${artisan.total_reviews || 0} reviews)</small>
                    </div>
                    <div class="price">$${artisan.hourly_rate || 75}/hour</div>
                    <p class="bio">${artisan.bio || 'Professional service provider'}</p>
                </div>
                <div class="artisan-footer">
                    <button class="btn btn-primary" onclick="viewProfile(${artisan.id})">View Profile</button>
                    <button class="btn btn-secondary" onclick="bookArtisan(${artisan.id}, '${artisan.name}')">Book Now</button>
                </div>
            </div>
        `;
    });
    grid.innerHTML = html;
}

function bookAgain(bookingId, artisanName, serviceName) {
    // Use the same artisan and service for booking again
    const userId = localStorage.getItem("userId");
    
    // Find the artisan by name
    const artisan = userData.artisans.find(a => a.name === artisanName);
    if (!artisan) {
        showNotification('Could not find artisan', 'error');
        return;
    }
    
    const form = `
        <form onsubmit="submitBooking(${artisan.id}, '${artisanName}', event)" class="form">
            <div class="form-group">
                <label>Service *</label>
                <input type="text" value="${serviceName}" disabled />
            </div>
            <div class="form-group">
                <label>Service Date *</label>
                <input type="date" id="bookingDate" required />
            </div>
            <div class="form-group">
                <label>Service Time *</label>
                <input type="time" id="bookingTime" required />
            </div>
            <div class="form-group">
                <label>Service Duration (hours) *</label>
                <input type="number" id="duration" value="1" min="1" required />
            </div>
            <div class="form-group">
                <label>Special Notes</label>
                <textarea id="bookingNotes" placeholder="Any special requests..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Confirm Booking</button>
        </form>
    `;
    showModalWithForm(`Book ${artisanName} Again`, form);
}

function cancelBooking(id) {
    if (confirm('Cancel this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'cancelled' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                userData.artisans = data.artisans || [];
                showNotification('Booking cancelled!', 'success');
                loadAllData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => showNotification('Failed to cancel booking', 'error'));
    }
}

function rateBooking(id) {
    const form = `
        <form onsubmit="submitRating(${id}, event)" class="form">
            <div class="form-group">
                <label>Rating *</label>
                <div style="display: flex; gap: 8px; margin-top: 8px;">
                    <button type="button" class="star" onclick="setRating(1, this)">⭐</button>
                    <button type="button" class="star" onclick="setRating(2, this)">⭐</button>
                    <button type="button" class="star" onclick="setRating(3, this)">⭐</button>
                    <button type="button" class="star" onclick="setRating(4, this)">⭐</button>
                    <button type="button" class="star" onclick="setRating(5, this)">⭐</button>
                </div>
                <input type="hidden" id="ratingValue" value="5" />
            </div>
            <div class="form-group">
                <label>Comment</label>
                <textarea id="ratingComment" placeholder="Share your experience..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Rating</button>
        </form>
    `;
    showModalWithForm('Rate This Service', form);
}

function setRating(value, element) {
    document.getElementById('ratingValue').value = value;
    const buttons = element.parentElement.querySelectorAll('button');
    buttons.forEach((btn, index) => {
        btn.style.opacity = index < value ? '1' : '0.3';
    });
}

function submitRating(id, event) {
    event.preventDefault();
    const rating = parseInt(document.getElementById('ratingValue').value);
    const comment = document.getElementById('ratingComment').value;
    
    const userId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/client/${userId}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ booking_id: id, rating, comment })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Review failed');
            closeModal();
            showNotification('Review sent to the artisan.', 'success');
            loadAllData(userId);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function contactArtisan(id) {
    const booking = userData.bookings.find(item => item.id === id || item.artisan_id === id);
    const artisanUserId = booking?.artisan_user_id || id;
    switchTab('messages');
    const conversation = userData.messages.find(item => item.user_id === artisanUserId || item.artisan_id === artisanUserId);
    if (conversation) openChat(artisanUserId);
    else showNotification('Start a conversation with this artisan from New Chat.', 'info');
}

function payBooking(bookingId) {
    const methods = userData.paymentMethods || [];
    if (!methods.length) {
        showNotification('Add a payment method in Settings before paying.', 'warning');
        switchTab('settings');
        return;
    }
    const options = methods.map(method => `<option value="${method.id}">${method.method_type.toUpperCase()} - ${method.account_label || method.account_reference}</option>`).join('');
    showModalWithForm('Confirm payment', `<form onsubmit="submitBookingPayment(event, ${bookingId})" class="form"><p>Payment will be recorded for this completed service.</p><div class="form-group"><label>Payment method</label><select id="paymentMethodForBooking" required>${options}</select></div><button type="submit" class="btn btn-primary"><i class="fa fa-lock"></i> Confirm payment</button></form>`);
}

function submitBookingPayment(event, bookingId) {
    event.preventDefault();
    const userId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/client/${userId}/bookings/${bookingId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_method_id: document.getElementById('paymentMethodForBooking').value })
    })
        .then(response => response.json())
        .then(result => {
            if (result.status !== 'success') throw new Error(result.message || 'Payment failed');
            closeModal();
            showNotification('Payment confirmed successfully.', 'success');
            loadAllData(userId);
        })
        .catch(error => showNotification(error.message, 'error'));
}

function sendMessageUI() {
    const messageInput = document.getElementById('messageInput');
    const artisanId = messageInput.dataset.artisanId;
    const userId = localStorage.getItem('userId');
    
    if (!artisanId) {
        showNotification('Please select a conversation first', 'warning');
        return;
    }
    
    sendMessage(userId, parseInt(artisanId));
}

function performGlobalSearch(event) {
    if (event && event.key && event.key !== 'Enter') return;
    
    const searchTerm = document.getElementById('globalSearch')?.value?.trim();
    if (!searchTerm) {
        showNotification('Please enter a search term', 'warning');
        return;
    }
    
    console.log('Searching for:', searchTerm);
    
    // Search from backend
    fetch(`http://localhost:5000/api/search/artisans?keyword=${encodeURIComponent(searchTerm)}`)
        .then(res => res.json())
        .then(data => {
            console.log('Search response:', data);
            if (data.status === 'success') {
                if (data.artisans.length === 0) {
                    showNotification(`No artisans found for "${searchTerm}"`, 'info');
                } else {
                    showNotification(`Found ${data.artisans.length} artisans`, 'success');
                }
                displayFilteredArtisans(data.artisans || []);
            } else {
                showNotification('Error searching artisans: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            showNotification('Error performing search', 'error');
        });
}

function searchByServiceType(serviceType) {
    if (!serviceType) {
        displayFilteredArtisans(userData.artisans || []);
        switchTab('search');
        return;
    }
    
    console.log('Searching for service type:', serviceType);
    
    // Fetch artisans for this specific service type from backend
    fetch(`http://localhost:5000/api/search/by-service/${encodeURIComponent(serviceType)}`)
        .then(res => res.json())
        .then(data => {
            console.log('Service search response:', data);
            if (data.status === 'success') {
                userData.artisans = data.artisans || [];
                if (data.total === 0) {
                    showNotification(`No artisans found for ${serviceType}`, 'info');
                } else {
                    showNotification(`Found ${data.total} artisans for ${serviceType}`, 'success');
                }
                displayFilteredArtisans(data.artisans || []);
            } else {
                showNotification('Error searching by service type: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            showNotification('Error searching artisans', 'error');
        });
}

function editProfile() {
    const escapeAttribute = value => String(value || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const form = `
        <form onsubmit="saveProfile(event)" class="form">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="profileName" value="${escapeAttribute(userData.user.name)}" required />
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="profileEmail" value="${escapeAttribute(userData.user.email)}" required />
            </div>
            <div class="form-group">
                <label>Cell phone number</label>
                <input type="tel" id="profilePhone" value="${escapeAttribute(userData.user.phone)}" />
            </div>
            <div class="form-group" id="emailVerificationGroup" style="display:none;">
                <label>Current password <small>(required when changing email)</small></label>
                <input type="password" id="profileCurrentPassword" autocomplete="current-password" />
            </div>
            <button type="submit" class="btn btn-primary">Save Profile</button>
        </form>
    `;
    showModalWithForm('Edit Profile', form);
    document.getElementById('profileEmail').addEventListener('input', event => {
        document.getElementById('emailVerificationGroup').style.display = event.target.value !== userData.user.email ? 'block' : 'none';
    });
}

function saveProfile(event) {
    event.preventDefault();
    const userId = localStorage.getItem("userId");
    const name = document.getElementById('profileName').value;
    const email = document.getElementById('profileEmail').value;
    const phone = document.getElementById('profilePhone').value;
    const password = document.getElementById('profileCurrentPassword')?.value;
    const payload = { name, email, phone };
    if (email !== userData.user.email) {
        if (!password) {
            showNotification('Enter your current password to change email.', 'warning');
            return;
        }
        payload.password = password;
    }
    
    fetch(`http://localhost:5000/api/user/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            userData.user.name = name;
            userData.user.email = email;
            userData.user.phone = phone;
            updateUserDisplay();
            displayProfile();
            saveUserDataToLocalStorage();
            closeModal();
            showNotification('Profile updated!', 'success');
            loadAllData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        showNotification('Failed to update profile', 'error');
    });
}

function changePhoto() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.onchange = () => {
        const file = input.files[0];
        if (!file) return;
        if (file.size > 2 * 1024 * 1024) {
            showNotification('Please choose an image smaller than 2 MB', 'warning');
            return;
        }
        const reader = new FileReader();
        reader.onload = () => {
            const userId = localStorage.getItem('userId');
            const formData = new FormData();
            formData.append('image', file);
            fetch(`http://localhost:5000/api/user/${userId}/profile-picture`, {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Upload failed');
                    userData.user.profile_picture = data.profile_picture;
                    const image = document.getElementById('userProfileImage');
                    if (image) image.src = data.profile_picture.startsWith('http') ? data.profile_picture : `http://localhost:5000${data.profile_picture}`;
                    updateProfileAvatars(data.profile_picture);
                    saveUserDataToLocalStorage();
                    showNotification('Profile photo updated!', 'success');
                })
                .catch(error => showNotification(error.message, 'error'));
        };
        reader.readAsDataURL(file);
    };
    input.click();
}

function callArtisan() {
    const artisanUserId = window.currentChatArtisanId;
    if (!artisanUserId) return showNotification('Select an artisan conversation first.', 'warning');
    fetch(`http://localhost:5000/api/user/${artisanUserId}`)
        .then(response => response.json())
        .then(result => {
            const phone = result.user?.phone;
            if (!phone) throw new Error('This artisan has not added a phone number.');
            window.location.href = `tel:${phone}`;
        })
        .catch(error => showNotification(error.message, 'warning'));
}

// ==================== MESSAGING FUNCTIONS ====================

// ==================== MESSAGING FUNCTIONS ====================

window.startNewChat = function() {
    console.log('✓ startNewChat called');
    console.log('  userData.favorites:', userData.favorites);
    console.log('  favorites length:', userData.favorites ? userData.favorites.length : 0);
    
    const preferredArtisans = userData.favorites || [];
    const otherArtisans = (userData.artisans || []).filter(artisan =>
        !preferredArtisans.some(favorite => favorite.id === artisan.id)
    );
    const chatArtisans = [...preferredArtisans, ...otherArtisans];

    if (chatArtisans.length === 0) {
        const form = `
            <div style="padding: 20px; text-align: center;">
                <i class="fa fa-users" style="font-size: 48px; color: #ddd; margin-bottom: 16px; display: block;"></i>
                <h4 style="margin: 0 0 12px 0; color: #333;">No Artisans Available</h4>
                <p style="margin: 0 0 20px 0; color: #999; font-size: 14px;">Load artisans from Find Artisans before starting a chat.</p>
                <button class="btn btn-primary" onclick="closeModal(); switchTab('search');" style="display: inline-block;">
                    <i class="fa fa-search"></i> Find Artisans
                </button>
            </div>
        `;
        showModalWithForm('Start New Chat', form);
        return;
    }

    console.log('  Showing favorites list...');
    
    let favoriteHTML = '<div style="display: grid; grid-template-columns: 1fr; gap: 12px; max-height: 400px; overflow-y: auto;">';
    
    chatArtisans.forEach((artisan) => {
        console.log('  Adding favorite artisan:', artisan.name);
        favoriteHTML += `
            <div style="display: flex; align-items: center; padding: 12px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.3s;" 
                 onmouseover="this.style.backgroundColor='#f0f8ff'; this.style.borderColor='#007bff';"
                 onmouseout="this.style.backgroundColor='white'; this.style.borderColor='#ddd';"
                 onclick="selectArtisanToChat(${artisan.id}, ${artisan.user_id || artisan.id}, '${artisan.name.replace(/'/g, "\\'")}')">
                <img src="${artisan.profile_picture || 'https://via.placeholder.com/50'}" alt="${artisan.name}" 
                     style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; margin-right: 12px;">
                <div>
                    <p style="margin: 0; font-weight: 600; color: #333;">${artisan.name}</p>
                    <p style="margin: 5px 0 0 0; font-size: 12px; color: #999;">${artisan.service_type}</p>
                    <p style="margin: 2px 0 0 0; font-size: 11px; color: #666;"><i class="fa fa-star"></i> ${(artisan.rating || 4.5).toFixed(1)}/5</p>
                </div>
            </div>
        `;
    });
    
    favoriteHTML += '</div>';

    const form = `
        <div style="padding: 10px;">
            <h4 style="margin: 0 0 15px 0; color: #333;">
                <i class="fa fa-comments" style="color: #2563eb; margin-right: 6px;"></i>
                Choose an Artisan (${chatArtisans.length})
            </h4>
            <p style="margin: 0 0 15px 0; color: #666; font-size: 13px;">Select an artisan to start chatting:</p>
            ${favoriteHTML}
        </div>
    `;

    showModalWithForm('Start New Chat', form);
};




window.selectArtisanToChat = function(artisanId, artisanUserId, artisanName) {
    console.log('✓ selectArtisanToChat called:', artisanId, artisanName);
    
    // Close modal
    closeModal();
    
    // Add to messages list if not already there
    let existingChat = userData.messages.find(m => (m.user_id || m.artisan_id) === artisanUserId);
    
    if (!existingChat) {
        existingChat = {
            artisan_id: artisanId,
            user_id: artisanUserId,
            artisan_name: artisanName,
            last_message: 'Chat started',
            timestamp: new Date().toISOString(),
            unread: false,
            messages: []
        };
        userData.messages.push(existingChat);
        console.log('  Created new chat');
    } else {
        console.log('  Using existing chat');
    }
    
    // Display messages and select this chat
    displayMessages();
    openChat(artisanUserId);
};


window.displayMessages = function() {
    const messagesList = document.getElementById('messagesList');
    const chatWindow = document.getElementById('chatWindow');
    if (!messagesList || !chatWindow) return;

    messagesList.style.display = 'flex';
    if (!userData.messages || userData.messages.length === 0) {
        messagesList.innerHTML = '<div class="message-empty-state"><i class="fa fa-comments-o"></i><h3>Your messages</h3><p>Start a conversation with an artisan.</p></div>';
        chatWindow.style.display = 'none';
        const emptyState = document.getElementById('emptyMessagesState');
        if (emptyState) emptyState.style.display = 'flex';
        return;
    }

    const emptyState = document.getElementById('emptyMessagesState');
    if (emptyState) emptyState.style.display = 'none';

    const formatTime = value => value ? new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
    messagesList.innerHTML = `<div class="messages-list-heading"><strong>Inbox</strong><span>${userData.messages.length}</span></div>` + userData.messages.map(chat => {
        const id = chat.user_id || chat.artisan_id;
        const name = chat.artisan_name || 'Artisan';
        const picture = chat.profile_picture || chat.avatar || 'https://via.placeholder.com/50';
        return `<button class="message-thread" type="button" onclick="openChat(${id}, event)">
            <img class="message-avatar" src="${picture}" alt="${name}" />
            <span class="message-preview"><strong>${name}</strong><span>${chat.last_message || 'Start a conversation'}</span><small>${formatTime(chat.last_message_time || chat.timestamp)}</small></span>
            ${chat.unread_count ? `<b class="unread-badge">${chat.unread_count}</b>` : ''}
        </button>`;
    }).join('');
    chatWindow.style.display = 'none';
};

window.openChat = function(artisanId, event) {
    if (event) event.stopPropagation();
    const chatWindow = document.getElementById('chatWindow');
    const chatMessages = document.getElementById('chatMessages');
    const chat = userData.messages.find(m => m.user_id === artisanId || m.artisan_id === artisanId);
    if (!chat) return;
    window.currentChatArtisanId = artisanId;
    const currentUserId = localStorage.getItem('userId');
    fetch(`http://localhost:5000/api/user/${currentUserId}/messages/${artisanId}`, { method: 'PUT' })
        .then(() => {
            chat.unread = false;
            chat.unread_count = 0;
            event?.currentTarget?.querySelector('.unread-badge')?.remove();
            loadNotifications(currentUserId);
        })
        .catch(error => console.error('Unable to mark conversation read:', error));
    const name = chat.artisan_name || 'Artisan';
    document.getElementById('chatWindowTitle').textContent = name;
    const chatProfileImage = document.getElementById('chatProfileImage');
    if (chatProfileImage) chatProfileImage.src = chat.profile_picture || chat.avatar || 'https://via.placeholder.com/40';
    const chatProfilePanel = document.getElementById('chatProfilePanel');
    if (chatProfilePanel) chatProfilePanel.innerHTML = `<i class="fa fa-user-circle"></i><h3>${name}</h3><p>Professional artisan on TradePro</p>`;
    document.querySelectorAll('.message-thread').forEach(thread => thread.classList.remove('active'));
    event?.currentTarget?.classList.add('active');
    const render = () => {
        chatMessages.innerHTML = chat.messages?.length ? chat.messages.map(msg => `<div class="message ${msg.sender === 'customer' ? 'sent' : 'received'}"><p>${escapeMessage(msg.content || '')}</p><small>${new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small></div>`).join('') : '<div class="chat-empty">No messages yet. Say hello.</div>';
        chatMessages.scrollTop = chatMessages.scrollHeight;
    };
    if (!chat.messages) {
        fetch(`http://localhost:5000/api/user/${localStorage.getItem('userId')}/messages/${artisanId}`)
            .then(response => response.json()).then(data => { chat.messages = data.messages || []; render(); });
    } else render();
    chatWindow.style.display = 'flex';
};

function escapeMessage(value) {
    return String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}

window.sendMessageUI = function() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    console.log('Sending message:', message, 'to artisan:', window.currentChatArtisanId);
    
    fetch(`http://localhost:5000/api/user/${localStorage.getItem('userId')}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipient_id: window.currentChatArtisanId, content: message })
    })
        .then(res => res.json())
        .then(data => {
            if (data.status !== 'success') throw new Error(data.message || 'Message failed');
            input.value = '';
            const chat = userData.messages.find(m => m.user_id === window.currentChatArtisanId || m.artisan_id === window.currentChatArtisanId);
            if (chat) {
                chat.messages = chat.messages || [];
                chat.messages.push({ content: message, sender: 'customer', timestamp: new Date().toISOString() });
                chat.last_message = message;
                openChat(window.currentChatArtisanId);
            }
            showNotification('Message sent!', 'success');
        })
        .catch(error => showNotification(error.message, 'error'));
};

window.closeChat = function() {
    document.getElementById('chatWindow').style.display = 'none';
    document.getElementById('messagesList').style.display = 'flex';
};

function viewInvoice(bookingId) {

    console.log('viewInvoice called with bookingId:', bookingId);
    console.log('userData.bookings:', userData.bookings);
    
    // Find the booking in userData.bookings
    const booking = userData.bookings.find(b => b.id === bookingId);
    console.log('Found booking:', booking);
    
    if (!booking) {
        showNotification('Invoice not found', 'error');
        return;
    }

    // Find artisan details
    const artisan = userData.artisans.find(a => a.id === booking.artisan_id);
    const artisanRate = artisan ? artisan.hourly_rate : 75;
    
    // Parse booking date
    const bookingDate = new Date(booking.date);
    const invoiceDate = bookingDate.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });

    // Calculate amounts (assuming 1 hour of service)
    const amount = artisanRate;
    const taxRate = 0.10; // 10% tax
    const tax = amount * taxRate;
    const total = amount + tax;

    // Generate invoice HTML
    const invoiceHTML = `
        <div style="font-family: Arial, sans-serif; color: #333; background: white; padding: 30px; border-radius: 8px;">
            <div style="text-align: center; border-bottom: 2px solid #007bff; padding-bottom: 20px; margin-bottom: 30px;">
                <h1 style="margin: 0; color: #007bff;">INVOICE</h1>
                <p style="margin: 10px 0 5px 0; color: #666;"><strong>Invoice #:</strong> INV-${String(bookingId).padStart(5, '0')}</p>
                <p style="margin: 5px 0; color: #666;"><strong>Date:</strong> ${invoiceDate}</p>
                <p style="margin: 5px 0; color: #28a745;"><strong>Status:</strong> PAID</p>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 30px;">
                <div>
                    <h4 style="color: #007bff; margin: 0 0 10px 0; font-size: 12px; text-transform: uppercase;">FROM</h4>
                    <p style="margin: 5px 0;"><strong>TradePro Services</strong></p>
                    <p style="margin: 5px 0; font-size: 12px; color: #666;">Professional Service Marketplace</p>
                    <p style="margin: 5px 0; font-size: 12px; color: #666;">support@tradepro.com</p>
                </div>
                <div>
                    <h4 style="color: #007bff; margin: 0 0 10px 0; font-size: 12px; text-transform: uppercase;">BILL TO</h4>
                    <p style="margin: 5px 0;"><strong>${userData.user.name}</strong></p>
                    <p style="margin: 5px 0; font-size: 12px; color: #666;">${userData.user.email}</p>
                    <p style="margin: 5px 0; font-size: 12px; color: #666;">${userData.user.phone || 'N/A'}</p>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <thead>
                    <tr style="background: #f5f5f5; border-bottom: 2px solid #ddd;">
                        <th style="padding: 12px; text-align: left; font-weight: 600; font-size: 12px;">Description</th>
                        <th style="padding: 12px; text-align: left; font-weight: 600; font-size: 12px;">Provider</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600; font-size: 12px;">Rate</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600; font-size: 12px;">Qty</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600; font-size: 12px;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="padding: 12px; font-size: 13px;">${booking.service_name}</td>
                        <td style="padding: 12px; font-size: 13px;">${booking.artisan_name}</td>
                        <td style="padding: 12px; text-align: right; font-size: 13px;">$${artisanRate.toFixed(2)}/hr</td>
                        <td style="padding: 12px; text-align: right; font-size: 13px;">1 hr</td>
                        <td style="padding: 12px; text-align: right; font-size: 13px;">$${amount.toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>

            <div style="text-align: right; margin-bottom: 30px;">
                <p style="margin: 8px 0; font-size: 13px;"><strong>Subtotal:</strong> $${amount.toFixed(2)}</p>
                <p style="margin: 8px 0; font-size: 13px;"><strong>Tax (10%):</strong> $${tax.toFixed(2)}</p>
                <p style="margin: 8px 0; font-size: 16px; color: #007bff; border-top: 2px solid #007bff; padding-top: 10px;"><strong>Total:</strong> $${total.toFixed(2)}</p>
            </div>

            <div style="text-align: center; color: #999; font-size: 11px; border-top: 1px solid #ddd; padding-top: 20px; margin-top: 40px;">
                <p>Thank you for using TradePro Services!</p>
                <p>© 2025 TradePro. All rights reserved.</p>
            </div>

            <center style="margin-top: 20px;">
                <button onclick="window.print()" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 13px;">Print Invoice</button>
            </center>
        </div>
    `;

    // Show invoice in modal
    showModalWithForm('Invoice #INV-' + String(bookingId).padStart(5, '0'), invoiceHTML);
}

function changePassword() {
    const form = `
        <form onsubmit="savePassword(event)" class="form">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" required />
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" required />
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
    `;
    showModalWithForm('Change Password', form);
}

function savePassword(event) {
    event.preventDefault();
    const userId = localStorage.getItem('userId');
    const fields = event.target.querySelectorAll('input[type="password"]');
    const currentPassword = fields[0]?.value;
    const newPassword = fields[1]?.value;
    const confirmPassword = fields[2]?.value;
    if (newPassword !== confirmPassword) {
        showNotification('Passwords do not match.', 'error');
        return;
    }
    fetch(`http://localhost:5000/api/user/${userId}/password`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })
    })
        .then(response => response.json())
        .then(result => {
            if (result.status !== 'success') throw new Error(result.message || 'Password update failed');
            closeModal();
            showNotification('Password updated!', 'success');
        })
        .catch(error => showNotification(error.message, 'error'));
}

function logout() {
    if (confirm('Logout?')) {
        // Stop message polling
        if (userData.messagePollingInterval) {
            clearInterval(userData.messagePollingInterval);
        }
        
        localStorage.removeItem("user");
        localStorage.removeItem("userId");
        localStorage.removeItem("isArtisan");
        window.location.href = "login.html";
    }
}

function setupClientSettingsActions() {
    const paymentForm = document.getElementById('paymentMethodForm');
    if (paymentForm) {
        paymentForm.addEventListener('submit', event => {
            event.preventDefault();
            const userId = localStorage.getItem('userId');
            fetch(`http://localhost:5000/api/client/${userId}/payment-methods`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    method_type: document.getElementById('paymentMethodType').value,
                    account_label: document.getElementById('paymentAccountLabel').value,
                    account_reference: document.getElementById('paymentAccountReference').value
                })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Unable to save payment method');
                    userData.paymentMethods = data.payment_methods || [];
                    displayPaymentMethods();
                    paymentForm.reset();
                    showNotification('Payment method saved.', 'success');
                })
                .catch(error => showNotification(error.message, 'error'));
        });
    }

    const settingsForm = document.getElementById('clientSettingsForm');
    if (settingsForm) {
        settingsForm.addEventListener('submit', event => {
            event.preventDefault();
            const userId = localStorage.getItem('userId');
            const settings = {
                booking_notifications: document.getElementById('bookingNotifications').checked,
                message_notifications: document.getElementById('messageNotifications').checked,
                profile_visibility: document.getElementById('profileVisibility').checked
            };
            fetch(`http://localhost:5000/api/client/${userId}/settings`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(settings)
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Unable to save settings');
                    userData.settings = data.settings;
                    showNotification('Settings saved.', 'success');
                })
                .catch(error => showNotification(error.message, 'error'));
        });
    }
}

// ==================== UI FUNCTIONS ====================

function switchTab(tabName) {
    console.log(`🔄 switchTab('${tabName}') called`);
    const searchTabWasActive = document.getElementById('search')?.classList.contains('active');
    
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
        console.log(`✓ Tab '${tabName}' activated`);
    } else {
        console.error(`✗ Tab '${tabName}' not found!`);
    }
    
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    
    const activeLink = document.querySelector(`a[href="#${tabName}"]`);
    if (activeLink) activeLink.classList.add('active');
    
    const titleMap = {
        'home': 'Home',
        'search': 'Find Artisans',
        'bookings': 'My Bookings',
        'favorites': 'Favorites',
        'history': 'Service History',
        'payments': 'Payments',
        'messages': 'Messages',
        'profile': 'My Profile',
        'settings': 'Settings'
    };
    document.getElementById('pageTitle').textContent = titleMap[tabName] || 'Dashboard';
    
    // Update URL hash
    window.history.pushState(null, null, `#${tabName}`);
    
    // Load artisans when switching to search tab
    if (tabName === 'search' && !searchTabWasActive) {
        console.log("📺 Search tab activated - loading artisans from API");
        
        // Reset filter form to show all
        document.getElementById('serviceFilter').value = '';
        document.getElementById('locationFilter').value = '';
        document.getElementById('ratingFilter').value = '';
        document.getElementById('priceMin').value = '';
        document.getElementById('priceMax').value = '';
        
        // Load and display all artisans
        loadArtisansForSearch();
    }

    if (tabName === 'history') {
        displayHistory();
    }

    if (tabName === 'favorites') {
        displayFavorites();
    }

    if (tabName === 'payments') {
        displayPayments();
    }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

function toggleNotifications() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.toggle('active');
    if (dropdown.classList.contains('active')) {
        const userId = localStorage.getItem('userId');
        fetch(`http://localhost:5000/api/user/${userId}/notifications`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: '{}' })
            .then(() => loadNotifications(userId));
    }
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
}

function showModal(title, content) {
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle"></h2>
                <div id="modalBody"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    modal.style.display = 'block';
}

function showModalWithForm(title, formHtml) {
    showModal(title, formHtml);
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) modal.style.display = 'none';
}

function showNotification(message, type = 'info') {
    let container = document.getElementById('notificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notificationContainer';
        document.body.appendChild(container);
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove();">&times;</button>
        </div>
    `;
    
    container.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}

// ==================== INITIALIZATION ====================

document.addEventListener('DOMContentLoaded', function() {
    setupClientSettingsActions();
    initializeDashboard();
    
    // Load the correct tab based on URL hash
    const hash = window.location.hash.substring(1) || 'home';
    switchTab(hash);
    
    // Handle hash changes (back/forward buttons)
    window.addEventListener('hashchange', function() {
        const newHash = window.location.hash.substring(1) || 'home';
        switchTab(newHash);
    });
});

// Add modal styles
const style = document.createElement('style');
style.textContent = `
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 30px;
        border-radius: 8px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover { color: #000; }
    #notificationContainer {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 3000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .notification {
        background-color: white;
        padding: 16px;
        border-radius: 8px;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        border-left: 4px solid;
    }
    .notification-success { border-left-color: #10b981; }
    .notification-error { border-left-color: #ef4444; }
    .notification-info { border-left-color: #3b82f6; }
    .notification-warning { border-left-color: #f59e0b; }
`;
document.head.appendChild(style);
