// USER DASHBOARD FUNCTIONALITY

// ==================== LOAD USER DATA FROM LOCALSTORAGE ====================
// Initialize with empty data - will be populated from API/database
let userData = {
    name: '',
    email: '',
    phone: ''
};

// Load user data from localStorage on page load
function loadUserData() {
    try {
        const storedUser = localStorage.getItem("user");
        const userId = localStorage.getItem("userId");
        const isArtisan = localStorage.getItem("isArtisan");
        
        console.log("Loading user data...");
        console.log("Stored user:", storedUser);
        console.log("User ID:", userId);
        console.log("Is artisan:", isArtisan);
        
        // Check if user is logged in and is NOT an artisan (is a client)
        if (!storedUser || !userId || (isArtisan === "1" || isArtisan === "true")) {
            console.warn("Not logged in as client, redirecting to login");
            window.location.href = "login.html";
            return;
        }
        
        const user = JSON.parse(storedUser);
        console.log("Parsed user:", user);
        
        // Update userData with actual user data from DB
        userData.name = user.name || "User";
        userData.email = user.email || "";
        userData.phone = user.phone || "";
        
        console.log("Updated userData:", userData);
        
        // Update page elements with user name immediately
        updateUserDisplay();
        
        // Initialize empty states while data loads
        populateClientBookings([]);
        populateUpcomingServices([]);
        populateRecentArtisans([]);
        populateArtisanSearch([]);
        
        // Fetch user-specific data from database
        fetchUserData(userId);
        
    } catch (error) {
        console.error("Error loading user data:", error);
        // If there's an error, redirect to login
        window.location.href = "login.html";
    }
}

// Update all places where user name is displayed
function updateUserDisplay() {
    console.log("Updating user display with name:", userData.name);
    
    // Update topbar user name
    const topbarUserName = document.getElementById("topbarUserName");
    if (topbarUserName) {
        topbarUserName.textContent = userData.name;
        console.log("Updated topbar name to:", userData.name);
    } else {
        console.warn("topbarUserName element not found");
    }
    
    // Update dashboard welcome message
    const dashboardUserName = document.getElementById("dashboardUserName");
    if (dashboardUserName) {
        dashboardUserName.textContent = userData.name;
        console.log("Updated dashboard name to:", userData.name);
    } else {
        console.warn("dashboardUserName element not found");
    }
}

// Helper function to fetch with timeout
function fetchWithTimeout(url, timeout = 5000) {
    return Promise.race([
        fetch(url),
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error('API request timeout')), timeout)
        )
    ]);
}

// Fetch user-specific data from API
function fetchUserData(userId) {
    console.log("Fetching user data for user ID:", userId);
    
    // Fetch user profile data
    fetchWithTimeout(`http://localhost:5000/api/user/${userId}`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("User API Response:", data);
            
            if (data.status === "success" && data.user) {
                const user = data.user;
                
                // Update with DB info
                userData.name = user.name;
                userData.email = user.email;
                userData.phone = user.phone;
                
                console.log("Updated userData from API:", userData);
                updateUserDisplay();
            }
        })
        .catch(err => {
            console.error("Error fetching user data:", err);
            populateClientBookings([]);
        });
    
    // Fetch client bookings
    fetchWithTimeout(`http://localhost:5000/api/client/${userId}/bookings`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("Client Bookings API Response:", data);
            if (data.status === "success") {
                populateClientBookings(data.bookings || []);
            } else {
                populateClientBookings([]);
            }
        })
        .catch(err => {
            console.error("Error fetching client bookings:", err);
            populateClientBookings([]);
        });
}

// Populate client bookings from API
function populateClientBookings(bookings) {
    console.log("Populating client bookings:", bookings);
    
    // Update bookings list for all bookings tab (if it exists)
    const bookingsContainer = document.querySelector('.bookings-grid') || document.querySelector('.booking-list');
    if (bookingsContainer) {
        if (!bookings || bookings.length === 0) {
            bookingsContainer.innerHTML = '<div class="empty-state"><p>No bookings yet. <a href="find-artisans.html">Find an artisan</a> to get started!</p></div>';
        } else {
            let bookingsHTML = '';
            bookings.forEach((booking) => {
                const bookingDate = new Date(booking.date);
                const formattedDate = bookingDate.toLocaleDateString() + ' ' + booking.time;
                
                const statusClass = `badge-${booking.status === 'pending' ? 'warning' : booking.status === 'completed' ? 'success' : 'info'}`;
                
                bookingsHTML += `
                    <div class="booking-card">
                        <div class="booking-card-header">
                            <h3>${booking.service_name}</h3>
                            <span class="badge ${statusClass}">${booking.status}</span>
                        </div>
                        <div class="booking-card-body">
                            <div class="booking-info">
                                <div class="info-item">
                                    <span class="label">Artisan</span>
                                    <span>${booking.artisan_name}</span>
                                </div>
                                <div class="info-item">
                                    <span class="label">Date & Time</span>
                                    <span>${formattedDate}</span>
                                </div>
                            </div>
                        </div>
                        <div class="booking-card-footer">
                            <button class="btn btn-outline" onclick="viewClientBookingDetails(${booking.id})">View Details</button>
                            <button class="btn btn-secondary" onclick="cancelClientBooking(${booking.id})">Cancel</button>
                        </div>
                    </div>
                `;
            });
            bookingsContainer.innerHTML = bookingsHTML;
        }
    }
    
    // Update upcoming bookings in overview (show only first 2)
    const upcomingBookingsList = document.querySelector('.upcoming-bookings-list');
    if (upcomingBookingsList && bookings && bookings.length > 0) {
        const recentBookings = bookings.slice(0, 2);
        let upcomingHTML = '';
        
        recentBookings.forEach((booking) => {
            const bookingDate = new Date(booking.date);
            const today = new Date();
            
            let dateText = 'Today';
            if (bookingDate.toDateString() === new Date(today.getTime() + 86400000).toDateString()) {
                dateText = 'Tomorrow';
            } else {
                dateText = bookingDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            }
            
            upcomingHTML += `
                <div class="booking-item">
                    <div class="booking-time">
                        <span class="date">${dateText}</span>
                        <span class="time">${booking.time}</span>
                    </div>
                    <div class="booking-details">
                        <h4>${booking.service_name}</h4>
                        <p>${booking.artisan_name}</p>
                    </div>
                    <div class="booking-actions">
                        <button class="btn btn-sm btn-secondary" onclick="viewClientBookingDetails(${booking.id})">View</button>
                    </div>
                </div>
            `;
        });
        
        upcomingBookingsList.innerHTML = upcomingHTML;
    }
    
    // Update user data bookings array (for compatibility with existing functions)
    userData.bookings = bookings.map(b => ({
        id: b.id,
        artisan: b.artisan_name,
        service: b.service_name,
        date: b.date,
        status: b.status,
        price: b.price || 'N/A'
    }));
}

// Populate upcoming services in homepage overview
function populateUpcomingServices(bookings) {
    console.log("Populating upcoming services:", bookings);
    
    const servicesContainer = document.getElementById('upcomingServicesOverview');
    if (!servicesContainer) return;
    
    if (!bookings || bookings.length === 0) {
        servicesContainer.innerHTML = '<div style=\"padding: 20px; text-align: center; color: #999;\">No upcoming services. <a href=\"#search\" onclick=\"switchTab(\\'search\\')\">Find an artisan</a></div>';
        return;
    }
    
    let html = '';
    bookings.slice(0, 2).forEach(booking => {
        const bookingDate = new Date(booking.date);
        const today = new Date();
        let dateText = 'Today';
        if (bookingDate.toDateString() === new Date(today.getTime() + 86400000).toDateString()) {
            dateText = 'Tomorrow';
        }
        
        html += `
            <div class=\"service-preview\">
                <div class=\"service-time\">
                    <span class=\"date\">${dateText}</span>
                    <span class=\"time\">${booking.time || '10:00 AM'}</span>
                </div>
                <div class=\"service-info\">
                    <h4>${booking.service_name}</h4>
                    <p><strong>${booking.artisan_name}</strong></p>
                </div>
                <div class=\"service-status\">
                    <span class=\"badge ${booking.status === 'confirmed' ? 'badge-success' : 'badge-warning'}\">${booking.status}</span>
                </div>
            </div>
        `;
    });
    
    servicesContainer.innerHTML = html;
}

// Populate recent artisans preview
function populateRecentArtisans(artisans) {
    console.log("Populating recent artisans:", artisans);
    
    const container = document.getElementById('recentArtisansPreview');
    if (!container) return;
    
    if (!artisans || artisans.length === 0) {
        container.innerHTML = '<div style=\"padding: 20px; text-align: center; color: #999;\">No recent artisans. <a href=\"#search\" onclick=\"switchTab(\\'search\\')\">Browse artisans</a></div>';
        return;
    }
    
    let html = '';
    artisans.slice(0, 2).forEach(artisan => {
        html += `
            <div class=\"artisan-preview\">
                <img src=\"https://via.placeholder.com/50\" alt=\"${artisan.name}\" />
                <div class=\"artisan-info\">
                    <h4>${artisan.name}</h4>
                    <p>${artisan.service || 'Professional'}</p>
                    <div class=\"rating\">
                        <span class=\"stars\"><i class=\"fa fa-star\"></i> ${artisan.rating || 0}</span>
                    </div>
                </div>
                <button class=\"btn btn-sm btn-primary\" onclick=\"bookArtisan(${artisan.id})\">Book</button>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Populate artisan search grid
function populateArtisanSearch(artisans) {
    console.log("Populating artisan search:", artisans);
    
    const grid = document.getElementById('searchArtisansGrid');
    if (!grid) return;
    
    if (!artisans || artisans.length === 0) {
        grid.innerHTML = '<div style=\"grid-column: 1 / -1; padding: 40px; text-align: center; color: #999;\">No artisans found. Use the search filters to find professionals in your area.</div>';
        return;
    }
    
    let html = '';
    artisans.forEach(artisan => {
        html += `
            <div class=\"artisan-card\">
                <div class=\"artisan-header\">
                    <img src=\"https://via.placeholder.com/150\" alt=\"${artisan.name}\" />
                    <button class=\"favorite-btn\" onclick=\"toggleFavorite(this)\">
                        <i class=\"fa fa-heart-o\"></i>
                    </button>
                </div>
                <div class=\"artisan-details\">
                    <h3>${artisan.name}</h3>
                    <p class=\"service-type\">${artisan.service || 'Professional'}</p>
                    <div class=\"rating-bar\">
                        <span class=\"stars\"><i class=\"fa fa-star\"></i> ${artisan.rating || 0}/5</span>
                    </div>
                    <div class=\"price\">$${artisan.hourly_rate || 0}/hour</div>
                </div>
                <div class=\"artisan-footer\">
                    <button class=\"btn btn-secondary\" onclick=\"bookArtisan(${artisan.id})\">Book Now</button>
                </div>
            </div>
        `;
    });
    
    grid.innerHTML = html;
}

// Load user data when page loads
window.addEventListener('load', function() {
    loadUserData();
});

// Also try to load on DOMContentLoaded
document.addEventListener("DOMContentLoaded", function() {
    // Give a small delay to ensure DOM is ready
    setTimeout(loadUserData, 100);
});

// Tab switching
function switchTab(tabName) {
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));

    // Show selected tab
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Update nav links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    
    const activeLink = document.querySelector(`a[href="#${tabName}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // Update page title
    const titleMap = {
        'home': 'Home',
        'search': 'Find Artisans',
        'bookings': 'My Bookings',
        'favorites': 'Favorites',
        'history': 'Service History',
        'payments': 'Payments & Invoices',
        'messages': 'Messages',
        'profile': 'My Profile',
        'settings': 'Settings'
    };
    document.getElementById('pageTitle').textContent = titleMap[tabName] || 'Home';
}

// Sidebar toggle
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    
    sidebar.classList.toggle('active');
    mainContent.classList.toggle('sidebar-collapsed');
}

// Close sidebar on mobile when clicking a link
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                const sidebar = document.getElementById('sidebar');
                sidebar.classList.remove('active');
            }
        });
    });
});

// Dropdown menus
function toggleNotifications() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.toggle('active');
    
    // Close other dropdowns
    document.getElementById('userDropdown').classList.remove('active');
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
    
    // Close other dropdowns
    document.getElementById('notificationDropdown').classList.remove('active');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('.notifications') && 
        !event.target.closest('.notification-dropdown')) {
        document.getElementById('notificationDropdown').classList.remove('active');
    }
    
    if (!event.target.closest('.user-menu')) {
        document.getElementById('userDropdown').classList.remove('active');
    }
});

// ============ SEARCH FUNCTIONS ============
function performGlobalSearch(event) {
    if (event && event.type === 'keypress' && event.key !== 'Enter') {
        return;
    }
    
    const searchTerm = document.getElementById('globalSearch').value;
    switchTab('search');
    showNotification(`Searching for: "${searchTerm || 'all services'}"`, 'info');
}

function applyFilters() {
    const service = document.getElementById('serviceFilter').value;
    const location = document.getElementById('locationFilter').value;
    const rating = document.getElementById('ratingFilter').value;
    const price = document.getElementById('priceFilter').value;
    
    let filterSummary = 'Filters applied:';
    if (service) filterSummary += ` ${service},`;
    if (location) filterSummary += ` ${location},`;
    if (rating) filterSummary += ` ${rating}+ stars,`;
    if (price) filterSummary += ` ${price}`;
    
    // Reorder artisan cards to show subscribed ones first
    reorderArtisansBySubscription();
    
    showNotification(filterSummary.replace(/,$/, '') + ' - Showing subscribed artisans first', 'success');
}

function reorderArtisansBySubscription() {
    const grid = document.querySelector('.artisans-grid');
    if (!grid) return;
    
    const cards = Array.from(grid.querySelectorAll('.artisan-card'));
    
    // Sort cards: subscribed artisans first
    cards.sort((a, b) => {
        const aSubscribed = userData.subscriptions.length > 0;
        const bSubscribed = userData.subscriptions.length > 0;
        
        // Get artisan IDs from button IDs
        const aBtn = a.querySelector('.subscribe-btn');
        const bBtn = b.querySelector('.subscribe-btn');
        
        const aId = aBtn ? aBtn.id.replace('sub-btn-', '') : '';
        const bId = bBtn ? bBtn.id.replace('sub-btn-', '') : '';
        
        const aIsSubscribed = userData.subscriptions.includes(aId);
        const bIsSubscribed = userData.subscriptions.includes(bId);
        
        // Subscribed first
        if (aIsSubscribed && !bIsSubscribed) return -1;
        if (!aIsSubscribed && bIsSubscribed) return 1;
        return 0;
    });
    
    // Re-append cards in sorted order
    cards.forEach(card => grid.appendChild(card));
}

// ============ ARTISAN FUNCTIONS ============
function viewProfile(artisanId) {
    const profileContent = `
        <div style="text-align: left;">
            <h3 style="margin-bottom: 12px;">Full Profile Details</h3>
            <p><strong>Experience:</strong> 3+ years in electrical work</p>
            <p><strong>Availability:</strong> Mon-Sat, 9 AM - 5 PM</p>
            <p><strong>Service Area:</strong> 15 miles radius</p>
            <p><strong>Certifications:</strong> Licensed, Insured, CPR Certified</p>
            <p><strong>Languages:</strong> English, Spanish</p>
            <p style="margin-top: 16px;"><button class="btn btn-primary" onclick="bookArtisan('${artisanId}')">Book Now</button></p>
        </div>
    `;
    showModalWithForm(`${artisanId.charAt(0).toUpperCase() + artisanId.slice(1)}'s Profile`, profileContent);
}

function bookArtisan(artisanId) {
    const bookingForm = `
        <form onsubmit="submitBooking('${artisanId}', event)" class="form">
            <div class="form-group">
                <label>Service Date</label>
                <input type="date" required />
            </div>
            <div class="form-group">
                <label>Service Time</label>
                <input type="time" required />
            </div>
            <div class="form-group">
                <label>Location</label>
                <input type="text" placeholder="Service address" required />
            </div>
            <div class="form-group">
                <label>Service Description</label>
                <textarea placeholder="Describe what you need..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Confirm Booking</button>
        </form>
    `;
    showModalWithForm('Book Appointment', bookingForm);
}

function submitBooking(artisanId, event) {
    event.preventDefault();
    closeModal();
    showNotification('Booking request sent! Artisan will confirm soon.', 'success');
}

function toggleFavorite(element) {
    const btn = element.closest('.favorite-btn');
    const icon = btn.querySelector('i');
    
    if (btn.classList.contains('active')) {
        btn.classList.remove('active');
        icon.classList.remove('fa-heart');
        icon.classList.add('fa-heart-o');
        showNotification('Removed from favorites', 'info');
    } else {
        btn.classList.add('active');
        icon.classList.remove('fa-heart-o');
        icon.classList.add('fa-heart');
        showNotification('Added to favorites!', 'success');
    }
}

// ============ BOOKINGS FUNCTIONS ============
function filterBookings(filter) {
    // Update active filter button
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
    
    const filterText = {
        'all': 'all bookings',
        'upcoming': 'upcoming bookings',
        'completed': 'completed services',
        'cancelled': 'cancelled bookings'
    };
    
    showNotification(`Showing ${filterText[filter] || filter}`, 'info');
}

function cancelBooking(id) {
    const booking = userData.bookings.find(b => b.id === id);
    if (booking && confirm(`Cancel booking with ${booking.artisan}?`)) {
        booking.status = 'Cancelled';
        showNotification(`Booking cancelled. A cancellation fee may apply.`, 'warning');
    }
}

function contactArtisan(artisanId) {
    switchTab('messages');
    showNotification(`Opening chat with ${artisanId}...`, 'info');
}

function viewBookingDetails(id) {
    const booking = userData.bookings.find(b => b.id === id);
    if (booking) {
        const details = `
            <div style="text-align: left;">
                <p><strong>Artisan:</strong> ${booking.artisan}</p>
                <p><strong>Service:</strong> ${booking.service}</p>
                <p><strong>Date & Time:</strong> ${booking.date}</p>
                <p><strong>Location:</strong> ${booking.location}</p>
                <p><strong>Price:</strong> ${booking.price}</p>
                <p><strong>Status:</strong> ${booking.status}</p>
            </div>
        `;
        showModalWithForm('Booking Details', details);
    }
}

// ============ FAVORITES FUNCTIONS ============
function removeFavorite(element) {
    const card = element.closest('.favorite-card');
    const artisanName = card.querySelector('h3').textContent;
    
    if (confirm(`Remove ${artisanName} from favorites?`)) {
        card.style.transition = 'opacity 0.3s ease';
        card.style.opacity = '0';
        setTimeout(() => {
            card.remove();
            showNotification(`${artisanName} removed from favorites`, 'success');
        }, 300);
    }
}

// ============ HISTORY FUNCTIONS ============
function leaveReview(bookingId) {
    const reviewForm = `
        <form onsubmit="submitReview(event)" class="form">
            <div class="form-group">
                <label>Rating</label>
                <select required>
                    <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                    <option value="4">⭐⭐⭐⭐ Good</option>
                    <option value="3">⭐⭐⭐ Average</option>
                    <option value="2">⭐⭐ Poor</option>
                    <option value="1">⭐ Very Poor</option>
                </select>
            </div>
            <div class="form-group">
                <label>Your Review</label>
                <textarea placeholder="Share your experience with this artisan..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Post Review</button>
        </form>
    `;
    showModalWithForm('Leave a Review', reviewForm);
}

function submitReview(event) {
    event.preventDefault();
    closeModal();
    showNotification('Thank you! Your review has been posted.', 'success');
}

function viewReview(bookingId) {
    const reviewContent = `
        <div style="text-align: left;">
            <h4>Your Review</h4>
            <p style="color: #f59e0b; margin-bottom: 8px;">⭐⭐⭐⭐⭐ Excellent</p>
            <p>"John did an amazing job! Very professional and completed the work quickly. Will book again!"</p>
            <p style="margin-top: 12px; font-size: 12px; color: #6b7280;">Posted 2 days ago</p>
        </div>
    `;
    showModalWithForm('Your Review', reviewContent);
}

function bookAgain(artisanId) {
    const bookingForm = `
        <form onsubmit="submitBooking('${artisanId}', event)" class="form">
            <div class="form-group">
                <label>Service Date</label>
                <input type="date" required />
            </div>
            <div class="form-group">
                <label>Service Time</label>
                <input type="time" required />
            </div>
            <div class="form-group">
                <label>Service Description</label>
                <textarea placeholder="Describe what you need..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Confirm Booking</button>
        </form>
    `;
    showModalWithForm('Book Again', bookingForm);
}

// ============ PAYMENTS FUNCTIONS ============
function viewInvoice(invoiceId) {
    const invoiceContent = `
        <div style="text-align: left; font-family: monospace;">
            <h4>Invoice #INV-2024-${invoiceId}</h4>
            <hr style="margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                <span>Service:</span>
                <span>Plumbing Repair</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                <span>Date:</span>
                <span>Jan 15, 2024</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                <span>Artisan:</span>
                <span>John Smith</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin: 8px 0;">
                <span>Duration:</span>
                <span>2 hours</span>
            </div>
            <hr style="margin: 12px 0;">
            <div style="display: flex; justify-content: space-between; margin: 8px 0; font-weight: bold;">
                <span>Total Amount:</span>
                <span>$120.00</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin: 8px 0; color: #10b981;">
                <span>Status:</span>
                <span>Paid ✓</span>
            </div>
            <button onclick="downloadInvoicePDF('INV-2024-${invoiceId}')" class="btn btn-primary" style="margin-top: 16px; width: 100%;">
                <i class="fa fa-download"></i> Download PDF
            </button>
        </div>
    `;
    showModalWithForm('Invoice Details', invoiceContent);
}

function downloadInvoicePDF(invoiceId) {
    closeModal();
    showNotification(`Invoice ${invoiceId} downloaded successfully!`, 'success');
}

// ============ MESSAGES FUNCTIONS ============
function openChat(artisanName) {
    const chatHeader = document.querySelector('.chat-header h3');
    if (chatHeader) {
        chatHeader.textContent = artisanName.charAt(0).toUpperCase() + artisanName.slice(1);
    }
    showNotification(`Opening chat with ${artisanName}`, 'info');
}

function callArtisan() {
    showNotification('Initiating call...', 'info');
}

// ============ PROFILE FUNCTIONS ============
function editProfile() {
    const profileForm = `
        <form onsubmit="saveProfileChanges(event)" class="form">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" value="${userData.name}" required />
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" value="${userData.email}" required />
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" value="${userData.phone}" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    `;
    showModalWithForm('Edit Profile', profileForm);
}

function saveProfileChanges(event) {
    event.preventDefault();
    closeModal();
    showNotification('Profile updated successfully!', 'success');
}

function changePhoto() {
    const photoForm = `
        <form onsubmit="uploadProfilePhoto(event)" class="form">
            <div class="form-group">
                <label>Profile Photo</label>
                <input type="file" accept="image/*" required />
            </div>
            <button type="submit" class="btn btn-primary">Upload Photo</button>
        </form>
    `;
    showModalWithForm('Change Profile Photo', photoForm);
}

function uploadProfilePhoto(event) {
    event.preventDefault();
    closeModal();
    showNotification('Profile photo updated!', 'success');
}

function editAddress(type) {
    const addressForm = `
        <form onsubmit="saveAddress('${type}', event)" class="form">
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" placeholder="123 Main St" required />
            </div>
            <div class="form-group">
                <label>City</label>
                <input type="text" placeholder="New York" required />
            </div>
            <div class="form-group">
                <label>State/Province</label>
                <input type="text" placeholder="NY" required />
            </div>
            <div class="form-group">
                <label>Postal Code</label>
                <input type="text" placeholder="10001" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Address</button>
        </form>
    `;
    showModalWithForm(`Edit ${type.charAt(0).toUpperCase() + type.slice(1)} Address`, addressForm);
}

function saveAddress(type, event) {
    event.preventDefault();
    closeModal();
    showNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} address updated!`, 'success');
}

function addAddress() {
    const addressForm = `
        <form onsubmit="saveNewAddress(event)" class="form">
            <div class="form-group">
                <label>Address Type</label>
                <select required>
                    <option value="home">Home</option>
                    <option value="work">Work</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" placeholder="123 Main St" required />
            </div>
            <div class="form-group">
                <label>City</label>
                <input type="text" placeholder="New York" required />
            </div>
            <div class="form-group">
                <label>State/Province</label>
                <input type="text" placeholder="NY" required />
            </div>
            <div class="form-group">
                <label>Postal Code</label>
                <input type="text" placeholder="10001" required />
            </div>
            <button type="submit" class="btn btn-primary">Add Address</button>
        </form>
    `;
    showModalWithForm('Add New Address', addressForm);
}

function saveNewAddress(event) {
    event.preventDefault();
    closeModal();
    showNotification('New address added successfully!', 'success');
}

// ============ SETTINGS FUNCTIONS ============
function changeEmail() {
    const emailForm = `
        <form onsubmit="updateEmail(event)" class="form">
            <div class="form-group">
                <label>Current Email</label>
                <input type="email" value="${userData.email}" disabled />
            </div>
            <div class="form-group">
                <label>New Email</label>
                <input type="email" placeholder="newemail@example.com" required />
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" placeholder="Enter your password" required />
            </div>
            <button type="submit" class="btn btn-primary">Change Email</button>
        </form>
    `;
    showModalWithForm('Change Email Address', emailForm);
}

function updateEmail(event) {
    event.preventDefault();
    closeModal();
    showNotification('Email change confirmed! Check your new email for verification.', 'success');
}

function changePassword() {
    const passwordForm = `
        <form onsubmit="updatePassword(event)" class="form">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" placeholder="Enter current password" required />
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" placeholder="Enter new password" required />
            </div>
            <div class="form-group">
                <label>Confirm New Password</label>
                <input type="password" placeholder="Confirm new password" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
    `;
    showModalWithForm('Change Password', passwordForm);
}

function updatePassword(event) {
    event.preventDefault();
    closeModal();
    showNotification('Password updated successfully!', 'success');
}

function enableTwoFactor() {
    const twoFactorForm = `
        <form onsubmit="setupTwoFactor(event)" class="form">
            <p style="margin-bottom: 16px;">Secure your account with two-factor authentication using an authenticator app.</p>
            <div class="form-group">
                <label>Authenticator App</label>
                <select required>
                    <option>Google Authenticator</option>
                    <option>Microsoft Authenticator</option>
                    <option>Authy</option>
                </select>
            </div>
            <div class="form-group">
                <label>Verification Code</label>
                <input type="text" placeholder="Enter 6-digit code" maxlength="6" required />
            </div>
            <button type="submit" class="btn btn-primary">Enable 2FA</button>
        </form>
    `;
    showModalWithForm('Enable Two-Factor Authentication', twoFactorForm);
}

function setupTwoFactor(event) {
    event.preventDefault();
    closeModal();
    showNotification('Two-factor authentication enabled!', 'success');
}

function changeVisibility() {
    const visibilityForm = `
        <form onsubmit="updateVisibility(event)" class="form">
            <div class="form-group">
                <label>
                    <input type="radio" name="visibility" value="public" checked /> Public Profile
                </label>
                <p style="font-size: 12px; color: #6b7280; margin-top: 4px;">Your profile is visible to all artisans</p>
            </div>
            <div class="form-group">
                <label>
                    <input type="radio" name="visibility" value="private" /> Private Profile
                </label>
                <p style="font-size: 12px; color: #6b7280; margin-top: 4px;">Only artisans you've booked can see your profile</p>
            </div>
            <button type="submit" class="btn btn-primary">Save Preference</button>
        </form>
    `;
    showModalWithForm('Change Profile Visibility', visibilityForm);
}

function updateVisibility(event) {
    event.preventDefault();
    closeModal();
    showNotification('Profile visibility updated!', 'success');
}

function downloadData() {
    showNotification('Your data export has started. Check your email for the file.', 'success');
}

function deleteAccount() {
    const deleteForm = `
        <div style="text-align: left;">
            <p style="color: #ef4444; font-weight: bold; margin-bottom: 12px;">⚠️ Warning: This action cannot be undone</p>
            <p>Deleting your account will:</p>
            <ul style="margin: 12px 0; padding-left: 20px;">
                <li>Permanently delete all your personal information</li>
                <li>Cancel all active bookings</li>
                <li>Remove all your reviews and ratings</li>
                <li>Prevent future artisan access to your information</li>
            </ul>
            <form onsubmit="confirmDeleteAccount(event)" class="form" style="margin-top: 16px;">
                <div class="form-group">
                    <label>Type your email to confirm deletion:</label>
                    <input type="email" placeholder="${userData.email}" required />
                </div>
                <button type="submit" class="btn btn-danger" style="width: 100%; background-color: #ef4444;">
                    Permanently Delete Account
                </button>
            </form>
        </div>
    `;
    showModalWithForm('Delete Account', deleteForm);
}

function confirmDeleteAccount(event) {
    event.preventDefault();
    closeModal();
    showNotification('Account deletion request submitted. You will receive a confirmation email.', 'warning');
}

// ============ LOGOUT ============
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear user data from localStorage
        localStorage.removeItem("user");
        localStorage.removeItem("userId");
        localStorage.removeItem("isArtisan");
        
        // Redirect to login page
        window.location.href = 'login.html';
    }
}

// Initialize on script load as well
if (document.readyState === 'loading') {
    // Document is still loading
    document.addEventListener('DOMContentLoaded', loadUserData);
} else {
    // Document is already loaded
    loadUserData();
}

// ============ UTILITY FUNCTIONS ============

// Show modal dialog
function showModal(title, content) {
    // Create modal if it doesn't exist
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle"></h2>
                <div id="modalBody"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').textContent = content;
    modal.style.display = 'block';

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Show notification toast
function showNotification(message, type = 'info') {
    // Create notification container if it doesn't exist
    let container = document.getElementById('notificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notificationContainer';
        document.body.appendChild(container);
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
    `;

    container.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Add modal styles dynamically
const modalStyle = document.createElement('style');
modalStyle.textContent = `
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 30px;
        border-radius: 8px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
        from {
            transform: translateY(-50px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        line-height: 1;
    }

    .close:hover {
        color: #000;
    }

    .modal-content h2 {
        margin-top: 0;
        color: #333;
        margin-bottom: 16px;
    }

    .modal-content div {
        color: #666;
        line-height: 1.6;
    }

    #notificationContainer {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 3000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .notification {
        background-color: white;
        padding: 16px;
        border-radius: 8px;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        display: flex;
        align-items: center;
        justify-content: space-between;
        animation: slideInRight 0.3s ease;
        border-left: 4px solid;
    }

    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .notification-success {
        border-left-color: #10b981;
        background-color: #f0fdf4;
    }

    .notification-error {
        border-left-color: #ef4444;
        background-color: #fef2f2;
    }

    .notification-warning {
        border-left-color: #f59e0b;
        background-color: #fffbeb;
    }

    .notification-info {
        border-left-color: #3b82f6;
        background-color: #eff6ff;
    }

    .notification-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        width: 100%;
    }

    .notification-content span {
        flex: 1;
        color: #333;
    }

    .notification-close {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        color: #999;
        padding: 0;
    }

    .notification-close:hover {
        color: #333;
    }

    @media (max-width: 480px) {
        #notificationContainer {
            left: 10px;
            right: 10px;
            top: 10px;
        }

        .notification {
            min-width: auto;
        }
    }
`;
document.head.appendChild(modalStyle);

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Set default tab as active
    switchTab('home');
    
    // Add event listeners for message thread clicks
    const messageThreads = document.querySelectorAll('.message-thread');
    messageThreads.forEach(thread => {
        thread.addEventListener('click', function() {
            messageThreads.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Add event listeners for favorite buttons
    const favoriteButtons = document.querySelectorAll('.favorite-btn');
    favoriteButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            toggleFavorite(btn);
        });
    });
});

// Handle responsive behavior
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.remove('active');
    }
});

// ============ SUBSCRIPTION FUNCTIONS ============
function subscribeToArtisan(artisanId, artisanName) {
    // Check if already subscribed
    if (userData.subscriptions.includes(artisanId)) {
        unsubscribeFromArtisan(artisanId, artisanName);
        return;
    }

    const subscriptionForm = `
        <div style="text-align: left;">
            <h4>Subscribe to ${artisanName}</h4>
            <p>Benefits of subscription:</p>
            <ul style="margin: 12px 0; padding-left: 20px;">
                <li>✓ See this artisan first in search results</li>
                <li>✓ Get special discount offers</li>
                <li>✓ Priority booking availability</li>
                <li>✓ Early access to promotional services</li>
                <li>✓ Direct messaging for quick quotes</li>
            </ul>
            <form onsubmit="confirmSubscription('${artisanId}', '${artisanName}', event)" class="form" style="margin-top: 16px;">
                <button type="submit" class="btn btn-success" style="width: 100%;">
                    <i class="fa fa-star"></i> Subscribe Now
                </button>
            </form>
        </div>
    `;
    showModalWithForm('Subscribe to Premium Artisan', subscriptionForm);
}

function confirmSubscription(artisanId, artisanName, event) {
    event.preventDefault();
    
    // Add to subscriptions
    userData.subscriptions.push(artisanId);
    
    // Update button
    const btn = document.getElementById(`sub-btn-${artisanId}`);
    if (btn) {
        btn.textContent = '<i class="fa fa-check"></i> Subscribed';
        btn.style.backgroundColor = '#6b7280';
        btn.disabled = true;
    }
    
    // Show subscription badge
    const badge = document.getElementById(`sub-${artisanId}`);
    if (badge) {
        badge.style.display = 'inline-block';
    }
    
    // Update recommended section
    updateRecommendedArtisans();
    
    closeModal();
    showNotification(`✓ You're now subscribed to ${artisanName}! You'll see their services first in searches.`, 'success');
}

function unsubscribeFromArtisan(artisanId, artisanName) {
    if (confirm(`Are you sure you want to unsubscribe from ${artisanName}?`)) {
        // Remove from subscriptions
        userData.subscriptions = userData.subscriptions.filter(id => id !== artisanId);
        
        // Update button
        const btn = document.getElementById(`sub-btn-${artisanId}`);
        if (btn) {
            btn.innerHTML = '<i class="fa fa-plus"></i> Subscribe';
            btn.style.backgroundColor = '';
            btn.disabled = false;
        }
        
        // Hide subscription badge
        const badge = document.getElementById(`sub-${artisanId}`);
        if (badge) {
            badge.style.display = 'none';
        }
        
        // Update recommended section
        updateRecommendedArtisans();
        
        showNotification(`You've unsubscribed from ${artisanName}.`, 'info');
    }
}

function updateRecommendedArtisans() {
    const recommendedContainer = document.getElementById('recommendedArtisansList');
    if (!recommendedContainer) return;
    
    // Clear existing content
    recommendedContainer.innerHTML = '';
    
    // Fetch subscribed artisans from API
    fetchWithTimeout(`http://localhost:5000/api/client/${localStorage.getItem('userId')}/subscriptions`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("Subscriptions API Response:", data);
            if (data.status === "success" && data.subscriptions && data.subscriptions.length > 0) {
                data.subscriptions.forEach(artisan => {
                    const artisanHTML = `
                        <div class="recommended-artisan">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <img src="https://via.placeholder.com/50" alt="${artisan.name}" style="width: 50px; height: 50px; border-radius: 50%;" />
                                <div style="flex: 1;">
                                    <h4 style="margin: 0; font-size: 15px;">${artisan.name}</h4>
                                    <p style="margin: 0; color: #6b7280; font-size: 13px;">${artisan.service_type || 'Professional'}</p>
                                    <span style="color: #2563eb; font-size: 13px;"><i class="fa fa-check-circle"></i> Subscribed</span>
                                </div>
                            </div>
                            <button class="btn btn-sm btn-primary" onclick="bookArtisan('${artisan.id}')" style="width: 100%; margin-bottom: 6px;">Book Now</button>
                            <button class="btn btn-sm" onclick="unsubscribeFromArtisan('${artisan.id}', '${artisan.name}')" style="width: 100%; background-color: #fee2e2; color: #991b1b;">Unsubscribe</button>
                        </div>
                    `;
                    recommendedContainer.innerHTML += artisanHTML;
                });
            } else {
                recommendedContainer.innerHTML = '<p style="color: #6b7280; text-align: center; padding: 20px;">Subscribe to artisans to see recommendations here</p>';
            }
        })
        .catch(err => {
            console.error("Error fetching subscriptions:", err);
            recommendedContainer.innerHTML = '<p style="color: #6b7280; text-align: center; padding: 20px;">Subscribe to artisans to see recommendations here</p>';
        });
}
