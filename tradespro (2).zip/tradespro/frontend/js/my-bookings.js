const API_BASE_URL = 'http://localhost:5000';
let bookings = [];
let activeStatus = 'all';

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) sidebar.classList.toggle('active');
}

function logout(event) {
    if (event) event.preventDefault();
    localStorage.removeItem('user');
    localStorage.removeItem('userId');
    localStorage.removeItem('isArtisan');
    window.location.href = 'login.html';
}

function setState(message, isError = false) {
    const list = document.getElementById('bookingsList');
    list.innerHTML = `<div class="booking-state${isError ? ' error' : ''}">${escapeHtml(message)}</div>`;
}

function getFilteredBookings() {
    if (activeStatus === 'upcoming') {
        return bookings.filter(booking => !['completed', 'declined', 'cancelled'].includes(booking.status));
    }
    if (activeStatus === 'completed') {
        return bookings.filter(booking => booking.status === 'completed');
    }
    if (activeStatus === 'cancelled') {
        return bookings.filter(booking => ['cancelled', 'declined'].includes(booking.status));
    }
    return bookings;
}

function statusClass(status) {
    if (status === 'pending') return 'badge-warning';
    if (status === 'confirmed' || status === 'in_progress') return 'badge-info';
    if (status === 'completed') return 'badge-success';
    return 'badge-secondary';
}

function renderBookings() {
    const filteredBookings = getFilteredBookings();
    const list = document.getElementById('bookingsList');

    if (!filteredBookings.length) {
        const label = activeStatus === 'all' ? '' : `${activeStatus} `;
        list.innerHTML = `<div class="booking-state">No ${label}bookings yet. <a href="find-artisans.html">Find an artisan</a> to make a booking.</div>`;
        return;
    }

    list.innerHTML = filteredBookings.map(booking => {
        const artisanName = booking.artisan_name || 'Unknown artisan';
        const serviceName = booking.service_name || 'Service';
        const status = booking.status || 'pending';
        const artisanId = booking.artisan_id || '';
        return `
            <article class="booking-item" data-artisan-id="${escapeHtml(artisanId)}">
                <div class="booking-artisan">
                    <img src="https://via.placeholder.com/60" alt="${escapeHtml(artisanName)}" />
                    <div>
                        <h4>${escapeHtml(artisanName)}</h4>
                        <p>Artisan #${escapeHtml(artisanId)}</p>
                    </div>
                </div>
                <div class="booking-service">
                    <h3>${escapeHtml(serviceName)}</h3>
                    <p>${escapeHtml(booking.notes || 'No special notes')}</p>
                </div>
                <div class="booking-details">
                    <span><i class="fa fa-calendar"></i>${escapeHtml(booking.date || 'Date not set')}</span>
                    <span><i class="fa fa-clock-o"></i>${escapeHtml(booking.time || 'Time not set')}</span>
                </div>
                <div class="booking-status">
                    <span class="badge ${statusClass(status)}">${escapeHtml(status)}</span>
                </div>
                <div class="booking-actions">
                    <a class="btn btn-sm btn-outline" href="find-artisans.html">Find Artisan</a>
                </div>
            </article>
        `;
    }).join('');
}

async function loadBookings() {
    const userId = localStorage.getItem('userId');
    if (!userId || localStorage.getItem('isArtisan') === '1' || localStorage.getItem('isArtisan') === 'true') {
        window.location.href = 'login.html';
        return;
    }

    setState('Loading your bookings...');
    try {
        const response = await fetch(`${API_BASE_URL}/api/client/${encodeURIComponent(userId)}/bookings`);
        const data = await response.json();
        if (!response.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load bookings');
        }
        bookings = Array.isArray(data.bookings) ? data.bookings : [];
        renderBookings();
    } catch (error) {
        console.error('Error loading client bookings:', error);
        setState('Bookings could not be loaded. Please check that the TradePro server is running and try again.', true);
    }
}

async function loadUserName() {
    const userId = localStorage.getItem('userId');
    if (!userId) return;
    try {
        const response = await fetch(`${API_BASE_URL}/api/user/${encodeURIComponent(userId)}`);
        const data = await response.json();
        if (data.status === 'success' && data.user) {
            document.getElementById('topbarUserName').textContent = data.user.name || 'Client';
        }
    } catch (error) {
        document.getElementById('topbarUserName').textContent = 'Client';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-status]').forEach(button => {
        button.addEventListener('click', () => {
            activeStatus = button.dataset.status;
            document.querySelectorAll('[data-status]').forEach(item => item.classList.remove('active'));
            button.classList.add('active');
            renderBookings();
        });
    });

    document.getElementById('refreshBookings').addEventListener('click', loadBookings);
    loadUserName();
    loadBookings();
});
