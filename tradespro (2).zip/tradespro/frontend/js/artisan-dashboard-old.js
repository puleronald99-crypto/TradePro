// ARTISAN DASHBOARD FUNCTIONALITY

// ==================== LOAD USER DATA FROM LOCALSTORAGE ====================
// Initialize with empty data - will be populated from API/database
let artisanData = {
    name: '',
    email: '',
    phone: '',
    rating: 0,
    verified: false
};

// Load user data from localStorage on page load
function loadUserData() {
    try {
        const storedUser = localStorage.getItem("user");
        const userId = localStorage.getItem("userId");
        const isArtisan = localStorage.getItem("isArtisan");
        
        console.log("Loading artisan data...");
        console.log("Stored user:", storedUser);
        console.log("User ID:", userId);
        console.log("Is artisan:", isArtisan);
        
        // Check if user is logged in and is an artisan
        if (!storedUser || !userId || (isArtisan !== "1" && isArtisan !== "true")) {
            console.warn("Not logged in as artisan, redirecting to login");
            window.location.href = "login.html";
            return;
        }
        
        const user = JSON.parse(storedUser);
        console.log("Parsed user:", user);
        
        // Update artisanData with actual user data from DB
        artisanData.name = user.name || "Artisan";
        artisanData.email = user.email || "";
        artisanData.phone = user.phone || "";
        
        console.log("Updated artisanData:", artisanData);
        
        // Update page elements with user name immediately
        updateUserDisplay();
        
        // Initialize empty states while data loads
        populateBookings([]);
        populateUpcomingBookings([]);
        populateServices([]);
        populateReviews([]);
        
        // Fetch artisan-specific data from database
        fetchArtisanData(userId);
        
    } catch (error) {
        console.error("Error loading user data:", error);
        // If there's an error, redirect to login
        window.location.href = "login.html";
    }
}

// Update all places where user name is displayed
function updateUserDisplay() {
    console.log("Updating user display with name:", artisanData.name);
    
    // Update topbar user name
    const topbarUserName = document.getElementById("topbarUserName");
    if (topbarUserName) {
        topbarUserName.textContent = artisanData.name;
        console.log("Updated topbar name to:", artisanData.name);
    } else {
        console.warn("topbarUserName element not found");
    }
    
    // Update dashboard welcome message
    const dashboardUserName = document.getElementById("dashboardUserName");
    if (dashboardUserName) {
        dashboardUserName.textContent = artisanData.name;
        console.log("Updated dashboard name to:", artisanData.name);
    } else {
        console.warn("dashboardUserName element not found");
    }
}

// Helper function to fetch with timeout
function fetchWithTimeout(url, timeout = 5000) {
    return Promise.race([
        fetch(url),
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error('API request timeout')), timeout)
        )
    ]);
}

// Fetch artisan-specific data from API and populate dashboard
function fetchArtisanData(userId) {
    console.log("Fetching artisan data for user ID:", userId);
    
    // Fetch user profile data
    fetchWithTimeout(`http://localhost:5000/api/user/${userId}`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("User API Response:", data);
            
            if (data.status === "success" && data.user) {
                const user = data.user;
                
                // Update with DB info
                artisanData.name = user.name;
                artisanData.email = user.email;
                artisanData.phone = user.phone;
                
                // If artisan data exists, update it
                if (user.artisan) {
                    artisanData.rating = user.artisan.rating || 0;
                    artisanData.verified = user.artisan.verified || false;
                }
                
                console.log("Updated artisanData from API:", artisanData);
                updateUserDisplay();
            }
        })
        .catch(err => {
            console.error("Error fetching user data:", err);
            populateBookings([]);
            populateServices([]);
            populateReviews([]);
        });
    
    // Fetch bookings data
    fetchWithTimeout(`http://localhost:5000/api/artisan/${userId}/bookings`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("Bookings API Response:", data);
            if (data.status === "success") {
                const bookings = data.bookings || [];
                populateBookings(bookings);
                populateUpcomingBookings(bookings);
            } else {
                populateBookings([]);
                populateUpcomingBookings([]);
            }
        })
        .catch(err => {
            console.error("Error fetching bookings:", err);
            populateBookings([]);
            populateUpcomingBookings([]);
        });
    
    // Fetch services data
    fetchWithTimeout(`http://localhost:5000/api/artisan/${userId}/services`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("Services API Response:", data);
            if (data.status === "success") {
                populateServices(data.services || []);
            } else {
                populateServices([]);
            }
        })
        .catch(err => {
            console.error("Error fetching services:", err);
            populateServices([]);
        });
    
    // Fetch reviews data
    fetchWithTimeout(`http://localhost:5000/api/artisan/${userId}/reviews`)
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log("Reviews API Response:", data);
            if (data.status === "success") {
                populateReviews(data.reviews || []);
            } else {
                populateReviews([]);
            }
        })
        .catch(err => {
            console.error("Error fetching reviews:", err);
            populateReviews([]);
        });
}

// Populate bookings in the dashboard
function populateBookings(bookings) {
    console.log("Populating bookings:", bookings);
    
    const bookingsContainer = document.querySelector('.bookings-list');
    if (!bookingsContainer) {
        console.warn("Bookings container not found");
        return;
    }
    
    if (!bookings || bookings.length === 0) {
        bookingsContainer.innerHTML = '<div class="empty-state"><p>No bookings yet. Accept jobs to get started!</p></div>';
        return;
    }
    
    let bookingsHTML = '';
    bookings.forEach((booking, index) => {
        const statusClass = `badge-${booking.status === 'pending' ? 'warning' : booking.status === 'completed' ? 'success' : 'info'}`;
        const bookingDate = new Date(booking.date);
        const formattedDate = bookingDate.toLocaleDateString() + ' ' + booking.time;
        
        bookingsHTML += `
            <div class="booking-card">
                <div class="booking-card-header">
                    <h3>${booking.service_name}</h3>
                    <span class="badge ${statusClass}">${booking.status}</span>
                </div>
                <div class="booking-card-body">
                    <div class="booking-info">
                        <div class="info-item">
                            <span class="label">Customer</span>
                            <span>${booking.customer_name}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">Date & Time</span>
                            <span>${formattedDate}</span>
                        </div>
                        <div class="info-item">
                            <span class="label">Notes</span>
                            <span>${booking.notes || 'No additional notes'}</span>
                        </div>
                    </div>
                </div>
                <div class="booking-card-footer">
                    <button class="btn btn-primary" onclick="acceptBooking(${booking.id})">Accept</button>
                    <button class="btn btn-secondary" onclick="declineBooking(${booking.id})">Decline</button>
                    <button class="btn btn-outline" onclick="viewBookingDetails(${booking.id})">View Details</button>
                </div>
            </div>
        `;
    });
    
    bookingsContainer.innerHTML = bookingsHTML;
}

// Populate services in the dashboard
function populateServices(services) {
    console.log("Populating services:", services);
    
    const servicesGrid = document.querySelector('.services-grid');
    if (!servicesGrid) {
        console.warn("Services grid not found");
        return;
    }
    
    if (!services || services.length === 0) {
        servicesGrid.innerHTML = '<div class="empty-state"><p>No services added yet. <button class="btn btn-primary btn-sm" onclick="addService()">Add your first service</button></p></div>';
        return;
    }
    
    let servicesHTML = '';
    services.forEach((service, index) => {
        servicesHTML += `
            <div class="service-card">
                <div class="service-header">
                    <h3>${service.name}</h3>
                    <div class="service-actions">
                        <button class="btn-icon" title="Edit" onclick="editService(${service.id})">
                            <i class="fa fa-pencil"></i>
                        </button>
                        <button class="btn-icon" title="Delete" onclick="deleteService(${service.id})">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="service-details">
                    <p>${service.description || 'Professional service'}</p>
                    <div class="service-meta">
                        <span class="badge badge-info">$${service.hourly_rate}/hour</span>
                        <span class="badge badge-success">Active</span>
                    </div>
                </div>
                <div class="service-stats">
                    <span><i class="fa fa-star"></i> Service ID: ${service.id}</span>
                </div>
            </div>
        `;
    });
    
    servicesGrid.innerHTML = servicesHTML;
}

// Populate services in the dashboard
function populateServices(services) {
    console.log("Populating services:", services);
    
    const servicesGrid = document.querySelector('.services-grid');
    if (!servicesGrid) {
        console.warn("Services grid not found");
        return;
    }
    
    if (!services || services.length === 0) {
        servicesGrid.innerHTML = '<div class="empty-state"><p>No services added yet. <button class="btn btn-primary btn-sm" onclick="addService()">Add your first service</button></p></div>';
        return;
    }
    
    let servicesHTML = '';
    services.forEach((service, index) => {
        servicesHTML += `
            <div class="service-card">
                <div class="service-header">
                    <h3>${service.name}</h3>
                    <div class="service-actions">
                        <button class="btn-icon" title="Edit" onclick="editService(${service.id})">
                            <i class="fa fa-pencil"></i>
                        </button>
                        <button class="btn-icon" title="Delete" onclick="deleteService(${service.id})">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="service-details">
                    <p>${service.description || 'Professional service'}</p>
                    <div class="service-meta">
                        <span class="badge badge-info">$${service.hourly_rate}/hour</span>
                        <span class="badge badge-success">Active</span>
                    </div>
                </div>
                <div class="service-stats">
                    <span><i class="fa fa-star"></i> Service ID: ${service.id}</span>
                </div>
            </div>
        `;
    });
    
    servicesGrid.innerHTML = servicesHTML;
}

// Populate reviews in the dashboard overview and reviews tab
function populateReviews(reviews) {
    console.log("Populating reviews:", reviews);
    
    // Update the full reviews container
    const reviewsContainer = document.querySelector('.reviews-container');
    if (reviewsContainer) {
        if (!reviews || reviews.length === 0) {
            reviewsContainer.innerHTML = '<div class="empty-state"><p>No reviews yet. Complete jobs to receive reviews from customers!</p></div>';
        } else {
            let reviewsHTML = '';
            reviews.forEach((review, index) => {
                const reviewDate = new Date(review.created_at);
                const daysAgo = Math.floor((Date.now() - reviewDate.getTime()) / (1000 * 60 * 60 * 24));
                const timeAgo = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : `${daysAgo} days ago`;
                
                let starsHTML = '';
                for (let i = 0; i < 5; i++) {
                    if (i < Math.floor(review.rating)) {
                        starsHTML += '<i class="fa fa-star"></i>';
                    } else if (i < review.rating && review.rating % 1 !== 0) {
                        starsHTML += '<i class="fa fa-star-half-o"></i>';
                    } else {
                        starsHTML += '<i class="fa fa-star-o"></i>';
                    }
                }
                
                reviewsHTML += `
                    <div class="review-card">
                        <div class="review-header">
                            <div>
                                <h4>${review.customer_name}</h4>
                                <div class="stars">${starsHTML}</div>
                            </div>
                            <small>${timeAgo}</small>
                        </div>
                        <p>"${review.comment}"</p>
                    </div>
                `;
            });
            
            reviewsContainer.innerHTML = reviewsHTML;
        }
    }
    
    // Update the recent reviews in overview (show only first 2)
    const reviewList = document.querySelector('.review-list');
    if (reviewList) {
        if (!reviews || reviews.length === 0) {
            reviewList.innerHTML = '<p style="padding: 20px; text-align: center; color: #999;">No reviews yet</p>';
        } else {
            let recentReviewsHTML = '';
            const recentReviews = reviews.slice(0, 2);
            
            recentReviews.forEach((review, index) => {
                const reviewDate = new Date(review.created_at);
                const daysAgo = Math.floor((Date.now() - reviewDate.getTime()) / (1000 * 60 * 60 * 24));
                const timeAgo = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : `${daysAgo} days ago`;
                
                let starsHTML = '';
                for (let i = 0; i < 5; i++) {
                    if (i < Math.floor(review.rating)) {
                        starsHTML += '<i class="fa fa-star"></i>';
                    } else if (i < review.rating && review.rating % 1 !== 0) {
                        starsHTML += '<i class="fa fa-star-half-o"></i>';
                    } else {
                        starsHTML += '<i class="fa fa-star-o"></i>';
                    }
                }
                
                recentReviewsHTML += `
                    <div class="review-item">
                        <div class="review-header">
                            <div>
                                <h4>${review.customer_name}</h4>
                                <div class="stars">${starsHTML}</div>
                            </div>
                            <small>${timeAgo}</small>
                        </div>
                        <p>"${review.comment}"</p>
                    </div>
                `;
            });
            
            reviewList.innerHTML = recentReviewsHTML;
        }
    }
}

// Populate upcoming bookings in dashboard overview (show only first 2)
function populateUpcomingBookings(bookings) {
    console.log("Populating upcoming bookings:", bookings);
    
    const bookingList = document.querySelector('.booking-list');
    if (!bookingList) {
        console.warn("Booking list not found");
        return;
    }
    
    if (!bookings || bookings.length === 0) {
        bookingList.innerHTML = '<div class="empty-state"><p>No upcoming bookings. Check back soon!</p></div>';
        return;
    }
    
    let bookingsHTML = '';
    const upcomingBookings = bookings.slice(0, 2);
    
    upcomingBookings.forEach((booking, index) => {
        const bookingDate = new Date(booking.date);
        const today = new Date();
        
        let dateText = 'Today';
        if (bookingDate.toDateString() === new Date(today.getTime() + 86400000).toDateString()) {
            dateText = 'Tomorrow';
        } else {
            dateText = bookingDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        }
        
        bookingsHTML += `
            <div class="booking-item">
                <div class="booking-time">
                    <span class="date">${dateText}</span>
                    <span class="time">${booking.time}</span>
                </div>
                <div class="booking-details">
                    <h4>${booking.service_name}</h4>
                    <p>${booking.customer_name}</p>
                    <small>${booking.notes || 'No location info'}</small>
                </div>
                <div class="booking-actions">
                    <button class="btn btn-sm btn-primary" onclick="acceptBooking(${booking.id})">Accept</button>
                    <button class="btn btn-sm btn-secondary" onclick="viewBookingDetails(${booking.id})">View Details</button>
                </div>
            </div>
        `;
    });
    
    bookingList.innerHTML = bookingsHTML;
}

// Load user data when page loads
window.addEventListener('load', function() {
    loadUserData();
});

// Also try to load on DOMContentLoaded
document.addEventListener("DOMContentLoaded", function() {
    // Give a small delay to ensure DOM is ready
    setTimeout(loadUserData, 100);
});

// Tab switching
function switchTab(tabName) {
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));

    // Show selected tab
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Update nav links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    
    const activeLink = document.querySelector(`a[href="#${tabName}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // Update page title
    const titleMap = {
        'dashboard': 'Dashboard',
        'profile': 'My Profile',
        'services': 'My Services',
        'bookings': 'Bookings',
        'schedule': 'Availability',
        'earnings': 'Earnings',
        'reviews': 'Reviews & Ratings',
        'messages': 'Messages',
        'settings': 'Settings'
    };
    document.getElementById('pageTitle').textContent = titleMap[tabName] || 'Dashboard';
}

// Sidebar toggle
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    
    sidebar.classList.toggle('active');
    mainContent.classList.toggle('sidebar-collapsed');
}

// Close sidebar on mobile when clicking a link
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                const sidebar = document.getElementById('sidebar');
                sidebar.classList.remove('active');
            }
        });
    });
});

// Dropdown menus
function toggleNotifications() {
    const dropdown = document.getElementById('notificationDropdown');
    dropdown.classList.toggle('active');
    
    // Close other dropdowns
    document.getElementById('userDropdown').classList.remove('active');
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
    
    // Close other dropdowns
    document.getElementById('notificationDropdown').classList.remove('active');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const notificationBtn = document.querySelector('.notification-btn');
    const userBtn = document.querySelector('.user-btn');
    
    if (!event.target.closest('.notifications') && 
        !event.target.closest('.notification-dropdown')) {
        document.getElementById('notificationDropdown').classList.remove('active');
    }
    
    if (!event.target.closest('.user-menu')) {
        document.getElementById('userDropdown').classList.remove('active');
    }
});

// ============ PROFILE FUNCTIONS ============
function editProfile() {
    const userId = localStorage.getItem("userId");
    
    const form = `
        <form onsubmit="saveProfile(event, ${userId})" class="form">
            <div class="form-group">
                <label>Bio</label>
                <textarea id="profileBio" placeholder="Tell customers about your experience and services"></textarea>
            </div>
            <div class="form-group">
                <label>Experience Years</label>
                <input type="number" id="profileExperience" value="0" min="0" />
            </div>
            <div class="form-group">
                <label>Company Name</label>
                <input type="text" id="profileCompany" placeholder="Your business name" />
            </div>
            <div class="form-group">
                <label>License Number</label>
                <input type="text" id="profileLicense" placeholder="Professional license number" />
            </div>
            <div class="form-group">
                <label>Service Radius (km)</label>
                <input type="number" id="profileRadius" value="15" min="1" />
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    `;
    showModalWithForm('Edit Profile', form);
}

function saveProfile(event, userId) {
    event.preventDefault();
    
    const bio = document.getElementById('profileBio').value;
    const experience = parseInt(document.getElementById('profileExperience').value) || 0;
    const company = document.getElementById('profileCompany').value;
    const license = document.getElementById('profileLicense').value;
    const radius = parseInt(document.getElementById('profileRadius').value) || 15;
    
    fetch(`http://localhost:5000/api/artisan/${userId}/profile`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            bio: bio,
            experience_years: experience,
            company_name: company,
            license_number: license,
            service_radius_km: radius
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Profile updated successfully!', 'success');
            fetchArtisanData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to update profile', 'error');
    });
}

function changePhoto() {
    const form = `
        <form onsubmit="uploadPhoto(event)" class="form">
            <div class="form-group">
                <label>Upload Photo</label>
                <input type="file" accept="image/*" required />
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    `;
    showModalWithForm('Change Profile Photo', form);
}

// ============ SERVICES FUNCTIONS ============
function addService() {
    const userId = localStorage.getItem("userId");
    
    const form = `
        <form onsubmit="saveService(event, ${userId})" class="form">
            <div class="form-group">
                <label>Service Name</label>
                <input type="text" id="serviceName" placeholder="e.g., Electrical Installation" required />
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea id="serviceDescription" placeholder="Describe your service..." required></textarea>
            </div>
            <div class="form-group">
                <label>Category</label>
                <input type="text" id="serviceCategory" placeholder="e.g., Electrical" />
            </div>
            <div class="form-group">
                <label>Price per Hour</label>
                <input type="number" id="serviceRate" placeholder="$" step="0.01" required />
            </div>
            <button type="submit" class="btn btn-primary">Add Service</button>
        </form>
    `;
    showModalWithForm('Add New Service', form);
}

function saveService(event, userId) {
    event.preventDefault();
    
    const serviceName = document.getElementById('serviceName').value;
    const description = document.getElementById('serviceDescription').value;
    const category = document.getElementById('serviceCategory').value;
    const hourlyRate = parseFloat(document.getElementById('serviceRate').value);
    
    fetch(`http://localhost:5000/api/artisan/${userId}/services`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            service_name: serviceName,
            description: description,
            category: category,
            hourly_rate: hourlyRate
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Service added successfully!', 'success');
            fetchArtisanData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to add service', 'error');
    });
}

function editService(id) {
    const form = `
        <form onsubmit="updateService(${id}, event)" class="form">
            <div class="form-group">
                <label>Hourly Rate ($)</label>
                <input type="number" id="editServiceRate" step="0.01" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Service</button>
        </form>
    `;
    showModalWithForm('Edit Service', form);
}

function updateService(id, event) {
    event.preventDefault();
    const hourlyRate = parseFloat(document.getElementById('editServiceRate').value);
    const userId = localStorage.getItem("userId");
    
    fetch(`http://localhost:5000/api/artisan/service/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ hourly_rate: hourlyRate })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Service updated successfully!', 'success');
            fetchArtisanData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to update service', 'error');
    });
}

function deleteService(id) {
    if (confirm('Are you sure you want to delete this service?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/artisan/service/${id}`, {
            method: 'DELETE'
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Service deleted successfully', 'success');
                fetchArtisanData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('Failed to delete service', 'error');
        });
    }
}

// ============ BOOKINGS FUNCTIONS ============
function filterBookings(filter) {
    // Update active filter button
    const buttons = document.querySelectorAll('.filter-buttons .btn');
    buttons.forEach(btn => btn.classList.remove('btn-primary'));
    
    event.target.classList.add('btn-primary');
    
    showNotification(`Filtered bookings by: ${filter}`, 'info');
}

function acceptBooking(id) {
    if (confirm('Accept this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: 'confirmed' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking accepted!', 'success');
                // Reload bookings
                fetchArtisanData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('Failed to accept booking', 'error');
        });
    }
}

function declineBooking(id) {
    if (confirm('Are you sure you want to decline this booking?')) {
        const userId = localStorage.getItem("userId");
        
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: 'declined' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking declined', 'info');
                fetchArtisanData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('Failed to decline booking', 'error');
        });
    }
}

function viewBookingDetails(id) {
    const userId = localStorage.getItem("userId");
    
    fetch(`http://localhost:5000/api/artisan/${userId}/bookings`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const booking = data.bookings.find(b => b.id === id);
                if (booking) {
                    const details = `
                        <div style="text-align: left;">
                            <p><strong>Customer:</strong> ${booking.customer_name}</p>
                            <p><strong>Service:</strong> ${booking.service_name}</p>
                            <p><strong>Date & Time:</strong> ${booking.date} ${booking.time}</p>
                            <p><strong>Status:</strong> ${booking.status}</p>
                            <p><strong>Notes:</strong> ${booking.notes || 'No additional notes'}</p>
                            <div style="margin-top: 16px; display: flex; gap: 8px;">
                                <button class="btn btn-primary" onclick="acceptBooking(${booking.id})">Accept</button>
                                <button class="btn btn-secondary" onclick="declineBooking(${booking.id})">Decline</button>
                                <button class="btn btn-outline" onclick="startBooking(${booking.id})">Start Job</button>
                            </div>
                        </div>
                    `;
                    showModalWithForm('Booking Details', details);
                }
            }
        })
        .catch(err => console.error('Error:', err));
}

function contactCustomer(id) {
    switchTab('messages');
    showNotification('Opening customer chat...', 'info');
}

function startBooking(id) {
    const userId = localStorage.getItem("userId");
    
    fetch(`http://localhost:5000/api/booking/${id}/status`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: 'in_progress' })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('Job started!', 'success');
            closeModal();
            fetchArtisanData(userId);
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to start job', 'error');
    });
}

function completeBooking(id) {
    const userId = localStorage.getItem("userId");
    
    if (confirm('Mark this job as complete?')) {
        fetch(`http://localhost:5000/api/booking/${id}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: 'completed' })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Booking completed! Thank you for your work.', 'success');
                fetchArtisanData(userId);
            } else {
                showNotification('Error: ' + data.message, 'error');
            }
        })
        .catch(err => {
            console.error('Error:', err);
            showNotification('Failed to complete booking', 'error');
        });
    }
}

function updateProgress(id) {
    const form = `
        <form onsubmit="saveProgress(${id}, event)" class="form">
            <div class="form-group">
                <label>Job Progress (%)</label>
                <input type="range" min="0" max="100" value="65" id="progressSlider" 
                       oninput="document.getElementById('progressValue').textContent = this.value + '%'" />
                <span id="progressValue">65%</span>
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea placeholder="Add any notes about the job progress..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Progress</button>
        </form>
    `;
    showModalWithForm('Update Job Progress', form);
}

function saveProgress(id, event) {
    event.preventDefault();
    closeModal();
    showNotification('Job progress updated successfully!', 'success');
}

// ============ SCHEDULE FUNCTIONS ============
function setAvailability() {
    const userId = localStorage.getItem("userId");
    
    const form = `
        <form onsubmit="saveAvailability(event, ${userId})" class="form">
            <div class="form-group">
                <label>Monday</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <input type="time" id="monStart" value="09:00" required /> 
                    <span>to</span>
                    <input type="time" id="monEnd" value="17:00" required />
                </div>
            </div>
            <div class="form-group">
                <label>Tuesday</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <input type="time" id="tueStart" value="09:00" required /> 
                    <span>to</span>
                    <input type="time" id="tueEnd" value="17:00" required />
                </div>
            </div>
            <div class="form-group">
                <label>Wednesday</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <input type="time" id="wedStart" value="09:00" required /> 
                    <span>to</span>
                    <input type="time" id="wedEnd" value="17:00" required />
                </div>
            </div>
            <div class="form-group">
                <label>Thursday</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <input type="time" id="thuStart" value="09:00" required /> 
                    <span>to</span>
                    <input type="time" id="thuEnd" value="17:00" required />
                </div>
            </div>
            <div class="form-group">
                <label>Friday</label>
                <div style="display: flex; gap: 8px; align-items: center;">
                    <input type="time" id="friStart" value="09:00" required /> 
                    <span>to</span>
                    <input type="time" id="friEnd" value="17:00" required />
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Save Availability</button>
        </form>
    `;
    showModalWithForm('Set Availability', form);
}

function saveAvailability(event, userId) {
    event.preventDefault();
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const dayIds = ['mon', 'tue', 'wed', 'thu', 'fri'];
    const availability = [];
    
    dayIds.forEach((dayId, index) => {
        const startTime = document.getElementById(dayId + 'Start').value;
        const endTime = document.getElementById(dayId + 'End').value;
        availability.push({
            day: days[index],
            start_time: startTime,
            end_time: endTime
        });
    });
    
    fetch(`http://localhost:5000/api/artisan/${userId}/availability`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ availability: availability })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            closeModal();
            showNotification('Availability updated successfully!', 'success');
        } else {
            showNotification('Error: ' + data.message, 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showNotification('Failed to update availability', 'error');
    });
}

function editSchedule(day) {
    const form = `
        <form onsubmit="saveSchedule(event)" class="form">
            <div class="form-group">
                <label>Available</label>
                <input type="checkbox" checked /> Yes, I'm available on ${day}
            </div>
            <div class="form-group">
                <label>Start Time</label>
                <input type="time" value="09:00" required />
            </div>
            <div class="form-group">
                <label>End Time</label>
                <input type="time" value="17:00" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Schedule</button>
        </form>
    `;
    showModalWithForm(`Edit ${day.charAt(0).toUpperCase() + day.slice(1)} Schedule`, form);
}

function saveSchedule(event) {
    event.preventDefault();
    closeModal();
    showNotification('Schedule saved successfully!', 'success');
}

function addUnavailableDate() {
    const form = `
        <form onsubmit="saveUnavailableDate(event)" class="form">
            <div class="form-group">
                <label>Date(s)</label>
                <input type="date" required />
            </div>
            <div class="form-group">
                <label>Reason</label>
                <input type="text" placeholder="e.g., Vacation, Personal appointment" required />
            </div>
            <button type="submit" class="btn btn-primary">Add Date</button>
        </form>
    `;
    showModalWithForm('Add Unavailable Date', form);
}

function saveUnavailableDate(event) {
    event.preventDefault();
    closeModal();
    showNotification('Unavailable date added successfully!', 'success');
}

function removeUnavailableDate(id) {
    if (confirm('Remove this unavailable date?')) {
        showNotification('Unavailable date removed', 'success');
    }
}

// ============ EARNINGS FUNCTIONS ============
function filterEarnings(period) {
    showNotification(`Earnings filtered for: ${period}`, 'info');
}

function editPayoutMethod() {
    const form = `
        <form onsubmit="savePayoutMethod(event)" class="form">
            <div class="form-group">
                <label>Bank Account Number</label>
                <input type="text" placeholder="Enter account number" required />
            </div>
            <div class="form-group">
                <label>Routing Number</label>
                <input type="text" placeholder="Enter routing number" required />
            </div>
            <div class="form-group">
                <label>Account Holder Name</label>
                <input type="text" placeholder="Full name" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Payout Method</button>
        </form>
    `;
    showModalWithForm('Edit Payout Method', form);
}

function savePayoutMethod(event) {
    event.preventDefault();
    closeModal();
    showNotification('Payout method updated successfully!', 'success');
}

function editPayoutFrequency() {
    const form = `
        <form onsubmit="savePayoutFrequency(event)" class="form">
            <div class="form-group">
                <label>Payout Frequency</label>
                <select required>
                    <option value="weekly">Weekly</option>
                    <option value="bi-weekly">Bi-Weekly</option>
                    <option value="monthly">Monthly</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save Frequency</button>
        </form>
    `;
    showModalWithForm('Edit Payout Frequency', form);
}

function savePayoutFrequency(event) {
    event.preventDefault();
    closeModal();
    showNotification('Payout frequency updated successfully!', 'success');
}

// ============ REVIEWS FUNCTIONS ============
function replyReview(id) {
    const form = `
        <form onsubmit="saveReviewReply(${id}, event)" class="form">
            <div class="form-group">
                <label>Your Reply</label>
                <textarea placeholder="Write your response to this review..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Post Reply</button>
        </form>
    `;
    showModalWithForm('Reply to Review', form);
}

function saveReviewReply(id, event) {
    event.preventDefault();
    closeModal();
    showNotification('Your reply has been posted!', 'success');
}

// ============ MESSAGES FUNCTIONS ============
function openChat(customer) {
    const chatHeader = document.querySelector('.chat-header h3');
    if (chatHeader) {
        chatHeader.textContent = customer.charAt(0).toUpperCase() + customer.slice(1);
    }
    showNotification(`Opening chat with ${customer}`, 'info');
}

function callCustomer() {
    showNotification('Initiating call...', 'info');
}

// ============ SETTINGS FUNCTIONS ============
function changeEmail() {
    const form = `
        <form onsubmit="saveEmail(event)" class="form">
            <div class="form-group">
                <label>Current Email</label>
                <input type="email" value="${artisanData.email}" disabled />
            </div>
            <div class="form-group">
                <label>New Email</label>
                <input type="email" placeholder="Enter new email" required />
            </div>
            <div class="form-group">
                <label>Password (to confirm)</label>
                <input type="password" placeholder="Enter password" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Email</button>
        </form>
    `;
    showModalWithForm('Change Email', form);
}

function saveEmail(event) {
    event.preventDefault();
    closeModal();
    showNotification('Email updated successfully!', 'success');
}

function changePassword() {
    const form = `
        <form onsubmit="savePassword(event)" class="form">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" required />
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" required />
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" required />
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
    `;
    showModalWithForm('Change Password', form);
}

function savePassword(event) {
    event.preventDefault();
    closeModal();
    showNotification('Password updated successfully!', 'success');
}

function enableTwoFactor() {
    const form = `
        <div class="form">
            <p>Two-Factor Authentication adds an extra layer of security to your account.</p>
            <p style="margin: 16px 0;">A verification code will be sent to your phone.</p>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" value="+1 (555) 123-4567" required />
            </div>
            <button type="button" class="btn btn-primary" onclick="enableTwoFactorSubmit()">Enable 2FA</button>
        </div>
    `;
    showModalWithForm('Enable Two-Factor Authentication', form);
}

function enableTwoFactorSubmit() {
    closeModal();
    showNotification('Two-Factor Authentication enabled!', 'success');
}

function changeServiceArea() {
    const form = `
        <form onsubmit="saveServiceArea(event)" class="form">
            <div class="form-group">
                <label>Service Radius (miles)</label>
                <input type="number" value="15" min="1" max="100" required />
            </div>
            <div class="form-group">
                <label>Your Location</label>
                <input type="text" value="New York, NY" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Service Area</button>
        </form>
    `;
    showModalWithForm('Change Service Area', form);
}

function saveServiceArea(event) {
    event.preventDefault();
    closeModal();
    showNotification('Service area updated!', 'success');
}

function changeResponseTime() {
    const form = `
        <form onsubmit="saveResponseTime(event)" class="form">
            <div class="form-group">
                <label>Response Time</label>
                <select required>
                    <option value="30">Within 30 minutes</option>
                    <option value="60" selected>Within 1 hour</option>
                    <option value="120">Within 2 hours</option>
                    <option value="240">Within 4 hours</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    `;
    showModalWithForm('Change Response Time', form);
}

function saveResponseTime(event) {
    event.preventDefault();
    closeModal();
    showNotification('Response time updated!', 'success');
}

function changeBufferTime() {
    const form = `
        <form onsubmit="saveBufferTime(event)" class="form">
            <div class="form-group">
                <label>Buffer Time Between Jobs (minutes)</label>
                <input type="number" value="30" min="15" max="120" required />
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    `;
    showModalWithForm('Change Booking Buffer Time', form);
}

function saveBufferTime(event) {
    event.preventDefault();
    closeModal();
    showNotification('Buffer time updated!', 'success');
}

function changeProfileVisibility() {
    const form = `
        <form onsubmit="saveProfileVisibility(event)" class="form">
            <div class="form-group">
                <label>Visibility</label>
                <select required>
                    <option value="all" selected>Visible to all customers</option>
                    <option value="reviewed">Only to customers who reviewed</option>
                    <option value="booked">Only to customers who booked</option>
                    <option value="hidden">Hidden (Draft mode)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    `;
    showModalWithForm('Change Profile Visibility', form);
}

function saveProfileVisibility(event) {
    event.preventDefault();
    closeModal();
    showNotification('Profile visibility updated!', 'success');
}

function downloadData() {
    showNotification('Your data export has started. Check your email for the file.', 'success');
}

function deleteAccount() {
    if (confirm('Are you sure? This action cannot be undone.')) {
        if (confirm('This will permanently delete your account and all associated data. Proceed?')) {
            showNotification('Account deletion initiated...', 'warning');
        }
    }
}

// ============ LOGOUT ============
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear user data from localStorage
        localStorage.removeItem("user");
        localStorage.removeItem("userId");
        localStorage.removeItem("isArtisan");
        
        // Redirect to login page
        window.location.href = 'login.html';
    }
}

// ============ UTILITY FUNCTIONS ============

// Show modal dialog
function showModal(title, content) {
    // Create modal if it doesn't exist
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle"></h2>
                <div id="modalBody"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    modal.style.display = 'block';

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };
}

function showModalWithForm(title, formHtml) {
    showModal(title, formHtml);
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Show notification toast
function showNotification(message, type = 'info') {
    // Create notification container if it doesn't exist
    let container = document.getElementById('notificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notificationContainer';
        document.body.appendChild(container);
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
    `;

    container.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Add modal styles dynamically
const modalStyle = document.createElement('style');
modalStyle.textContent = `
    .modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
        background-color: white;
        margin: 5% auto;
        padding: 30px;
        border-radius: 8px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
        from {
            transform: translateY(-50px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        line-height: 1;
    }

    .close:hover {
        color: #000;
    }

    .modal-content h2 {
        margin-top: 0;
        color: #333;
        margin-bottom: 16px;
    }

    .modal-content div {
        color: #666;
        line-height: 1.6;
    }

    #notificationContainer {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 3000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .notification {
        background-color: white;
        padding: 16px;
        border-radius: 8px;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        display: flex;
        align-items: center;
        justify-content: space-between;
        animation: slideInRight 0.3s ease;
        border-left: 4px solid;
    }

    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .notification-success {
        border-left-color: #10b981;
        background-color: #f0fdf4;
    }

    .notification-error {
        border-left-color: #ef4444;
        background-color: #fef2f2;
    }

    .notification-warning {
        border-left-color: #f59e0b;
        background-color: #fffbeb;
    }

    .notification-info {
        border-left-color: #3b82f6;
        background-color: #eff6ff;
    }

    .notification-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        width: 100%;
    }

    .notification-content span {
        flex: 1;
        color: #333;
    }

    .notification-close {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        color: #999;
        padding: 0;
    }

    .notification-close:hover {
        color: #333;
    }

    @media (max-width: 480px) {
        #notificationContainer {
            left: 10px;
            right: 10px;
            top: 10px;
        }

        .notification {
            min-width: auto;
        }
    }
`;
document.head.appendChild(modalStyle);

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Set default tab as active
    switchTab('dashboard');
    
    // Add event listeners for message thread clicks
    const messageThreads = document.querySelectorAll('.message-thread');
    messageThreads.forEach(thread => {
        thread.addEventListener('click', function() {
            messageThreads.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });
});

// Handle responsive behavior
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.remove('active');
    }
});

// ============ PREMIUM SUBSCRIPTION FUNCTIONS ============
function togglePremiumSubscription() {
    if (artisanData.isPremium) {
        cancelPremiumSubscription();
    } else {
        enablePremiumSubscription();
    }
}

function enablePremiumSubscription() {
    const premiumForm = `
        <div style="text-align: left;">
            <h3>Unlock Premium Benefits</h3>
            <p style="margin: 16px 0; color: #6b7280;">Boost your visibility and attract more customers!</p>
            <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 16px; border-radius: 8px; margin: 16px 0;">
                <h4 style="color: #059669; margin-top: 0;">Premium Benefits Include:</h4>
                <ul style="margin: 8px 0; padding-left: 20px;">
                    <li>✓ Appear FIRST in customer searches</li>
                    <li>✓ Get recommended to new customers</li>
                    <li>✓ Premium badge on your profile</li>
                    <li>✓ Increased visibility in all searches</li>
                    <li>✓ Track number of subscribers</li>
                    <li>✓ Access to customer insights</li>
                </ul>
            </div>
            <div style="background-color: #fffbeb; border: 1px solid #fde68a; padding: 12px; border-radius: 8px; margin: 12px 0;">
                <strong>Cost:</strong> $9.99/month or $99/year (Save 17%)
            </div>
            <form onsubmit="confirmPremiumSubscription(event)" class="form">
                <div class="form-group">
                    <label>
                        <input type="radio" name="plan" value="monthly" checked /> Monthly - $9.99/month
                    </label>
                </div>
                <div class="form-group">
                    <label>
                        <input type="radio" name="plan" value="yearly" /> Yearly - $99/year (Save $20)
                    </label>
                </div>
                <button type="submit" class="btn btn-success" style="width: 100%; margin-top: 16px;">
                    <i class="fa fa-crown"></i> Upgrade to Premium
                </button>
            </form>
        </div>
    `;
    showModalWithForm('Go Premium', premiumForm);
}

function confirmPremiumSubscription(event) {
    event.preventDefault();
    const plan = document.querySelector('input[name="plan"]:checked').value;
    
    artisanData.isPremium = true;
    artisanData.subscribers = 3; // Start with 3 subscribers
    
    updatePremiumUI();
    closeModal();
    
    const planText = plan === 'monthly' ? 'Monthly ($9.99/month)' : 'Yearly ($99/year)';
    showNotification(`🎉 Welcome to Premium! Your plan: ${planText}. You'll now appear first in customer searches!`, 'success');
}

function cancelPremiumSubscription() {
    if (confirm('Are you sure you want to cancel your Premium subscription? You\'ll lose premium benefits.')) {
        artisanData.isPremium = false;
        updatePremiumUI();
        showNotification('Premium subscription cancelled. You can reactivate anytime.', 'warning');
    }
}

function updatePremiumUI() {
    const statusEl = document.getElementById('premiumStatus');
    const btnEl = document.getElementById('premiumToggleBtn');
    const subscriberEl = document.getElementById('subscriberCount');
    
    if (statusEl) {
        statusEl.textContent = artisanData.isPremium ? '✓ Premium Active' : 'Not Subscribed';
        statusEl.style.color = artisanData.isPremium ? '#059669' : '#6b7280';
    }
    
    if (btnEl) {
        if (artisanData.isPremium) {
            btnEl.textContent = 'Cancel Premium';
            btnEl.className = 'btn btn-sm btn-danger';
        } else {
            btnEl.textContent = 'Enable Premium';
            btnEl.className = 'btn btn-sm btn-success';
        }
    }

// Initialize on script load as well
if (document.readyState === 'loading') {
    // Document is still loading
    document.addEventListener('DOMContentLoaded', loadUserData);
} else {
    // Document is already loaded
    loadUserData();
}
    
    if (subscriberEl) {
        subscriberEl.textContent = artisanData.subscribers + ' customers subscribed to you';
    }
}
