function toggleNav() {
    const navLinks = document.getElementById('navLinks');
    if (navLinks.className === '') {
        navLinks.className = 'responsive';
    } else {
        navLinks.className = '';
    }
}

// Service descriptions
const serviceDescriptions = {
    'Electrician': 'Professional electricians for residential and commercial electrical work, repairs, installations, and maintenance.',
    'Plumber': 'Licensed plumbers offering plumbing repairs, installations, pipe work, and emergency services.',
    'Carpenter': 'Skilled carpenters for woodworking, furniture making, renovations, and custom carpentry projects.',
    'Mechanic': 'Experienced mechanics for vehicle repairs, maintenance, diagnostics, and restoration services.',
    'Builder': 'Professional builders for construction projects, renovations, and structural work.',
    'Painter': 'Expert painters for interior and exterior painting, finishing touches, and decorative work.',
    'HVAC Technician': 'HVAC specialists for heating, cooling, ventilation system installation and maintenance.',
    'Locksmith': 'Professional locksmiths for lock installation, repairs, key cutting, and security services.',
    'Gardener': 'Landscape and garden experts for landscaping, maintenance, planting, and outdoor design.',
    'Roofer': 'Experienced roofers for roof installation, repairs, maintenance, and roofing solutions.'
};

function openServiceModal(serviceName) {
    const modal = document.getElementById('serviceModal');
    const modalServiceName = document.getElementById('modalServiceName');
    const modalServiceDesc = document.getElementById('modalServiceDesc');

    modalServiceName.textContent = serviceName;
    modalServiceDesc.textContent = serviceDescriptions[serviceName] || 'Find trusted professionals for this service.';

    modal.classList.add('show');
}

function closeServiceModal() {
    const modal = document.getElementById('serviceModal');
    modal.classList.remove('show');
}

function searchArtisans() {
    const service = document.getElementById("service").value.trim();
    const location = document.getElementById("location").value.trim();
    const resultsEl = document.getElementById('results');

    // simple validation
    if (!service || !location) {
        resultsEl.innerHTML = '<p class="result-meta">Please enter both service and location to search.</p>';
        return;
    }

    // show loading state
    resultsEl.innerHTML = '<p class="result-meta">Searching for <strong>' + escapeHtml(service) + '</strong> in <strong>' + escapeHtml(location) + '</strong>...</p>';

    // Fetch from database API
    fetch(`http://localhost:5000/api/search/artisans?service_type=${encodeURIComponent(service)}&location=${encodeURIComponent(location)}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.artisans && data.artisans.length > 0) {
                const grid = document.createElement('div');
                grid.className = 'result-grid';

                data.artisans.forEach(artisan => {
                    const card = document.createElement('div');
                    card.className = 'result-card';

                    const h3 = document.createElement('h3');
                    h3.textContent = artisan.name;

                    const serviceType = document.createElement('div');
                    serviceType.className = 'result-service';
                    serviceType.textContent = artisan.service_type || service;

                    const meta = document.createElement('div');
                    meta.className = 'result-meta';
                    meta.innerHTML = `<span>★ ${artisan.rating}/5 (${artisan.total_reviews} reviews)</span> • $${artisan.hourly_rate}/hr`;

                    const bio = document.createElement('p');
                    bio.className = 'result-bio';
                    bio.textContent = artisan.bio || 'Professional artisan services';

                    const contact = document.createElement('button');
                    contact.className = 'contact-btn';
                    contact.textContent = 'View Profile';
                    contact.addEventListener('click', () => {
                        alert('Contacting ' + artisan.name + ' — feature coming soon.');
                    });

                    card.appendChild(h3);
                    card.appendChild(serviceType);
                    card.appendChild(meta);
                    card.appendChild(bio);
                    card.appendChild(contact);
                    grid.appendChild(card);
                });

                resultsEl.innerHTML = '';
                resultsEl.appendChild(grid);
            } else {
                resultsEl.innerHTML = '<p class="result-meta">No artisans found matching your criteria. Try a different search.</p>';
            }
        })
        .catch(error => {
            console.error('Search error:', error);
            resultsEl.innerHTML = '<p class="result-meta">Search failed. Is the Flask server running on port 5000? Error: ' + error.message + '</p>';
        });
}

// small helper to avoid injecting raw text
function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// wire up button and enter key
document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('searchBtn');
    const inputs = [document.getElementById('service'), document.getElementById('location')];

    if (btn) btn.addEventListener('click', searchArtisans);

    inputs.forEach(inp => {
        if (!inp) return;
        inp.addEventListener('keydown', function (ev) {
            if (ev.key === 'Enter') searchArtisans();
        });
    });

    // Toggle between sign-in and sign-up forms (for login page)
    const imgBtn = document.querySelector('.img__btn');
    if (imgBtn) {
        imgBtn.addEventListener('click', function() {
            document.querySelector('.cont').classList.toggle('s--signup');
        });
    }

    // Service card click handlers
    const serviceCards = document.querySelectorAll('.cat-card');
    serviceCards.forEach(card => {
        card.addEventListener('click', function() {
            const serviceName = this.getAttribute('data-service');
            openServiceModal(serviceName);
        });
    });

    // Modal close button
    const closeBtn = document.querySelector('.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeServiceModal);
    }

    // Close modal when clicking outside
    const modal = document.getElementById('serviceModal');
    if (modal) {
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                closeServiceModal();
            }
        });
    }

    // Modal search button
    const modalSearchBtn = document.getElementById('modalSearchBtn');
    if (modalSearchBtn) {
        modalSearchBtn.addEventListener('click', function() {
            const serviceName = document.getElementById('modalServiceName').textContent;
            document.getElementById('service').value = serviceName;
            document.getElementById('location').focus();
            closeServiceModal();
        });
    }
});
