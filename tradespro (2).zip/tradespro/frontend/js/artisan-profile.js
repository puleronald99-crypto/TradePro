const profilePage = document.getElementById('profilePage');
const profileId = new URLSearchParams(window.location.search).get('id');

function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[character]));
}

function profileImageUrl(value) {
    if (!value) return 'https://via.placeholder.com/180';
    if (value.startsWith('http://') || value.startsWith('https://') || value.startsWith('data:')) return value;
    return `http://localhost:5000${value.startsWith('/') ? '' : '/'}${value}`;
}

function formatDate(value) {
    if (!value) return '';
    return new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function stars(rating) {
    const rounded = Math.round(Number(rating) || 0);
    return `${'&#9733;'.repeat(rounded)}${'&#9734;'.repeat(5 - rounded)}`;
}

function renderProfile(profile, reviews) {
    const services = profile.services || [];
    const serviceNames = services.map(service => service.name).join(' · ') || 'Trade professional';
    const verified = profile.verified ? '<span class="verified"><i class="fa fa-check"></i> Verified</span>' : '';
    const servicePosts = services.length ? services.map(service => `
        <article class="timeline-post service-post">
            <div class="post-heading"><span class="post-icon"><i class="fa fa-wrench"></i></span><div><strong>${escapeHtml(service.name)}</strong><small>Service offered on TradePro</small></div></div>
            <p>${escapeHtml(service.description || 'Professional service delivered with care and attention to detail.')}</p>
            ${service.hourly_rate !== null ? `<div class="post-price">From $${Number(service.hourly_rate).toFixed(2)} / hour</div>` : ''}
        </article>
    `).join('') : '<article class="timeline-post"><p class="muted">This artisan has not published services yet.</p></article>';
    const reviewPosts = reviews.length ? reviews.map(review => `
        <article class="timeline-post review-post">
            <div class="post-heading"><span class="review-avatar"><i class="fa fa-user"></i></span><div><strong>${escapeHtml(review.customer_name)}</strong><small>${formatDate(review.created_at)}</small></div><span class="review-stars">${stars(review.rating)}</span></div>
            <p>${escapeHtml(review.comment || 'Shared a TradePro service review.')}</p>
            ${review.artisan_reply ? `<div class="reply"><strong>${escapeHtml(profile.name)} replied</strong><p>${escapeHtml(review.artisan_reply)}</p></div>` : ''}
        </article>
    `).join('') : '<article class="timeline-post"><p class="muted">No client reviews yet. Be the first to work with this artisan.</p></article>';

    profilePage.innerHTML = `
        <section class="profile-hero">
            <div class="avatar-wrap"><img src="${profileImageUrl(profile.profile_picture)}" alt="${escapeHtml(profile.name)} profile photo" /></div>
            <div class="profile-identity">
                <div class="name-row"><h1>${escapeHtml(profile.name)}</h1>${verified}</div>
                <p class="handle">@${escapeHtml((profile.company_name || profile.name).toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 28))}</p>
                <p class="bio">${escapeHtml(profile.bio || 'Professional artisan on TradePro.')}</p>
                <p class="meta"><i class="fa fa-map-marker"></i> ${escapeHtml(profile.location || 'Location not specified')} &nbsp; <i class="fa fa-briefcase"></i> ${profile.experience_years || 0} years experience</p>
                <div class="profile-actions"><button class="primary-action" onclick="bookArtisan()"><i class="fa fa-calendar"></i> Book artisan</button><button class="secondary-action" onclick="messageArtisan()"><i class="fa fa-envelope"></i> Message</button></div>
            </div>
        </section>
        <section class="profile-stats" aria-label="Artisan statistics">
            <div><strong>${profile.total_reviews || 0}</strong><span>reviews</span></div><div><strong>${Number(profile.rating || 0).toFixed(1)}</strong><span>rating</span></div><div><strong>${profile.experience_years || 0}</strong><span>years</span></div><div><strong>${services.length}</strong><span>services</span></div>
        </section>
        <nav class="profile-tabs" aria-label="Profile sections"><button class="active" type="button" onclick="showProfileSection('timeline', this)"><i class="fa fa-th-large"></i> Timeline</button><button type="button" onclick="showProfileSection('services', this)"><i class="fa fa-wrench"></i> Services</button><button type="button" onclick="showProfileSection('reviews', this)"><i class="fa fa-star"></i> Reviews (${reviews.length})</button></nav>
        <section class="profile-columns" id="timeline">
            <aside class="profile-sidebar"><div class="side-block"><h2>About</h2><p>${escapeHtml(profile.bio || 'A trusted professional available through TradePro.')}</p><div class="side-line"><i class="fa fa-clock-o"></i><span>${profile.availability_status === 'available' ? 'Available for new work' : escapeHtml(profile.availability_status)}</span></div><div class="side-line"><i class="fa fa-bolt"></i><span>Usually responds within ${profile.response_time_minutes || 60} minutes</span></div><div class="side-line"><i class="fa fa-crosshairs"></i><span>Service radius: ${profile.service_radius_km || 15} km</span></div></div></aside>
            <div class="timeline"><div class="timeline-heading" id="services"><h2>TradePro timeline</h2><span>${escapeHtml(serviceNames)}</span></div>${servicePosts}<details class="reviews-dropdown" id="reviews"><summary><i class="fa fa-star"></i> Reviews and artisan responses <span>${reviews.length}</span></summary><div class="reviews-list">${reviewPosts}</div></details></div>
        </section>
    `;
}

function showError(message) {
    profilePage.innerHTML = `<div class="profile-error"><i class="fa fa-exclamation-circle"></i><h1>Profile unavailable</h1><p>${escapeHtml(message)}</p><a href="user-dashboard-clean.html#search">Return to artisan search</a></div>`;
}

function bookArtisan() {
    sessionStorage.setItem('tradeproBookArtisanId', profileId || '');
    window.location.href = 'user-dashboard-clean.html#search';
}

function messageArtisan() {
    sessionStorage.setItem('tradeproMessageArtisanId', profilePage.dataset.userId || '');
    window.location.href = 'user-dashboard-clean.html#messages';
}

function showProfileSection(sectionId, button) {
    const target = document.getElementById(sectionId);
    if (!target) return;
    document.querySelectorAll('.profile-tabs button').forEach(tab => tab.classList.remove('active'));
    button.classList.add('active');
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (sectionId === 'reviews') {
        const reviews = document.getElementById('reviews');
        if (reviews && reviews.tagName === 'DETAILS') reviews.open = true;
    }
}

if (!profileId) {
    showError('No artisan profile was selected.');
} else {
    Promise.all([
        fetch(`http://localhost:5000/api/artisan-profile/${encodeURIComponent(profileId)}`).then(response => response.json()),
        fetch(`http://localhost:5000/api/artisan-profile/${encodeURIComponent(profileId)}/reviews`).then(response => response.json())
    ]).then(([profileResponse, reviewResponse]) => {
        if (profileResponse.status !== 'success') throw new Error(profileResponse.message || 'Artisan profile not found');
        profilePage.dataset.userId = profileResponse.profile.user_id || '';
        renderProfile(profileResponse.profile, reviewResponse.status === 'success' ? reviewResponse.reviews || [] : []);
        document.title = `${profileResponse.profile.name} - TradePro`;
    }).catch(error => showError(error.message || 'Unable to load this artisan profile.'));
}
