/**
 * TradePro Login & Signup JavaScript
 * Works with Python Flask backend
 */

const API_BASE_URL = 'http://localhost:5000';

// ==================== SIGN UP ====================

document.getElementById("signUpForm").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const name = document.getElementById("signUpName").value.trim();
    const email = document.getElementById("signUpEmail").value.trim();
    const password = document.getElementById("signUpPassword").value;
    const confirmPassword = document.getElementById("signUpConfirmPassword").value;
    const isArtisan = document.getElementById("isArtisanCheckbox")?.checked || false;
    const termsAccepted = document.getElementById("terms").checked;
    const signUpButton = document.querySelector("#signUpForm input[type='submit']");
    
    console.log("Sign-up attempt:", { name, email, isArtisan });
    
    // Clear previous errors
    const signUpError = document.getElementById("signUpError");
    if (signUpError) {
        signUpError.style.display = "none";
        signUpError.innerText = "";
    }
    
    // Validate inputs
    if (!name || !email || !password || !confirmPassword) {
        showSignUpError("All fields are required");
        return;
    }
    
    if (!email.includes("@")) {
        showSignUpError("Please enter a valid email address");
        return;
    }
    
    if (password !== confirmPassword) {
        showSignUpError("Passwords do not match");
        return;
    }
    
    if (password.length < 6) {
        showSignUpError("Password must be at least 6 characters");
        return;
    }
    
    if (!termsAccepted) {
        showSignUpError("You must agree to the Terms of Service and Privacy Policy");
        return;
    }
    
    // Disable button during request
    if (signUpButton) {
        signUpButton.disabled = true;
        signUpButton.value = "Creating account...";
    }
    
    // Send signup request
    const data = {
        name: name,
        email: email,
        password: password,
        is_artisan: isArtisan
    };
    
    console.log("Sending signup request to:", `${API_BASE_URL}/api/signup`);
    
    fetch(`${API_BASE_URL}/api/signup`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(res => {
        console.log("Response status:", res.status);
        return res.json();
    })
    .then(res => {
        console.log("Response data:", res);
        
        if (res.status === "success") {
            console.log("Sign-up successful!");
            
            // Show success message
            const successMsg = document.getElementById("signUpSuccess");
            if (successMsg) {
                successMsg.style.display = "block";
                successMsg.innerText = "Account created successfully! Redirecting to login...";
            }
            
            // Reset form
            document.getElementById("signUpForm").reset();
            
            // Redirect to sign in after 2 seconds
            setTimeout(() => {
                const showSignInLink = document.getElementById("showSignIn");
                if (showSignInLink) {
                    showSignInLink.click();
                } else {
                    document.getElementById('signUpSection').style.display = 'none';
                    document.getElementById('signInSection').style.display = 'block';
                }
                if (successMsg) successMsg.style.display = "none";
            }, 2000);
        } else {
            console.error("Sign-up failed:", res.message);
            showSignUpError(res.message || "Registration failed. Please try again.");
            
            // Re-enable button
            if (signUpButton) {
                signUpButton.disabled = false;
                signUpButton.value = "Sign Up";
            }
        }
    })
    .catch(err => {
        console.error("Signup error:", err);
        showSignUpError(`Error: ${err.message || "Network error. Please check your connection and try again."}`);
        
        // Re-enable button
        if (signUpButton) {
            signUpButton.disabled = false;
            signUpButton.value = "Sign Up";
        }
    });
});

function showSignUpError(message) {
    console.warn("Sign-up error:", message);
    const signUpError = document.getElementById("signUpError");
    if (signUpError) {
        signUpError.style.display = "block";
        signUpError.innerText = message;
        signUpError.style.color = "#d32f2f";
        signUpError.scrollIntoView({ behavior: "smooth", block: "center" });
    } else {
        console.warn("Error div not found, using alert");
        alert("Error: " + message);
    }
}

// ==================== SIGN IN ====================

document.getElementById("signInForm").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const email = document.getElementById("signInEmail").value.trim();
    const password = document.getElementById("signInPassword").value;
    const signInButton = document.querySelector("#signInForm input[type='submit']");
    
    console.log("Sign-in attempt:", { email });
    
    // Clear previous errors
    const signInError = document.getElementById("signInError");
    if (signInError) {
        signInError.style.display = "none";
        signInError.innerText = "";
    }
    
    // Validate inputs
    if (!email || !password) {
        showSignInError("Email and password are required");
        return;
    }
    
    if (!email.includes("@")) {
        showSignInError("Please enter a valid email address");
        return;
    }
    
    // Disable button during request
    if (signInButton) {
        signInButton.disabled = true;
        signInButton.value = "Signing in...";
    }
    
    // Send login request
    const data = {
        email: email,
        password: password
    };
    
    console.log("Sending login request to:", `${API_BASE_URL}/api/login`);
    
    fetch(`${API_BASE_URL}/api/login`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data),
        timeout: 10000
    })
    .then(res => {
        console.log("Response status:", res.status);
        return res.json();
    })
    .then(res => {
        console.log("Response data:", res);
        
        if (res.status === "success") {
            console.log("Login successful! User:", res.user);
            
            // Store user data in localStorage
            localStorage.setItem("user", JSON.stringify(res.user));
            localStorage.setItem("userId", res.user.id);
            localStorage.setItem("isArtisan", res.user.is_artisan || false);
            
            console.log("User data stored. Redirecting...");
            
            // Show success message
            showSignInSuccess("Login successful! Redirecting...");
            
            // Redirect based on user type
            setTimeout(() => {
                if (res.user.is_artisan) {
                    console.log("Redirecting to artisan dashboard");
                    window.location.href = "artisan-dashboard.html";
                } else {
                    console.log("Redirecting to user dashboard");
                    window.location.href = "user-dashboard-clean.html";
                }
            }, 500);
        } else {
            console.error("Login failed:", res.message);
            showSignInError(res.message || "Login failed. Please check your email and password.");
            
            // Re-enable button
            if (signInButton) {
                signInButton.disabled = false;
                signInButton.value = "Sign In";
            }
        }
    })
    .catch(err => {
        console.error("Login error:", err);
        showSignInError(`Error: ${err.message || "Network error. Please check your connection and try again."}`);
        
        // Re-enable button
        if (signInButton) {
            signInButton.disabled = false;
            signInButton.value = "Sign In";
        }
    });
});

function showSignInError(message) {
    console.warn("Sign-in error:", message);
    const signInError = document.getElementById("signInError");
    if (signInError) {
        signInError.style.display = "block";
        signInError.innerText = message;
        signInError.style.color = "#d32f2f";
        signInError.scrollIntoView({ behavior: "smooth", block: "center" });
    } else {
        console.warn("Error div not found, using alert");
        alert("Error: " + message);
    }
}

function showSignInSuccess(message) {
    console.log("Sign-in success:", message);
    const signInError = document.getElementById("signInError");
    if (signInError) {
        signInError.style.display = "block";
        signInError.innerText = message;
        signInError.style.color = "#4caf50";
        signInError.style.backgroundColor = "#f1f8f4";
        signInError.style.borderLeft = "4px solid #4caf50";
    }
}

// ==================== FORM TOGGLE ====================

document.addEventListener("DOMContentLoaded", function() {
    const oauthParams = new URLSearchParams(window.location.search);
    const oauthUser = oauthParams.get('oauth_user');
    const oauthError = oauthParams.get('oauth_error');
    if (oauthError) showSignInError(decodeURIComponent(oauthError));
    if (oauthUser) {
        try {
            const decoded = JSON.parse(decodeURIComponent(escape(atob(oauthUser))));
            localStorage.setItem('user', JSON.stringify(decoded));
            localStorage.setItem('userId', decoded.id);
            localStorage.setItem('isArtisan', decoded.is_artisan || false);
            window.location.href = decoded.is_artisan ? 'artisan-dashboard.html' : 'user-dashboard-clean.html';
            return;
        } catch (error) {
            showSignInError('Social login response could not be read.');
        }
    }
    document.querySelectorAll('.google-btn, .email-btn, .facebook-btn, .github-btn').forEach(button => {
        button.addEventListener('click', () => {
            const provider = button.classList.contains('facebook-btn') ? 'facebook' : button.classList.contains('github-btn') ? 'github' : 'google';
            const isArtisan = document.getElementById('isArtisanCheckbox')?.checked || false;
            fetch(`${API_BASE_URL}/api/auth/${provider}?is_artisan=${isArtisan}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status !== 'success') throw new Error(data.message || 'Social login is not configured');
                    window.location.href = data.authorization_url;
                })
                .catch(error => showSignInError(error.message));
        });
    });

    const showSignUpLink = document.getElementById('showSignUp');
    const showSignInLink = document.getElementById('showSignIn');
    const signInSection = document.getElementById('signInSection');
    const signUpSection = document.getElementById('signUpSection');
    const signInForm = document.getElementById('signInForm');
    const signUpForm = document.getElementById('signUpForm');
    
    if (showSignUpLink) {
        showSignUpLink.addEventListener('click', function(e) {
            e.preventDefault();
            signInSection.style.display = 'none';
            signUpSection.style.display = 'block';
            signInForm.reset();
        });
    }
    
    if (showSignInLink) {
        showSignInLink.addEventListener('click', function(e) {
            e.preventDefault();
            signUpSection.style.display = 'none';
            signInSection.style.display = 'block';
            signUpForm.reset();
        });
    }
    
    // Forgot password
    const forgotPassLink = document.querySelector('.forgot-pass a');
    if (forgotPassLink) {
        forgotPassLink.addEventListener('click', function(e) {
            e.preventDefault();
            signInSection.style.display = 'none';
            document.getElementById('forgotPasswordSection').style.display = 'block';
        });
    }
    
    const backToSignIn = document.getElementById('backToSignIn');
    if (backToSignIn) {
        backToSignIn.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('forgotPasswordSection').style.display = 'none';
            signInSection.style.display = 'block';
        });
    }
});

// ==================== UTILITY FUNCTIONS ====================

function isLoggedIn() {
    return localStorage.getItem("userId") !== null;
}

function getStoredUser() {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
}

function isArtisan() {
    return localStorage.getItem("isArtisan") === "1" || localStorage.getItem("isArtisan") === "true";
}

function logout() {
    localStorage.removeItem("user");
    localStorage.removeItem("userId");
    localStorage.removeItem("isArtisan");
    window.location.href = "index.html";
}

// Redirect to login if user tries to access protected pages
function requireLogin() {
    if (!isLoggedIn()) {
        window.location.href = "login.html";
    }
}

function requireArtisan() {
    if (!isLoggedIn() || !isArtisan()) {
        window.location.href = "login.html?redirect=artisan";
    }
}

// Export for use in other scripts
window.TradeProAuth = {
    isLoggedIn,
    getStoredUser,
    isArtisan,
    logout,
    requireLogin,
    requireArtisan
};
